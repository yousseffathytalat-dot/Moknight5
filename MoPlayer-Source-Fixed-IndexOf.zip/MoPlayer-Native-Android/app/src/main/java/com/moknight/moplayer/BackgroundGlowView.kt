package com.moknight.moplayer

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator

/**
 * Native recreation of the APK's CSS living background:
 * deep navy base, blue glow at the top, drifting blue/cyan/violet light,
 * and a soft breathing glow near the bottom.
 */
class BackgroundGlowView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var phase = 0f
    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 15000L
        repeatCount = ValueAnimator.INFINITE
        repeatMode = ValueAnimator.REVERSE
        interpolator = AccelerateDecelerateInterpolator()
        addUpdateListener { phase = it.animatedValue as Float; invalidate() }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (!animator.isStarted) animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        canvas.drawColor(0xFF030816.toInt())
        // Upper blue halo from the reference CSS radial-gradient.
        paint.shader = RadialGradient(
            w * 0.5f, -h * 0.03f, w * 1.12f,
            intArrayOf(0xAA1B3FAE.toInt(), 0x552457E8, 0x00030816),
            floatArrayOf(0f, 0.42f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w, h, paint)
        // Slow drifting ambient glows (intentionally restrained).
        paint.shader = RadialGradient(
            -w * 0.03f + phase * w * 0.08f, h * 0.12f, w * 0.72f,
            intArrayOf(0x662457E8, 0x242457E8, 0x00030816),
            floatArrayOf(0f, 0.48f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w, h, paint)
        paint.shader = RadialGradient(
            w * (1.02f - phase * 0.05f), h * 0.68f, w * 0.70f,
            intArrayOf(0x660E8FE1, 0x1C0E8FE1, 0x00030816),
            floatArrayOf(0f, 0.46f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w, h, paint)
        paint.shader = RadialGradient(
            w * (0.32f + phase * 0.28f), h * 0.48f, w * 0.60f,
            intArrayOf(0x444A3FD8, 0x124A3FD8, 0x00030816),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w, h, paint)
        // Soft floor glow, like the APK's animated .floor element.
        paint.shader = RadialGradient(
            w * 0.5f, h * 1.04f, h * 0.62f,
            intArrayOf(if (phase < 0.5f) 0x332F6BFF else 0x662F6BFF, 0x002F6BFF),
            null, Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w, h, paint)
        paint.shader = null
    }
}
