مشروع MoPlayer المدمج للمراجعة

ابدأ بقراءة MERGE_NOTES_AR.md داخل MoPlayerNative.
ملفات الواجهة الأصلية من APK موجودة في:
MoPlayerNative/app/src/main/assets/www/

مصدر Android/Kotlin الموجود من ZIP محفوظ كما هو. هذا ليس APK جديدًا جاهزًا للتثبيت، ولم يتم ادعاء أن وظائف الصوت والتصنيف قد رُبطت واختُبرت بالكامل.
