package com.moknight.moplayer

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.os.Handler
import android.os.Looper
import android.media.PlaybackParams
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors

data class AudioTrack(val id: Long, val title: String, val artist: String, val album: String, val uri: Uri, val folder: String)

class MainActivity : Activity() {
    private val tracks = mutableListOf<AudioTrack>()
    private var playingTrack: AudioTrack? = null
    private var playingIndex = -1
    private var activeQueue: List<Long>? = null
    private var queuePosition = -1
    private var currentTab = "all"
    private var continuous = true
    private var shuffle = false
    private var seeking = false
    private var repeatMode = 0 // 0 off, 1 all, 2 one
    private var playbackSpeed = 1.0f
    private var selectedIds = linkedSetOf<Long>()
    private val playlists = linkedMapOf<String, MutableList<Long>>()
    private val customArtwork = mutableMapOf<Long, String>()
    private lateinit var prefs: SharedPreferences
    private val handler = Handler(Looper.getMainLooper())
    private var sleepRunnable: Runnable? = null
    private lateinit var list: LinearLayout
    private lateinit var search: EditText
    private lateinit var title: TextView
    private lateinit var subtitle: TextView
    private lateinit var count: TextView
    private lateinit var miniTrack: TextView
    private lateinit var miniArtist: TextView
    private lateinit var playButton: TextView
    private lateinit var progress: SeekBar
    private lateinit var miniArt: ImageView
    private lateinit var sequence: TextView
    private lateinit var shuffleButton: TextView
    private var player: MediaPlayer? = null
    // A single worker prevents creating one thread per audio row, which could crash on large libraries.
    private val artworkExecutor = Executors.newSingleThreadExecutor()

    private val ticker = object : Runnable {
        override fun run() {
            if (!seeking) try {
                val p = player
                if (p != null) progress.progress = (p.currentPosition * 1000L / p.duration.coerceAtLeast(1)).toInt()
            } catch (_: Exception) {}
            progress.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFF030816.toInt()
        window.navigationBarColor = 0xFF030816.toInt()
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("moplayer_preferences", MODE_PRIVATE)
        loadPreferences()
        list = findViewById(R.id.tracksContainer)
        search = findViewById(R.id.searchField)
        title = findViewById(R.id.pageTitle)
        subtitle = findViewById(R.id.pageSubtitle)
        count = findViewById(R.id.countBadge)
        miniTrack = findViewById(R.id.miniTrack)
        miniArtist = findViewById(R.id.miniArtist)
        playButton = findViewById(R.id.playPause)
        progress = findViewById(R.id.progressBar)
        miniArt = findViewById(R.id.miniArtwork)
        sequence = findViewById(R.id.sequenceButton)
        shuffleButton = findViewById(R.id.shuffleButton)

        findViewById<View>(R.id.addButton).setOnClickListener { addMenu() }
        findViewById<View>(R.id.settingsButton).setOnClickListener { settings() }
        findViewById<View>(R.id.previousButton).setOnClickListener { moveTrack(-1) }
        findViewById<View>(R.id.nextButton).setOnClickListener { moveTrack(1) }
        playButton.setOnClickListener { toggle() }
        findViewById<View>(R.id.tabAll).setOnClickListener { currentTab = "all"; tabs(); render() }
        findViewById<View>(R.id.tabTracks).setOnClickListener { currentTab = "tracks"; tabs(); render() }
        findViewById<View>(R.id.tabFolders).setOnClickListener { currentTab = "folders"; tabs(); render() }
        sequence.setOnClickListener { continuous = !continuous; modeStyle(); toast(if (continuous) "التشغيل المتتابع يعمل" else "التشغيل المتتابع متوقف") }
        shuffleButton.setOnClickListener { shuffle = !shuffle; modeStyle(); toast(if (shuffle) "التشغيل العشوائي يعمل" else "التشغيل العشوائي متوقف") }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { render() }
            override fun afterTextChanged(s: Editable?) {}
        })
        progress.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar?) { seeking = true }
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                try { player?.seekTo((player!!.duration.toLong() * (seekBar?.progress ?: 0) / 1000).toInt()) } catch (_: Exception) {}
                seeking = false
            }
        })
        modeStyle()
        progress.post(ticker)
        requestAudio()
    }

    private fun requestAudio() {
        val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
        if (Build.VERSION.SDK_INT < 23 || checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED) loadAudio()
        else requestPermissions(arrayOf(perm), 100)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        if (requestCode == 100 && results.firstOrNull() == PackageManager.PERMISSION_GRANTED) loadAudio()
        else toast("اسمح للتطبيق بالوصول إلى ملفات الصوت")
    }

    private fun loadAudio() {
        tracks.clear()
        val uri = if (Build.VERSION.SDK_INT >= 29) MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL) else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val cols = mutableListOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM)
        if (Build.VERSION.SDK_INT >= 29) cols.add(MediaStore.Audio.Media.RELATIVE_PATH)
        try {
            contentResolver.query(uri, cols.toTypedArray(), null, null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use { c ->
                val id = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val ti = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val ar = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val al = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val fo = c.getColumnIndex(MediaStore.Audio.Media.RELATIVE_PATH)
                while (c.moveToNext()) {
                    val songId = c.getLong(id)
                    tracks.add(AudioTrack(songId, c.getString(ti) ?: "ملف صوتي",
                        c.getString(ar)?.takeUnless { it == "<unknown>" }.orEmpty(),
                        c.getString(al)?.takeUnless { it == "<unknown>" }.orEmpty(),
                        ContentUris.withAppendedId(uri, songId),
                        if (fo >= 0) c.getString(fo).orEmpty() else ""))
                }
            }
        } catch (_: Exception) {}
        updateHead()
        render()
    }

    private fun updateHead() {
        title.text = when (currentTab) { "tracks" -> "التسجيلات"; "folders" -> "القوائم"; else -> "المكتبة" }
        subtitle.text = when (currentTab) { "tracks" -> "تصفّح ملفاتك الصوتية"; "folders" -> "قوائم ومجلدات الصوت"; else -> "ملفاتك الصوتية في مكان واحد" }
        findViewById<TextView>(R.id.sectionTitle).text = when (currentTab) { "tracks" -> "التسجيلات"; "folders" -> "القوائم"; else -> "كل الملفات" }
    }

    private fun tabs() {
        listOf(R.id.tabAll, R.id.tabTracks, R.id.tabFolders).forEachIndexed { i, id ->
            val value = listOf("all", "tracks", "folders")[i]
            val v = findViewById<TextView>(id)
            v.background = getDrawable(if (currentTab == value) R.drawable.selected_bg else R.drawable.button_bg)
            v.alpha = if (currentTab == value) 1f else .72f
        }
        updateHead()
    }

    private fun modeStyle() {
        sequence.background = getDrawable(if (continuous) R.drawable.selected_bg else R.drawable.button_bg)
        sequence.alpha = if (continuous) 1f else .6f
        shuffleButton.background = getDrawable(if (shuffle) R.drawable.selected_bg else R.drawable.button_bg)
        shuffleButton.alpha = if (shuffle) 1f else .6f
    }

    private fun render() {
        list.removeAllViews()
        val q = search.text?.toString()?.trim().orEmpty()
        val filtered = tracks.filter { "${it.title} ${it.artist} ${it.album} ${it.folder}".contains(q, true) }
        count.text = "${filtered.size} ملف"
        if (currentTab == "folders") {
            playlists.toSortedMap().forEach { (playlistName, ids) ->
                val pr = row()
                pr.addView(artText("♫"))
                val pc = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(12),0,dp(8),0); layoutParams=LinearLayout.LayoutParams(0,-2,1f) }
                pc.addView(label(playlistName,13f,0xFFEAF1FF.toInt(),true))
                pc.addView(label("${ids.size} ملف محفوظ",11f,0xFF8FA3CF.toInt()))
                pr.addView(pc)
                pr.setOnClickListener { val first=tracks.firstOrNull { it.id in ids }; if(first!=null) play(first) else toast("القائمة فارغة أو ملفاتها غير متاحة") }
                pr.setOnLongClickListener { playlistActions(playlistName); true }
                list.addView(pr)
            }
            val groups = filtered.groupBy { it.folder.ifBlank { "مجلد غير معروف" } }.toSortedMap()
            if (groups.isEmpty()) { list.addView(label("لا توجد قوائم أو مجلدات لعرضها", 13f, 0xFF8FA3CF.toInt())); return }
            groups.forEach { (folder, items) ->
                val row = row()
                row.addView(artText("▣"))
                val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12),0,dp(8),0); layoutParams = LinearLayout.LayoutParams(0,-2,1f) }
                col.addView(label(folder.trimEnd('/'),13f,0xFFEAF1FF.toInt(),true))
                col.addView(label("${items.size} ملف صوتي",11f,0xFF8FA3CF.toInt()))
                row.addView(col)
                row.setOnClickListener { currentTab = "tracks"; tabs(); list.removeAllViews(); items.forEach { list.addView(trackRow(it)) } }
                list.addView(row)
            }
            return
        }
        if (filtered.isEmpty()) {
            list.addView(label(if (tracks.isEmpty()) "لا توجد ملفات صوتية ظاهرة. أضف ملفات على الهاتف واسمح بالوصول إليها." else "لا توجد نتائج مطابقة.",13f,0xFF8FA3CF.toInt()).apply { gravity=Gravity.CENTER; setPadding(dp(12),dp(24),dp(12),dp(24)) })
            return
        }
        filtered.forEach { list.addView(trackRow(it)) }
    }

    private fun trackRow(track: AudioTrack): View {
        val r = row()
        r.background = getDrawable(if (playingTrack?.id == track.id) R.drawable.track_selected_bg else R.drawable.track_bg)
        val box = FrameLayout(this).apply { layoutParams = LinearLayout.LayoutParams(dp(50),dp(50)); background = getDrawable(R.drawable.mini_logo_bg) }
        val image = ImageView(this).apply { layoutParams = FrameLayout.LayoutParams(-1,-1); scaleType=ImageView.ScaleType.CENTER_CROP; setImageResource(R.mipmap.ic_launcher) }
        val letter = TextView(this).apply { text="M"; textSize=22f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.CENTER; setTextColor(-1); background=getDrawable(R.drawable.mini_logo_bg); layoutParams=FrameLayout.LayoutParams(-1,-1) }
        box.addView(image); box.addView(letter)
        artwork(track,image) { letter.visibility = if (it) View.GONE else View.VISIBLE }
        val col=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(12),0,dp(8),0); layoutParams=LinearLayout.LayoutParams(0,-2,1f) }
        col.addView(label(track.title,13f,0xFFEAF1FF.toInt(),true))
        col.addView(label(track.artist.ifBlank { track.album.ifBlank { "ملف صوتي" } },10.5f,0xFF8FA3CF.toInt()))
        r.addView(box); r.addView(col); r.addView(label(if(playingTrack?.id==track.id && player?.isPlaying==true) "Ⅱ" else "▶",17f,0xFF4CB8FF.toInt(),true).apply { gravity=Gravity.CENTER; layoutParams=LinearLayout.LayoutParams(dp(34),dp(46)) })
        r.setOnClickListener { play(track) }
        r.setOnLongClickListener { toggleSelection(track); true }
        r.setOnTouchListener { v,e ->
            if(e.action==android.view.MotionEvent.ACTION_DOWN) v.animate().scaleX(.985f).scaleY(.985f).setDuration(100).start()
            if(e.action==android.view.MotionEvent.ACTION_UP || e.action==android.view.MotionEvent.ACTION_CANCEL) v.animate().scaleX(1f).scaleY(1f).setDuration(180).start()
            false
        }
        return r
    }

    private fun row() = LinearLayout(this).apply {
        orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(dp(12),dp(10),dp(10),dp(10)); background=getDrawable(R.drawable.track_bg)
        layoutParams=LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(8) }; isClickable=true; isFocusable=true
    }
    private fun artText(s:String) = TextView(this).apply { text=s; textSize=22f; gravity=Gravity.CENTER; setTextColor(-1); background=getDrawable(R.drawable.mini_logo_bg); layoutParams=LinearLayout.LayoutParams(dp(50),dp(50)) }
    private fun label(s:String,size:Float,color:Int,bold:Boolean=false) = TextView(this).apply { text=s; textSize=size; setTextColor(color); maxLines=1; ellipsize=android.text.TextUtils.TruncateAt.END; if(bold) setTypeface(typeface,Typeface.BOLD) }
    private fun artwork(track:AudioTrack,target:ImageView,done:(Boolean)->Unit={}) {
        target.setImageResource(R.mipmap.ic_launcher)
        val custom = customArtwork[track.id] ?: prefs.getString("art_${track.id}", null)
        if (custom != null) {
            try { target.setImageURI(Uri.parse(custom)); done(true); return } catch (_: Exception) {}
        }
        artworkExecutor.execute {
            var bitmap:android.graphics.Bitmap?=null
            val retriever=MediaMetadataRetriever()
            try { retriever.setDataSource(this,track.uri); retriever.embeddedPicture?.let { bitmap=BitmapFactory.decodeByteArray(it,0,it.size) } } catch (_:Exception) {} finally { try{retriever.release()}catch(_:Exception){} }
            val b=bitmap
            try {
                runOnUiThread { if(!isFinishing && !isDestroyed) { if(b!=null) target.setImageBitmap(b); done(b!=null) } }
            } catch (_:Exception) {}
        }
    }

    private fun play(track:AudioTrack, keepQueue: Boolean = false) {
        if (!keepQueue) { activeQueue = null; queuePosition = -1 }
        try {
            player?.release()
            player=MediaPlayer().apply {
                setDataSource(this@MainActivity,track.uri)
                setOnCompletionListener {
                    when {
                        repeatMode == 2 -> playingTrack?.let { play(it, keepQueue = true) }
                        activeQueue != null && activeQueue!!.isNotEmpty() -> {
                            val q = activeQueue!!
                            if (queuePosition + 1 < q.size) {
                                queuePosition++
                                tracks.firstOrNull { it.id == q[queuePosition] }?.let { play(it, keepQueue = true) }
                                    ?: run { activeQueue = null; playButton.text = "▶"; render() }
                            } else if (repeatMode == 1) {
                                queuePosition = 0
                                tracks.firstOrNull { it.id == q[queuePosition] }?.let { play(it, keepQueue = true) }
                            } else {
                                activeQueue = null; queuePosition = -1; playButton.text = "▶"; render()
                            }
                        }
                        repeatMode == 1 || continuous || shuffle -> moveTrack(1)
                        else -> { playButton.text = "▶"; render() }
                    }
                }
                setOnErrorListener { _, _, _ ->
                    runOnUiThread { toast("تعذّر تشغيل هذا الملف الصوتي") }
                    true
                }
                prepare(); start()
            }
            playingTrack=track; playingIndex=tracks.indexOfFirst{it.id==track.id}
            prefs.edit().putLong("last_track_id", track.id).putString("last_track_uri", track.uri.toString()).putString("last_track_title", track.title).putString("last_track_artist", track.artist).putString("last_track_album", track.album).putString("last_track_folder", track.folder).apply()
            try { player?.playbackParams = PlaybackParams().setSpeed(playbackSpeed) } catch (_: Exception) {}
            miniTrack.text=track.title; miniArtist.text=track.artist.ifBlank{track.album.ifBlank{"MoPlayer"}}
            artwork(track,miniArt); playButton.text="Ⅱ"; progress.progress=0; render()
        } catch (e:Exception) {
            try { player?.release() } catch (_:Exception) {}
            player = null
            playButton.text = "▶"
            toast("تعذّر تشغيل الملف الصوتي. جرّب ملفًا آخر أو تحقق من صلاحية الوصول.")
        }
    }
    private fun toggle() {
        val p=player
        if(p==null){toast("اختار ملف صوتي أولًا");return}
        try { if(p.isPlaying){p.pause();playButton.text="▶"}else{p.start();playButton.text="Ⅱ"}; render() }catch(_:Exception){ toast("تعذّر التحكم في التشغيل") }
    }
    private fun moveTrack(delta:Int) {
        if(tracks.isEmpty()) return
        val idx=if(shuffle && tracks.size>1) tracks.indices.filter{it!=playingIndex}.random() else ((if(playingIndex<0) 0 else playingIndex)+delta+tracks.size)%tracks.size
        play(tracks[idx])
    }
    private fun details(t:AudioTrack) {
        AlertDialog.Builder(this).setTitle("تفاصيل الملف").setMessage("الاسم: ${t.title}\nالفنان: ${t.artist.ifBlank{"غير معروف"}}\nالألبوم: ${t.album.ifBlank{"غير معروف"}}")
            .setPositiveButton("تشغيل"){_,_->play(t)}.setNeutralButton("مشاركة"){_,_->share(t)}.setNegativeButton("إغلاق",null).show()
    }
    private fun settings() {
        val opts = arrayOf(
            if (continuous) "✓ التشغيل المتتابع" else "التشغيل المتتابع",
            if (shuffle) "✓ التشغيل العشوائي" else "التشغيل العشوائي",
            "وضع التكرار: ${when(repeatMode){1->"تكرار الكل";2->"تكرار المقطع";else->"إيقاف"}}",
            "سرعة التشغيل (${playbackSpeed}x)", "مؤقت النوم", "إدارة قوائم التشغيل",
            "تحديد ملفات وإجراءات جماعية", "استعادة آخر أغنية", "تحديث المكتبة", "حول التطبيق"
        )
        AlertDialog.Builder(this).setTitle("الإعدادات").setItems(opts) { _, i -> when (i) {
            0 -> { continuous=!continuous; modeStyle(); savePreferences() }
            1 -> { shuffle=!shuffle; modeStyle(); savePreferences() }
            2 -> { repeatMode=(repeatMode+1)%3; savePreferences(); settings() }
            3 -> chooseSpeed()
            4 -> chooseSleepTimer()
            5 -> managePlaylists()
            6 -> bulkActions()
            7 -> resumeLastTrack()
            8 -> loadAudio()
            9 -> AlertDialog.Builder(this).setTitle("MoPlayer").setMessage("مشغل صوت أندرويد. بعض الميزات تعتمد على توافق الجهاز ومصدر الملف.").setPositiveButton("حسنًا",null).show()
        }}.show()
    }

    private fun resumeLastTrack() {
        val savedId=prefs.getLong("last_track_id", Long.MIN_VALUE)
        val savedUri=prefs.getString("last_track_uri", null)
        val t=tracks.firstOrNull { it.id==savedId } ?: if(savedUri!=null) try {
            AudioTrack(savedId, prefs.getString("last_track_title","ملف صوتي") ?: "ملف صوتي", prefs.getString("last_track_artist","") ?: "", prefs.getString("last_track_album","") ?: "", Uri.parse(savedUri), prefs.getString("last_track_folder","") ?: "")
        } catch (_:Exception) { null } else null
        if(t!=null) { if(tracks.none { it.id==t.id }) tracks.add(0,t); play(t) } else toast("لا توجد أغنية سابقة محفوظة")
    }

    private fun loadPreferences() {
        continuous = prefs.getBoolean("continuous", true)
        shuffle = prefs.getBoolean("shuffle", false)
        repeatMode = prefs.getInt("repeat_mode", 0)
        playbackSpeed = prefs.getFloat("speed", 1f)
        try {
            val arr = JSONArray(prefs.getString("playlists", "[]"))
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i); val ids = mutableListOf<Long>(); val a = obj.optJSONArray("ids") ?: JSONArray()
                for (j in 0 until a.length()) ids.add(a.optLong(j))
                playlists[obj.optString("name")] = ids
            }
            val arts = JSONObject(prefs.getString("artworks", "{}"))
            arts.keys().forEach { key -> customArtwork[key.toLongOrNull() ?: return@forEach] = arts.getString(key) }
        } catch (_: Exception) {}
    }

    private fun savePreferences() {
        prefs.edit().putBoolean("continuous", continuous).putBoolean("shuffle", shuffle).putInt("repeat_mode", repeatMode).putFloat("speed", playbackSpeed).apply()
        val arr = JSONArray()
        playlists.forEach { (name, ids) -> val obj=JSONObject(); obj.put("name",name); val a=JSONArray(); ids.forEach { a.put(it) }; obj.put("ids",a); arr.put(obj) }
        val arts=JSONObject(); customArtwork.forEach { (id, uri) -> arts.put(id.toString(),uri) }
        prefs.edit().putString("playlists",arr.toString()).putString("artworks",arts.toString()).apply()
    }

    private fun chooseSpeed() {
        val speeds = arrayOf("0.5x", "0.75x", "1.0x", "1.25x", "1.5x", "1.75x", "2.0x")
        val values = floatArrayOf(.5f,.75f,1f,1.25f,1.5f,1.75f,2f)
        val checked = values.indexOf(playbackSpeed).coerceAtLeast(2)
        AlertDialog.Builder(this).setTitle("سرعة التشغيل").setSingleChoiceItems(speeds, checked) { d, which ->
            playbackSpeed=values[which]; try { player?.playbackParams=PlaybackParams().setSpeed(playbackSpeed) } catch (_:Exception) {}; savePreferences(); d.dismiss(); toast("سرعة التشغيل ${speeds[which]}")
        }.setNegativeButton("إلغاء",null).show()
    }

    private fun chooseSleepTimer() {
        val options = arrayOf("إيقاف المؤقت", "10 دقائق", "15 دقيقة", "30 دقيقة", "45 دقيقة", "60 دقيقة")
        val mins = intArrayOf(0,10,15,30,45,60)
        AlertDialog.Builder(this).setTitle("مؤقت النوم").setItems(options) { _, i ->
            sleepRunnable?.let { handler.removeCallbacks(it) }; sleepRunnable=null
            if (mins[i] == 0) toast("تم إيقاف مؤقت النوم") else {
                val task=Runnable { try { player?.pause(); playButton.text="▶"; toast("تم إيقاف التشغيل بمؤقت النوم") } catch (_:Exception) {} }
                sleepRunnable=task; handler.postDelayed(task, mins[i]*60_000L); toast("سيتوقف التشغيل بعد ${mins[i]} دقيقة")
            }
        }.show()
    }

    private fun managePlaylists() {
        val names = playlists.keys.toMutableList()
        val options = names.toMutableList().apply { add("+ إنشاء قائمة جديدة") }
        AlertDialog.Builder(this).setTitle("قوائم التشغيل").setItems(options.toTypedArray()) { _, i ->
            if (i == names.size) {
                val input=EditText(this).apply { hint="اسم القائمة" }
                AlertDialog.Builder(this).setTitle("إنشاء قائمة").setView(input).setPositiveButton("إنشاء") { _, _ ->
                    val name=input.text.toString().trim(); if(name.isNotEmpty() && !playlists.containsKey(name)){ playlists[name]=selectedIds.toMutableList(); selectedIds.clear(); savePreferences(); toast("تم إنشاء القائمة") } else toast("اكتب اسمًا جديدًا")
                }.setNegativeButton("إلغاء",null).show()
            } else playlistActions(names[i])
        }.setNegativeButton("إغلاق",null).show()
    }

    private fun playlistActions(name:String) {
        val opts=arrayOf("تشغيل القائمة", "إضافة الملفات المحددة", "إعادة تسمية", "حذف القائمة")
        AlertDialog.Builder(this).setTitle(name).setItems(opts) { _, i -> when(i) {
            0 -> {
                val ids = playlists[name].orEmpty().filter { id -> tracks.any { it.id == id } }
                if (ids.isNotEmpty()) {
                    activeQueue = ids
                    queuePosition = 0
                    tracks.firstOrNull { it.id == ids.first() }?.let { play(it, keepQueue = true) }
                } else toast("القائمة فارغة أو ملفاتها غير متاحة")
            }
            1 -> { if(selectedIds.isEmpty()) toast("اضغط مطولًا على الملفات لتحديدها") else { playlists[name]?.addAll(selectedIds.filter { id -> playlists[name]?.contains(id)!=true }); selectedIds.clear(); savePreferences(); render(); toast("تمت الإضافة للقائمة") } }
            2 -> { val input=EditText(this).apply { setText(name) }; AlertDialog.Builder(this).setTitle("إعادة تسمية القائمة").setView(input).setPositiveButton("حفظ") { _, _ -> val new=input.text.toString().trim(); if(new.isNotEmpty() && new!=name){ playlists[new]=playlists.remove(name) ?: mutableListOf(); savePreferences() } }.setNegativeButton("إلغاء",null).show() }
            3 -> AlertDialog.Builder(this).setMessage("حذف القائمة $name؟ لن تُحذف الملفات الصوتية.").setPositiveButton("حذف") { _, _ -> playlists.remove(name); savePreferences(); toast("تم حذف القائمة") }.setNegativeButton("إلغاء",null).show()
        }}.show()
    }

    private fun toggleSelection(track: AudioTrack) {
        if (!selectedIds.add(track.id)) selectedIds.remove(track.id)
        toast(if(track.id in selectedIds) "تم التحديد: ${track.title}" else "تم إلغاء التحديد")
        bulkActions()
    }

    private fun bulkActions() {
        val opts=arrayOf("تشغيل الملفات المحددة", "إضافة المحدد إلى قائمة", "مشاركة الملف المحدد", "حذف التحديد")
        AlertDialog.Builder(this).setTitle("الملفات المحددة (${selectedIds.size})").setItems(opts) { _, i -> when(i) {
            0 -> {
                val ids = tracks.filter { it.id in selectedIds }.map { it.id }
                if (ids.isNotEmpty()) {
                    activeQueue = ids; queuePosition = 0
                    tracks.firstOrNull { it.id == ids.first() }?.let { play(it, keepQueue = true) }
                } else toast("حدد ملفًا أولًا")
            }
            1 -> managePlaylists()
            2 -> tracks.firstOrNull { it.id in selectedIds }?.let { share(it) } ?: toast("حدد ملفًا أولًا")
            3 -> { selectedIds.clear(); render(); toast("تم إلغاء التحديد") }
        }}.setPositiveButton("إغلاق",null).show()
    }

    private fun addMenu() {
        AlertDialog.Builder(this).setTitle("إضافة").setItems(arrayOf("اختيار ملف صوتي","اختيار صورة غلاف للأغنية الحالية","إدارة قوائم التشغيل","تحديث المكتبة")){_,i->
            if(i==0){val intent=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="audio/*"};startActivityForResult(intent,120)}
            else if(i==1){ if(playingTrack==null) toast("شغّل أغنية أولًا") else { val intent=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="image/*"};startActivityForResult(intent,121) } }
            else if(i==2) managePlaylists() else loadAudio()
        }.show()
    }
    @Deprecated("Use Activity Result API in a future refinement")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(resultCode != RESULT_OK) return
        val uri=data?.data?:return
        try{contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)}catch(_:Exception){}
        if(requestCode==121) {
            val track=playingTrack ?: return
            customArtwork[track.id]=uri.toString(); savePreferences(); artwork(track,miniArt); render(); toast("تم تغيير غلاف الأغنية")
        } else if(requestCode==120) {
            val name=uri.lastPathSegment?.substringAfterLast('/')?.substringAfterLast(':')?:"ملف صوتي"
            val t=AudioTrack(-System.currentTimeMillis(),name,"","",uri,"ملفات مختارة")
            tracks.add(0,t);play(t)
        }
    }
    private fun share(t:AudioTrack) {
        try{val i=Intent(Intent.ACTION_SEND).apply{type="audio/*";putExtra(Intent.EXTRA_STREAM,t.uri);putExtra(Intent.EXTRA_SUBJECT,t.title);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)};startActivity(Intent.createChooser(i,"مشاركة الملف الصوتي"))}catch(_:Exception){toast("تعذرت مشاركة الملف")}
    }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
    override fun onDestroy(){progress.removeCallbacks(ticker); sleepRunnable?.let { handler.removeCallbacks(it) }; savePreferences(); try{player?.release()}catch(_:Exception){};player=null;artworkExecutor.shutdownNow();super.onDestroy()}
}
