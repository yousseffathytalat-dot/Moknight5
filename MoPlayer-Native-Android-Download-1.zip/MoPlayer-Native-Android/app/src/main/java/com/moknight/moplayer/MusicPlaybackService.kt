package com.moknight.moplayer

import android.app.*
import android.content.*
import android.graphics.BitmapFactory
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

/** Owns audio playback so it continues when the Activity is closed or the screen is off. */
class MusicPlaybackService : Service() {
    companion object {
        const val ACTION_PLAY = "com.moplayer.nativeplayer.PLAY"
        const val ACTION_TOGGLE = "com.moplayer.nativeplayer.TOGGLE"
        const val ACTION_NEXT = "com.moplayer.nativeplayer.NEXT"
        const val ACTION_PREVIOUS = "com.moplayer.nativeplayer.PREVIOUS"
        const val ACTION_STOP = "com.moplayer.nativeplayer.STOP"
        const val ACTION_MODES = "com.moplayer.nativeplayer.MODES"
        const val ACTION_PAUSE = "com.moplayer.nativeplayer.PAUSE"
        const val ACTION_CHANGED = "com.moplayer.nativeplayer.TRACK_CHANGED"
        const val EXTRA_URI = "uri"
        const val EXTRA_TITLE = "title"
        const val EXTRA_ARTIST = "artist"
        const val EXTRA_QUEUE_URIS = "queue_uris"
        const val EXTRA_QUEUE_TITLES = "queue_titles"
        const val EXTRA_QUEUE_ARTISTS = "queue_artists"
        const val EXTRA_POSITION = "position"
        const val EXTRA_REPEAT = "repeat"
        const val EXTRA_SHUFFLE = "shuffle"
        const val EXTRA_CONTINUOUS = "continuous"
        const val EXTRA_SPEED = "speed"
        const val CHANNEL = "moplayer_playback"
        const val NOTIFICATION_ID = 4107
        @Volatile var player: MediaPlayer? = null
            private set
        @Volatile var currentUri: String? = null
            private set
        @Volatile var currentTitle: String = "MoPlayer"
            private set
        @Volatile var currentArtist: String = "مشغل الصوت"
            private set
    }

    private var queueUris = arrayListOf<String>()
    private var queueTitles = arrayListOf<String>()
    private var queueArtists = arrayListOf<String>()
    private var position = -1
    private var repeatMode = 0
    private var shuffle = false
    private var continuous = true
    private var speed = 1f

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PLAY -> {
                queueUris = intent.getStringArrayListExtra(EXTRA_QUEUE_URIS) ?: arrayListOf(intent.getStringExtra(EXTRA_URI).orEmpty())
                queueTitles = intent.getStringArrayListExtra(EXTRA_QUEUE_TITLES) ?: arrayListOf(intent.getStringExtra(EXTRA_TITLE).orEmpty())
                queueArtists = intent.getStringArrayListExtra(EXTRA_QUEUE_ARTISTS) ?: arrayListOf(intent.getStringExtra(EXTRA_ARTIST).orEmpty())
                position = intent.getIntExtra(EXTRA_POSITION, 0).coerceAtLeast(0)
                repeatMode = intent.getIntExtra(EXTRA_REPEAT, repeatMode)
                shuffle = intent.getBooleanExtra(EXTRA_SHUFFLE, shuffle)
                continuous = intent.getBooleanExtra(EXTRA_CONTINUOUS, continuous)
                speed = intent.getFloatExtra(EXTRA_SPEED, speed)
                val uri = intent.getStringExtra(EXTRA_URI)
                if (uri != null) {
                    val idx = queueUris.indexOf(uri)
                    if (idx >= 0) position = idx
                    playAt(position)
                }
            }
            ACTION_MODES -> { repeatMode = intent.getIntExtra(EXTRA_REPEAT, repeatMode); shuffle = intent.getBooleanExtra(EXTRA_SHUFFLE, shuffle); continuous = intent.getBooleanExtra(EXTRA_CONTINUOUS, continuous) }
            ACTION_PAUSE -> { try { player?.pause(); updateNotification(false) } catch (_: Exception) {} }
            ACTION_TOGGLE -> togglePlayback()
            ACTION_NEXT -> move(1)
            ACTION_PREVIOUS -> move(-1)
            ACTION_STOP -> { stopForeground(true); releasePlayer(); stopSelf() }
        }
        return START_STICKY
    }

    private fun playAt(index: Int) {
        if (queueUris.isEmpty()) return
        position = index.coerceIn(0, queueUris.lastIndex)
        val uri = queueUris[position]
        releasePlayer()
        currentUri = uri
        currentTitle = queueTitles.getOrNull(position)?.ifBlank { "ملف صوتي" } ?: "ملف صوتي"
        currentArtist = queueArtists.getOrNull(position).orEmpty()
        try {
            player = MediaPlayer().apply {
                setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                setDataSource(this@MusicPlaybackService, Uri.parse(uri))
                setOnCompletionListener {
                    when {
                        repeatMode == 2 -> playAt(position)
                        shuffle && queueUris.size > 1 -> playAt(nextIndex())
                        position < queueUris.lastIndex -> playAt(nextIndex())
                        continuous -> playAt(0)
                        repeatMode == 1 -> playAt(if (shuffle && queueUris.size > 1) (queueUris.indices.filter { it != position }.random()) else 0)
                        else -> { stopForeground(false); updateNotification(false) }
                    }
                }
                setOnErrorListener { _, _, _ -> stopForeground(false); updateNotification(false); true }
                startForeground(NOTIFICATION_ID, buildNotification(true))
                prepare(); try { playbackParams = android.media.PlaybackParams().setSpeed(speed) } catch (_: Exception) {}; start()
            }
            updateNotification(true)
            sendBroadcast(Intent(ACTION_CHANGED).setPackage(packageName).putExtra(EXTRA_URI, uri).putExtra(EXTRA_TITLE, currentTitle).putExtra(EXTRA_ARTIST, currentArtist))
        } catch (_: Exception) {
            releasePlayer()
            stopForeground(false)
            updateNotification(false)
        }
    }

    private fun nextIndex(): Int = if (shuffle && queueUris.size > 1) queueUris.indices.filter { it != position }.random() else (position + 1).coerceAtMost(queueUris.lastIndex)
    private fun move(delta: Int) {
        if (queueUris.isEmpty()) return
        if (shuffle && queueUris.size > 1) playAt(queueUris.indices.filter { it != position }.random())
        else {
            val n = position + delta
            if (n in queueUris.indices) playAt(n) else if (repeatMode == 1) playAt(if (delta > 0) 0 else queueUris.lastIndex)
        }
    }
    private fun togglePlayback() {
        val p = player ?: return
        try { if (p.isPlaying) p.pause() else p.start(); updateNotification(p.isPlaying) } catch (_: Exception) {}
    }
    private fun buildNotification(isPlaying: Boolean): android.app.Notification {
        fun action(label: String, icon: Int, action: String, request: Int) = NotificationCompat.Action.Builder(icon, label,
            PendingIntent.getService(this, request, Intent(this, MusicPlaybackService::class.java).setAction(action), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)).build()
        val openApp = PendingIntent.getActivity(this, 10, Intent(this, MainActivity::class.java).apply { flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP }, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL)
            .setContentIntent(openApp)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(currentTitle).setContentText(currentArtist.ifBlank { "MoPlayer" })
            .setOngoing(isPlaying).setOnlyAlertOnce(true).setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .addAction(action("السابق", android.R.drawable.ic_media_previous, ACTION_PREVIOUS, 1))
            .addAction(action(if (isPlaying) "إيقاف مؤقت" else "تشغيل", if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play, ACTION_TOGGLE, 2))
            .addAction(action("التالي", android.R.drawable.ic_media_next, ACTION_NEXT, 3))
            .setStyle(androidx.media.app.NotificationCompat.MediaStyle().setShowActionsInCompactView(0, 1, 2))
            .build()
    }
    private fun updateNotification(isPlaying: Boolean) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(isPlaying))
    }
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL, "تشغيل MoPlayer", NotificationManager.IMPORTANCE_LOW).apply { description = "التحكم في تشغيل الصوت بالخلفية" })
    }
    private fun releasePlayer() { try { player?.release() } catch (_: Exception) {}; player = null }
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onTaskRemoved(rootIntent: Intent?) { if (player == null) stopSelf(); super.onTaskRemoved(rootIntent) }
    override fun onDestroy() { releasePlayer(); super.onDestroy() }
}
