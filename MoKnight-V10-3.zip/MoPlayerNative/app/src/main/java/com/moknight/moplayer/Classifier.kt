package com.moknight.moplayer

/** تصنيف الملف: أنشودة / قرآن / أخرى. */
enum class Kind { NASHEED, QURAN, OTHER }

fun kindLabel(k: Kind): String = when (k) {
    Kind.NASHEED -> tr("أناشيد", "Nasheeds")
    Kind.QURAN -> tr("القرآن الكريم", "Quran")
    Kind.OTHER -> tr("أخرى", "Other")
}

fun kindOf(name: String?): Kind? = Kind.values().firstOrNull { it.name == name }

/**
 * نتيجة تحليل الصوت نفسه (مش الاسم):
 * beat  = قوة الإيقاع المنتظم (0..1). التلاوة بلا إيقاع منتظم، والأنشودة غالبًا لها إيقاع أو لحن متكرر.
 * pause = نسبة لحظات الصمت/الوقفات (التلاوة والكلام فيهم وقفات أكتر).
 * beat < 0 معناها إن التحليل فشل لهذا الملف.
 */
data class Probe(val beat: Float, val pause: Float) {
    val ok: Boolean get() = beat >= 0f
    /** كلام/تلاوة: مفيش إيقاع منتظم ومعاه وقفات. */
    val speechLike: Boolean get() = ok && beat < 0.25f && pause > 0.08f
}

/**
 * التصنيف بيتم على كذا مرحلة، والاسم لوحده مش هو الحكم:
 * 1) بيانات الملف كلها (الاسم، الملف، الفنان، الألبوم، النوع، المجلد) بنظام نقط، ومعاها كل أسماء السور 114 بالعربي والإنجليزي.
 * 2) الجيران: لو ملفات المجلد/الألبوم/الفنان نفسه أغلبها قرآن أو أناشيد، الملفات اللي مش واضحة بتتبعهم.
 *    وأي ملف بتنقله بإيدك بيعلّم باقي ملفات نفس الفنان/المجلد.
 * 3) تحليل الصوت نفسه (إيقاع ووقفات) للملفات اللي لسه مش واضحة.
 * 4) تصنيفك اليدوي هو الأقوى دايمًا.
 */
object Classifier {

    // ------------------------------------------------------------------
    //  أدوات التوحيد
    // ------------------------------------------------------------------

    /** توحيد الحروف: شيل التشكيل والتطويل، وحّد الألف والياء والتاء المربوطة، وخلّي كل كلمة بين مسافتين. */
    private fun norm(s: String): String {
        val sb = StringBuilder(s.length + 2)
        sb.append(' ')
        var lastSpace = true
        for (ch in s.lowercase()) {
            val c = when (ch) {
                'أ', 'إ', 'آ', 'ٱ' -> 'ا'
                'ى' -> 'ي'
                'ة' -> 'ه'
                'ؤ' -> 'و'
                'ئ' -> 'ي'
                else -> ch
            }
            val code = c.code
            if (code in 0x064B..0x065F || code == 0x0670 || code == 0x0640) continue
            if (c.isLetterOrDigit()) {
                sb.append(c)
                lastSpace = false
            } else if (!lastSpace) {
                sb.append(' ')
                lastSpace = true
            }
        }
        if (!lastSpace) sb.append(' ')
        return sb.toString()
    }

    private fun keys(vararg k: String): List<String> = k.map { norm(it).trim() }

    private fun hasAny(s: String, list: List<String>): Boolean = list.any { s.contains(" $it ") }

    // ------------------------------------------------------------------
    //  كلمات وأسماء
    // ------------------------------------------------------------------

    private val Q_KEYS = keys(
        "سورة", "سوره", "قرآن", "القرآن", "قران", "تلاوة", "تلاوات", "ترتيل", "مصحف", "المصحف",
        "تجويد", "ختمة", "رقية شرعية", "آية الكرسي", "اية الكرسي", "ايات", "آيات",
        "surah", "surat", "sura", "quran", "quraan", "koran", "tilawa", "tilawah", "tajweed",
        "juz", "recitation", "ruqyah", "ayatul kursi", "ayat al kursi",
    )

    private val N_KEYS = keys(
        "نشيد", "أناشيد", "اناشيد", "أنشودة", "انشودة", "أنشودات", "إنشاد", "انشاد", "منشد", "نشيدة",
        "ابتهال", "ابتهالات", "مدائح", "مديح نبوي",
        "nasheed", "nasheeds", "anasheed", "nashid", "nasyid", "inshad", "munshid",
    )

    private val N_GROUPS = keys(
        "فرقة", "نور الإيمان", "العين العالمية", "طيور الجنة", "أطفال المستقبل", "سامي يوسف",
        "ماهر زين", "حمود الخضر", "أحمد بوخاطر", "أبو راتب", "طلع البدر", "ابو راتب", "منشد",
        "محمد طارق", "عمر الحسيني", "مصطفى عاطف", "اسلام صبحي", "إسلام صبحي", "فريق",
        "sami yusuf", "maher zain", "humood", "mesut kurtis", "ahmed bukhatir", "abu ratib",
        "talaa al badru", "tala al badru", "native deen", "raihan", "outlandish", "hamza namira",
    )

    // القرّاء بينشدوا كمان، فاسم القارئ لوحده إشارة ضعيفة
    private val RECITERS = keys(
        "مشاري", "العفاسي", "عبد الباسط", "عبدالباسط", "المنشاوي", "الحصري", "السديس", "الشريم",
        "المعيقلي", "الغامدي", "الدوسري", "القطامي", "العجمي", "البلوشي", "الحذيفي", "الطبلاوي",
        "الشاطري", "بندر بليلة", "فارس عباد", "ادريس ابكر", "خالد الجليل", "علي جابر", "عبدالله بصفر",
        "رعد الكردي", "القزابري", "منصور السالمي", "وديع اليمني", "محمد أيوب", "مصطفى إسماعيل",
        "ياسر سلامة", "صلاح بوخاطر", "ابراهيم الاخضر", "عبد الله الموسى", "ماهر المعيقلي", "محمد جبريل",
        "mishary", "alafasy", "afasy", "minshawi", "husary", "hussary", "sudais", "shuraim", "ghamdi",
        "dosari", "dossary", "muaiqly", "abdul basit", "abdulbasit", "abdelbasset", "qatami", "ajmi",
        "balushi", "shatri", "hudhaify", "tablawi", "yasser salama", "idrees abkar", "bandar baleela",
    )

    // علامات إنه مش قرآن ولا أنشودة (محاضرات، بودكاست، رسائل صوتية، نغمات)
    private val O_KEYS = keys(
        "محاضرة", "محاضرات", "خطبة", "خطبه", "بودكاست", "كتاب مسموع", "رسالة صوتية", "رساله صوتيه",
        "podcast", "episode", "audiobook", "audio book", "lecture", "ringtone", "whatsapp audio", "ptt",
        "voice note", "voice message",
    )

    // أنواع موسيقى صريحة بعيدة عن الأناشيد
    private val O_GENRES = keys(
        "pop", "rock", "rap", "hip hop", "hiphop", "r b", "rnb", "dance", "electronic", "edm", "metal",
        "jazz", "country", "reggae", "techno", "house", "trap", "disco", "شعبي", "مهرجانات", "راب",
        "podcast", "speech", "spoken", "audiobook", "lecture",
    )

    private val G_QURAN = keys("quran", "koran", "recitation", "tilawat", "قران", "قرآن", "تلاوة", "تلاوات")
    private val G_NASHEED = keys("nasheed", "nasheeds", "anasheed", "nashid", "islamic", "اناشيد", "نشيد", "اسلامي", "إسلامي")

    // ------------------------------------------------------------------
    //  أسماء السور الـ 114
    // ------------------------------------------------------------------

    private val SURAH_AR: List<String> = keys(
        "الفاتحة", "البقرة", "آل عمران", "النساء", "المائدة", "الأنعام", "الأعراف", "الأنفال", "التوبة",
        "يونس", "هود", "يوسف", "الرعد", "إبراهيم", "الحجر", "النحل", "الإسراء", "الكهف", "مريم", "طه",
        "الأنبياء", "الحج", "المؤمنون", "النور", "الفرقان", "الشعراء", "النمل", "القصص", "العنكبوت",
        "الروم", "لقمان", "السجدة", "الأحزاب", "سبأ", "فاطر", "يس", "الصافات", "الزمر", "غافر", "فصلت",
        "الشورى", "الزخرف", "الدخان", "الجاثية", "الأحقاف", "محمد", "الفتح", "الحجرات", "الذاريات",
        "الطور", "النجم", "القمر", "الرحمن", "الواقعة", "الحديد", "المجادلة", "الحشر", "الممتحنة", "الصف",
        "الجمعة", "المنافقون", "التغابن", "الطلاق", "التحريم", "الملك", "القلم", "الحاقة", "المعارج",
        "نوح", "الجن", "المزمل", "المدثر", "القيامة", "الإنسان", "المرسلات", "النبأ", "النازعات", "عبس",
        "التكوير", "الانفطار", "المطففين", "الانشقاق", "البروج", "الطارق", "الأعلى", "الغاشية", "الفجر",
        "البلد", "الشمس", "الليل", "الضحى", "الشرح", "التين", "العلق", "القدر", "البينة", "الزلزلة",
        "العاديات", "القارعة", "التكاثر", "العصر", "الهمزة", "الفيل", "قريش", "الماعون", "الكوثر",
        "الكافرون", "النصر", "المسد", "الإخلاص", "الفلق", "الناس",
        // أسماء بديلة
        "براءة", "التوبه", "الاخلاص", "اللهب", "تبت", "الدهر", "المعوذتين", "ياسين", "الم السجدة", "حم السجدة",
    )

    private val AR_FULL: Set<String> = SURAH_AR.toSet()

    // نفس الأسماء من غير "ال" (إشارة أضعف لأنها كلمات عادية: نور، فجر، شمس...)
    private val AR_BARE: Set<String> = SURAH_AR.mapNotNull {
        if (it.startsWith("ال") && it.length > 5) it.substring(2).trim() else null
    }.toSet()

    // أسماء سور ممكن تكون كمان اسم أغنية/شخص، فنقطها أقل
    private val AR_AMBIG: Set<String> = keys(
        "يوسف", "مريم", "محمد", "إبراهيم", "نوح", "هود", "لقمان", "النور", "الفجر", "الشمس", "الرحمن",
        "الفتح", "الجن", "الملك", "الحديد", "الصف", "الطلاق", "طه", "الشرح", "التين", "القدر", "العصر",
        "النصر", "القمر", "النجم", "الروم", "الحج", "الإنسان", "البلد", "الليل", "الضحى", "الطور", "الفيل",
        "الجمعة", "النساء", "الدهر", "التوبة", "القيامة", "اللهب", "سبأ", "فاطر", "الأعلى", "الحشر", "الشعراء", "الكهف",
    ).toSet()

    // كل اسم سورة بالإنجليزي بصيغ الكتابة الشائعة (من غير "Al-" و"An-" و"Ar-"...)
    private val EN_SURAH: List<String> = listOf(
        "fatiha|fatihah|fateha", "baqarah|baqara|bakarah|bakara", "imran|eimran|iimran|omran",
        "nisa|nisaa|nissa", "maidah|maida|maaidah|maeda|maedah", "anam|anaam|anaam", "araf|aaraf|aeraf",
        "anfal|anfaal", "tawbah|tawba|taubah|tauba|baraah|barah", "yunus|yoonus|younus|yunis",
        "hud|hood", "yusuf|yousuf|yousef|yosuf|yusuff|joseph", "rad|raad|raud|rrad", "ibrahim|ibraheem|abraham",
        "hijr|hijar", "nahl|nahal", "isra|israa|baniisrael|baniisraeel", "kahf|kahaf|kehf", "maryam|mariam|maryem|mary",
        "taha|taahaa", "anbiya|anbiyaa|ambiya|anbiyah", "hajj|haj", "muminun|mominoon|muminoon|mumenoon|muminin|muminum",
        "nur|noor|nour", "furqan|furqaan|forqan", "shuara|shuaraa|shuaara|shuaaraa", "naml|namal",
        "qasas|qasass|qisas", "ankabut|ankaboot|ankabout|ankabuut", "rum|room|rome", "luqman|luqmaan|lokman|loqman",
        "sajdah|sajda|sajadah|sajdeh", "ahzab|ahzaab|ahzabb", "saba|sabaa|sheba", "fatir|faatir|fater",
        "yasin|yaseen|yasseen|yaaseen", "saffat|saaffaat|saffaat|saafaat|safat", "sad|saad|suad",
        "zumar|zumer|zomar", "ghafir|ghafer|mumin|mumen|momin", "fussilat|fusilat|fuselat|fosselat",
        "shura|shoora|shuraa|shuara2", "zukhruf|zukhruf|zokhrof|zukhraf", "dukhan|dokhan|dukhaan|dukhaan",
        "jathiyah|jathiya|jasiyah|jaathiyah|jathia|jasiya", "ahqaf|ahqaaf|ahkaf", "muhammad|mohammed|mohamed|mohammad",
        "fath|fatah|fatih", "hujurat|hujuraat|hojorat|hujurat", "qaf|qaaf",
        "dhariyat|dhariyaat|zariyat|zariyaat|dhaariyaat|zaariyaat", "tur|toor|tour", "najm|najam|nijm",
        "qamar|kamar", "rahman|rehman|rahmaan|rahmen|rahmann", "waqiah|waqia|waqiya|waaqiah|waqiyah|waqea",
        "hadid|hadeed|hadied", "mujadilah|mujadila|mujadalah|mujadala|mujadelah", "hashr|hasher|hashar",
        "mumtahanah|mumtahana|mumtahina|mumtahinah|mumtahena", "saff|saf|saaf", "jumuah|jumua|jumah|juma|jummah|jumaa",
        "munafiqun|munafiqoon|munafikun|munafiqin|munafiqeen|munafiqon", "taghabun|taghaabun|taghabon|taghabn",
        "talaq|talaaq|talak", "tahrim|tahreem|tahrem|tahrime", "mulk|mulq|molk", "qalam|kalam",
        "haqqah|haaqqah|haqqa|haqa|haaqqa", "maarij|maaarij|maarej|marij|maarig", "nuh|nooh|noah",
        "jinn|jin|jen", "muzzammil|muzammil|muzzamil|muzamil", "muddaththir|muddathir|mudathir|muddasir|mudassir|mudaththir|mudasir",
        "qiyamah|qiyama|qiyamat|qiyaamah|qiyamh", "insan|insaan|dahr|ensan", "mursalat|mursalaat|mursalah|morsalat",
        "naba|nabaa|nabae|nabaa2", "naziat|naziaat|naaziaat|naziyat|naziyaat|naziat2", "abasa|abas|abbasa",
        "takwir|takweer|takwer|takvir", "infitar|infitaar|infitaar|enfitar", "mutaffifin|mutaffifeen|mutafifin|mutaffifun|tatfif|mutafifeen",
        "inshiqaq|inshiqaaq|inshiqaq|inshiqaq|inshikak", "buruj|burooj|buruuj|borooj", "tariq|taariq|tareq|tarik",
        "ala|aala|alaa|aala2", "ghashiyah|ghashiya|ghashia|gashiyah|ghashiah", "fajr|fajar|fajer", "balad|balat|belad",
        "shams|shamsh|shamss", "layl|lail|leil|laylah|layel", "duha|dhuha|duhaa|dhuhaa|zuha|doha",
        "sharh|inshirah|inshirah|sharah|ashrah", "tin|teen|tiin", "alaq|alak|iqra|alaaq", "qadr|qadar|qadir|qader",
        "bayyinah|bayyina|bayinah|bayyinat|bayinat", "zalzalah|zalzala|zilzal|zilzalah|zelzal", "adiyat|adiyaat|aadiyat|aadiyaat|adiat",
        "qariah|qaria|qariaa|qaariah|qaaria|qariyah|qaria2", "takathur|takasur|takaathur|takaathur|takathor",
        "asr|asar|assr", "humazah|humaza|humazat|homazah", "fil|feel|fiel", "quraysh|quraish|qurayshin|quresh|kuraish|qoraish",
        "maun|maoon|maaoon|maaun|maon", "kawthar|kauthar|kausar|kawsar|kauser|kawther|kothar|kosar",
        "kafirun|kafiroon|kaafiroon|kafirin|kafiron|kafirune", "nasr|nasar|nassr", "masad|lahab|tabbat|lahb",
        "ikhlas|ikhlaas|ikhlass|ikhlasi|ikhlaas2", "falaq|falak|falaaq|felaq", "nas|naas|nass",
    )

    private val EN_SET: Set<String> = EN_SURAH.flatMap { it.split('|') }.filter { it.length >= 2 }.toSet()

    private val EN_AMBIG: Set<String> = setOf(
        "hud", "hood", "yusuf", "yousuf", "yousef", "yosuf", "maryam", "mariam", "mary", "ibrahim", "ibraheem",
        "nur", "noor", "nour", "muhammad", "mohammed", "mohamed", "mohammad", "fath", "fatah", "fajr", "fajar",
        "shams", "jinn", "jin", "mulk", "rahman", "rehman", "insan", "saba", "sheba", "nuh", "nooh", "noah",
        "sad", "saad", "qaf", "taha", "fatir", "luqman", "lail", "layl", "leil", "tin", "teen", "qadr", "qadar",
        "asr", "asar", "rum", "room", "rome", "ala", "alaa", "nas", "naas", "sharh", "hadid", "hadeed", "saff", "saf",
        "tariq", "tareq", "najm", "qamar", "nasr", "duha", "dhuha", "zuha", "fil", "feel", "juma", "jumah", "jumma",
        "tur", "toor", "tour", "balad", "naba", "nabaa", "rad", "raad", "mumin", "momin", "hajj", "haj", "kahf",
        "joseph", "abraham", "dahr", "ikhlas", "ikhlaas", "ikhlass", "ikhlasi", "tawbah", "tawba", "taubah", "tauba", "qiyamah", "qiyama", "hashr", "shura", "jin", "doha", "fiel", "kamar", "kalam", "qalam",
    )

    private val ARTICLES = listOf("aal", "ash", "adh", "ath", "al", "an", "ar", "as", "at", "az", "ad", "el")

    /** 0 = مش اسم سورة، 1 = اسم سورة ممكن يكون اسم حاجة تانية، 2 = اسم سورة واضح. */
    private fun surahHit(text: String): Int {
        var best = 0
        // عربي
        val core = norm(text).trim().split(' ')
            .filter { it.isNotEmpty() && it != "سوره" && it != "surah" && it != "surat" && it != "sura" && !it.all { ch -> ch.isDigit() } }
            .joinToString(" ")
        if (core.isNotEmpty()) {
            if (core in AR_FULL) best = if (core in AR_AMBIG) 1 else 2
            else if (core in AR_BARE) best = 1
        }
        // إنجليزي
        var c = text.lowercase().filter { it in 'a'..'z' }
        for (p in listOf("surah", "surat", "sura", "chapter")) if (c.startsWith(p) && c.length > p.length) { c = c.removePrefix(p); break }
        if (c.length >= 2) {
            var hit: String? = null
            if (c in EN_SET) {
                hit = c
            } else {
                for (a in ARTICLES) {
                    if (c.startsWith(a) && c.length > a.length + 1 && c.substring(a.length) in EN_SET) {
                        hit = c.substring(a.length)
                        break
                    }
                }
            }
            if (hit != null) {
                val v = if (hit in EN_AMBIG) 1 else 2
                if (v > best) best = v
            }
        }
        return best
    }

    // ------------------------------------------------------------------
    //  النقط
    // ------------------------------------------------------------------

    private class Sig(var q: Int = 0, var n: Int = 0, var o: Int = 0)

    private fun pureNumber(t: Track): Int? {
        val base = t.file.substringBeforeLast('.').trim()
        if (base.isEmpty() || base.length > 3 || !base.all { it.isDigit() }) return null
        val v = base.toIntOrNull() ?: return null
        return if (v in 1..114) v else null
    }

    private fun sig(t: Track, numericFolder: Boolean): Sig {
        val s = Sig()
        val tf = norm("${t.title} ${t.file}")
        val all = norm("${t.title} ${t.file} ${t.artist} ${t.album} ${t.genre} ${t.path}")

        // 1) كلمات صريحة (أقوى لو في الاسم نفسه)
        val tq = hasAny(tf, Q_KEYS)
        val tn = hasAny(tf, N_KEYS)
        if (tq && !tn) s.q += 6
        else if (tn && !tq) s.n += 6
        else {
            if (hasAny(all, Q_KEYS)) s.q += 4
            if (hasAny(all, N_KEYS)) s.n += 4
        }
        // 2) منشدون وفرق معروفين
        if (hasAny(all, N_GROUPS)) s.n += 4
        // 3) اسم قارئ: إشارة ضعيفة لأن القرّاء بينشدوا كمان
        if (hasAny(all, RECITERS)) s.q += 2
        // 4) اسم سورة (عربي أو إنجليزي) في الاسم أو اسم الملف
        val hit = maxOf(surahHit(t.title), surahHit(t.file.substringBeforeLast('.')))
        if (hit == 2) s.q += 4 else if (hit == 1) s.q += 2
        // 5) نوع الملف (Genre)
        if (t.genre.isNotBlank()) {
            val g = norm(t.genre)
            if (hasAny(g, G_QURAN)) s.q += 4
            if (hasAny(g, G_NASHEED)) s.n += 2
            if (hasAny(g, O_GENRES)) s.o += 4
        }
        // 6) مجلد كله ملفات أرقامها 1..114 (001.mp3 ... 114.mp3)
        if (numericFolder) s.q += 3
        // 7) محاضرات وبودكاست ورسائل صوتية
        if (hasAny(tf, O_KEYS)) s.o += 5
        return s
    }

    private fun base(s: Sig): Kind? = when {
        s.q >= 3 && s.q > s.n && s.q >= s.o -> Kind.QURAN
        s.n >= 4 && s.n >= s.q && s.n > s.o -> Kind.NASHEED
        s.o >= 4 && s.q < 3 && s.n < 4 -> Kind.OTHER
        else -> null
    }

    // ------------------------------------------------------------------
    //  الجيران (المجلد / الألبوم / الفنان)
    // ------------------------------------------------------------------

    private val GENERIC_DIRS = setOf(
        "music", "download", "downloads", "audio", "audios", "sounds", "media", "sdcard", "storage", "emulated",
        "whatsapp", "whatsapp audio", "bluetooth", "recordings", "documents", "telegram", "telegram audio",
        "android", "data", "podcasts", "notifications", "ringtones", "alarms", "0", "الموسيقى", "التنزيلات",
    )

    private fun dirOf(path: String): String {
        val p = path.replace('\\', '/').trim('/')
        if (p.isEmpty()) return ""
        val last = p.substringAfterLast('/')
        val ext = last.substringAfterLast('.', "")
        return if (last.contains('.') && ext.length in 2..5) p.substringBeforeLast('/', "") else p
    }

    private fun groupKeys(t: Track): List<String> {
        val out = ArrayList<String>(3)
        val d = dirOf(t.path).lowercase()
        if (d.isNotEmpty() && d.substringAfterLast('/').trim() !in GENERIC_DIRS) out.add("f:$d")
        val al = norm(t.album).trim()
        if (al.length >= 3 && al != "unknown" && al != "music" && al != "download" && al != "downloads") out.add("b:$al")
        val ar = norm(t.artist).trim()
        if (ar.length >= 3 && ar != "unknown") out.add("a:$ar")
        return out
    }

    class Result(val kinds: Map<Long, Kind>, val needProbe: List<Track>)

    /**
     * يحدد تصنيف كل الملفات.
     * [manual] تصنيفات انت عملتها بإيدك، [probes] نتايج تحليل الصوت المحفوظة.
     */
    fun resolve(list: List<Track>, probes: Map<Long, Probe>, manual: Map<Long, Kind>): Result {
        // مجلدات الملفات المرقمة 001..114
        val nums = HashMap<String, MutableSet<Int>>()
        for (t in list) {
            val n = pureNumber(t) ?: continue
            val d = dirOf(t.path).lowercase()
            if (d.isNotEmpty()) nums.getOrPut(d) { HashSet() }.add(n)
        }
        val numericDirs = nums.filter { it.value.size >= 8 && (it.value.maxOrNull() ?: 0) >= 30 }.keys

        val sigs = HashMap<Long, Sig>(list.size * 2)
        val strong = HashMap<Long, Kind>()
        for (t in list) {
            val d = dirOf(t.path).lowercase()
            val s = sig(t, pureNumber(t) != null && d in numericDirs)
            sigs[t.id] = s
            base(s)?.let { strong[t.id] = it }
        }

        // أصوات الجيران
        val votes = HashMap<String, IntArray>()
        fun vote(t: Track, k: Kind, w: Int) {
            for (g in groupKeys(t)) votes.getOrPut(g) { IntArray(3) }[k.ordinal] += w
        }
        for (t in list) {
            val m = manual[t.id]
            if (m != null) vote(t, m, 3)
            else strong[t.id]?.let { vote(t, it, 1) }
        }

        fun byNeighbours(t: Track): Kind? {
            for (g in groupKeys(t)) {
                val v = votes[g] ?: continue
                val total = v.sum()
                var bi = 0
                for (i in 1..2) if (v[i] > v[bi]) bi = i
                if (v[bi] >= 3 && v[bi] * 10 >= total * 7) return Kind.values()[bi]
            }
            return null
        }

        val out = HashMap<Long, Kind>(list.size * 2)
        val need = ArrayList<Track>()
        for (t in list) {
            val m = manual[t.id]
            if (m != null) { out[t.id] = m; continue }
            val st = strong[t.id]
            if (st != null) { out[t.id] = st; continue }
            val nb = byNeighbours(t)
            if (nb != null) { out[t.id] = nb; continue }
            val p = probes[t.id]
            if (p == null) need.add(t)
            out[t.id] = fallback(t, sigs.getValue(t.id), p)
        }
        return Result(out, need)
    }

    /** آخر مرحلة للملفات اللي الاسم والجيران ما حسموهاش: بنبص على مدة الملف وعلى الصوت نفسه. */
    private fun fallback(t: Track, s: Sig, p: Probe?): Kind {
        val sec = t.durationMs / 1000
        if (sec < 40) return Kind.OTHER                        // مقاطع قصيرة ونغمات
        if (sec > 30 * 60) return if (s.q > 0) Kind.QURAN else Kind.OTHER   // محاضرات وبودكاست طويلة
        if (p != null && p.ok) {
            if (p.speechLike) return if (s.q > 0) Kind.QURAN else Kind.OTHER // كلام بلا إيقاع
            return Kind.NASHEED                                 // صوت ملحّن/إيقاعي من غير علامات إنه حاجة تانية
        }
        return Kind.NASHEED
    }
}
