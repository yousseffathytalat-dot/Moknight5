package com.moknight.moplayer

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.withFrameNanos
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

/**
 * هالة ضوئية (جلو) ناعمة حوالين العنصر، مرسومة بطبقات شفافة فتشتغل على كل إصدارات أندرويد.
 * [alpha] دالة عشان الجلو يتحرك (نبض) من غير ما يعمل recomposition.
 */
fun Modifier.glow(color: Color, radius: Dp = 18.dp, corner: Dp = 24.dp, alpha: () -> Float): Modifier =
    this.drawBehind {
        val a = alpha()
        if (a <= 0.01f) return@drawBehind
        val r = radius.toPx()
        val c = corner.toPx()
        val steps = 8
        for (i in steps downTo 1) {
            val f = i / steps.toFloat()
            val grow = r * f
            drawRoundRect(
                color = color.copy(alpha = (a * 0.30f * (1f - f * 0.82f)).coerceIn(0f, 1f)),
                topLeft = Offset(-grow, -grow),
                size = Size(size.width + grow * 2f, size.height + grow * 2f),
                cornerRadius = CornerRadius(c + grow)
            )
        }
    }

fun Modifier.glow(color: Color, radius: Dp = 18.dp, corner: Dp = 24.dp, alpha: Float): Modifier =
    this.glow(color, radius, corner) { alpha }

// منحنيات الحركة المنسوخة من الـ APK
val EaseApk = CubicBezierEasing(0.2f, 0.8f, 0.2f, 1f)       // --ease
val EaseLayer = CubicBezierEasing(0.2f, 0.9f, 0.3f, 1f)     // فتح الطبقة المركزية
val EaseSheet = CubicBezierEasing(0.2f, 0.85f, 0.2f, 1f)    // فتح المشغّل الكامل
val EaseSeg = CubicBezierEasing(0.34f, 1.45f, 0.64f, 1f)    // مؤشر السرعة والنوم (بنطّة خفيفة)

/** ضغطة: العنصر بيصغر وهو مضغوط ويرجع بنعومة (زي :active في الـ APK). */
@OptIn(ExperimentalFoundationApi::class)
fun Modifier.bounceClick(
    enabled: Boolean = true,
    onLong: (() -> Unit)? = null,
    pressScale: Float = 0.92f,
    interaction: MutableInteractionSource? = null,
    onClick: () -> Unit,
): Modifier = composed {
    val src = interaction ?: remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed) pressScale else 1f, tween(260, easing = EaseApk), label = "press")
    this
        .graphicsLayer { scaleX = sc; scaleY = sc }
        .combinedClickable(
            interactionSource = src,
            indication = null,
            enabled = enabled,
            onLongClick = onLong,
            onClick = onClick,
        )
}

/** ظهور العنصر زي .rv في الـ APK: شفافية + طلوع من تحت + تكبير بسيط، بتأخير حسب ترتيبه. */
@Composable
fun Modifier.staggerIn(
    index: Int,
    step: Int = 50,
    base: Int = 0,
    rise: Dp = 24.dp,
    from: Float = 0.97f,
    dur: Int = 500,
): Modifier {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay((base + index.coerceIn(0, 10) * step).toLong())
        a.animateTo(1f, tween(dur, easing = EaseApk))
    }
    return this.graphicsLayer {
        alpha = a.value
        translationY = (1f - a.value) * rise.toPx()
        val sc = from + (1f - from) * a.value
        scaleX = sc
        scaleY = sc
    }
}

/** "popi" من الـ APK: الأيقونة بتتكبر وتميل وترجع لما تتفعّل. */
fun Modifier.popi(trigger: Any?, enabled: Boolean = true): Modifier = composed {
    val p = remember { Animatable(1f) }
    LaunchedEffect(trigger) {
        if (enabled) {
            p.snapTo(0f)
            p.animateTo(1f, tween(500, easing = EaseApk))
        }
    }
    this.graphicsLayer {
        val x = p.value
        val sc: Float
        val rot: Float
        if (x < 0.6f) {
            val f = x / 0.6f
            sc = 0.5f + 0.72f * f
            rot = -40f + 48f * f
        } else {
            val f = (x - 0.6f) / 0.4f
            sc = 1.22f - 0.22f * f
            rot = 8f * (1f - f)
        }
        scaleX = sc
        scaleY = sc
        rotationZ = rot
    }
}

/** الترس: بيلف وهو مضغوط (60 درجة) وبيرجع، زي .setb:active svg في الـ APK. */
@Composable
fun GearIcon(tint: Color, size: Dp, pressed: Boolean = false, deg: Float = 60f, modifier: Modifier = Modifier) {
    val r by animateFloatAsState(if (pressed) deg else 0f, tween(500, easing = EaseApk), label = "gear")
    Icon(
        Icons.Outlined.Settings, null, tint = tint,
        modifier = modifier.size(size).graphicsLayer { rotationZ = r }
    )
}

/** أيقونة تشغيل/إيقاف بتتحوّل لبعض بدوران وتصغير (زي .pbtn .ip / .ia في الـ APK). */
@Composable
fun PlayPauseIcon(playing: Boolean, tint: Color, size: Dp) {
    val t by animateFloatAsState(if (playing) 1f else 0f, tween(550, easing = EaseApk), label = "pp")
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Icon(
            Icons.Default.PlayArrow, null, tint = tint,
            modifier = Modifier.fillMaxSize().graphicsLayer {
                alpha = 1f - t
                rotationZ = 90f * t
                val sc = 1f - 0.7f * t
                scaleX = sc
                scaleY = sc
            }
        )
        Icon(
            Icons.Default.Pause, null, tint = tint,
            modifier = Modifier.fillMaxSize().graphicsLayer {
                alpha = t
                rotationZ = -90f * (1f - t)
                val sc = 0.3f + 0.7f * t
                scaleX = sc
                scaleY = sc
            }
        )
    }
}

/** حلقة "burst" بتتمدد وتختفي لما تضغط على زر التشغيل (من الـ APK). */
fun Modifier.burstRing(key: Int, maxScale: Float = 1.5f): Modifier = composed {
    val p = remember { Animatable(1f) }
    LaunchedEffect(key) {
        if (key > 0) {
            p.snapTo(0f)
            p.animateTo(1f, tween(600, easing = EaseApk))
        }
    }
    this.drawBehind {
        val x = p.value
        if (x < 1f) {
            val r = size.minDimension / 2f
            drawCircle(
                color = Sky.copy(alpha = 1f - x),
                radius = r * (1f + (maxScale - 1f + 0.5f) * x),
                style = androidx.compose.ui.graphics.drawscope.Stroke((4f * (1f - x) + 1f).dp.toPx())
            )
        }
    }
}

/** حلقة بتتمدد حوالين الصف اللي اتشغّل (.tr.pop في الـ APK). */
fun Modifier.popRing(key: Int, corner: Dp): Modifier = composed {
    val p = remember { Animatable(1f) }
    LaunchedEffect(key) {
        if (key > 0) {
            p.snapTo(0f)
            p.animateTo(1f, tween(600, easing = LinearEasing))
        }
    }
    this.drawBehind {
        val x = p.value
        if (x < 1f) {
            val g = 20.dp.toPx() * x
            drawRoundRect(
                color = Sky.copy(alpha = 0.8f * (1f - x)),
                topLeft = Offset(-g, -g),
                size = Size(size.width + g * 2f, size.height + g * 2f),
                cornerRadius = CornerRadius(corner.toPx() + g)
            )
        }
    }
}

