package com.moknight.moplayer

import androidx.compose.animation.Crossfade

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player

private fun modeLabel(m: Int) = when (m) {
    0 -> tr("متتابع", "In order")
    1 -> tr("تكرار الكل", "Repeat all")
    2 -> tr("تكرار واحد", "Repeat one")
    else -> tr("عشوائي", "Shuffle")
}

private fun modeIcon(m: Int): ImageVector = when (m) {
    0 -> Icons.Default.East
    1 -> Icons.Default.Repeat
    2 -> Icons.Default.RepeatOne
    else -> Icons.Default.Shuffle
}

private fun kindIcon(k: Kind): ImageVector = when (k) {
    Kind.NASHEED -> Icons.Default.MusicNote
    Kind.QURAN -> Icons.Default.MenuBook
    Kind.OTHER -> Icons.Default.GridView
}

private val CtlBorder = Color(0xFF22408F)
private val CtlFill = Color(0xCC0A1A55)
private val MutBlue = Color(0xFFB7C6E8)

/** المشغّل الكامل على شكل الصورة: هيدر MoKnight، غلاف بإطار متوهج، شريط رفيع بنقطة، أزرار دائرية، وشريط سفلي. */
@Composable
fun FullPlayer(
    track: Track,
    playing: Boolean,
    progress: Float,
    position: Long,
    duration: Long,
    mode: Int,
    shuffle: Boolean,
    repeat: Int,
    onClose: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onPrev: () -> Unit,
    onSeek: (Float) -> Unit,
    onMode: () -> Unit,
    onShuffle: () -> Unit,
    onRepeat: () -> Unit,
    onKind: (Kind) -> Unit,
    onOptions: () -> Unit,
    onPlayback: () -> Unit,
    playbackDot: Boolean,
    micOk: Boolean,
) {
    BoxWithConstraints(
        Modifier.fillMaxSize().background(Color(0xFF030816))
            .pointerInput(Unit) { detectTapGestures { } }
    ) {
        val boxW = maxWidth
        val boxH = maxHeight
        val landscape = boxW > boxH * 1.15f
        PlayerBg()
        Box(Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0x14030816), Color(0x88030816)))
        ))

        val cover: @Composable (Dp) -> Unit = { s -> CoverFrame(track, s, playing, onOptions) }

        if (landscape) {
            val coverSize = minOf(boxW * 0.34f, boxH - 90.dp, 360.dp).coerceAtLeast(120.dp)
            Row(
                Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.weight(1f).fillMaxHeight().staggerIn(1, 50, 140, 26.dp, 0.97f, 420), contentAlignment = Alignment.Center) { cover(coverSize) }
                Spacer(Modifier.width(18.dp))
                Column(
                    Modifier.weight(1.2f).fillMaxHeight().verticalScroll(rememberScrollState()),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    TopBar(onClose, onOptions)
                    PlayerPanel(track, playing, progress, position, duration, mode, onToggle, onNext, onPrev, onSeek, onMode, onPlayback, playbackDot)
                    BottomBar(track.kind, shuffle, repeat, onShuffle, onRepeat, onKind)
                }
            }
        } else {
            Column(
                Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
                    .padding(horizontal = 22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                TopBar(onClose, onOptions)
                Spacer(Modifier.weight(1f))
                val coverSize = minOf(boxW - 44.dp, boxH * 0.38f, 340.dp).coerceAtLeast(120.dp)
                Box(Modifier.staggerIn(1, 50, 140, 26.dp, 0.97f, 420)) { cover(coverSize) }
                PlayerPanel(track, playing, progress, position, duration, mode, onToggle, onNext, onPrev, onSeek, onMode, onPlayback, playbackDot)
                Spacer(Modifier.weight(0.6f))
                BottomBar(track.kind, shuffle, repeat, onShuffle, onRepeat, onKind)
                Spacer(Modifier.height(12.dp))
            }
        }
    }
}

@Composable
private fun CoverFrame(track: Track, s: Dp, playing: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(34.dp)
    val inf = rememberInfiniteTransition(label = "cf")
    val gp by inf.animateFloat(0.45f, 0.8f, infiniteRepeatable(tween(2800), RepeatMode.Reverse), label = "gp")
    // لما الأغنية تتغيّر الغلاف بيتنطّ نطّة خفيفة
    val swap = remember { androidx.compose.animation.core.Animatable(1f) }
    LaunchedEffect(track.id) {
        swap.snapTo(0f)
        swap.animateTo(1f, tween(520, easing = EaseSeg))
    }
    Box(
        Modifier.size(s)
            .graphicsLayer { val k = 0.93f + 0.07f * swap.value; scaleX = k; scaleY = k }
            .glow(Color(0xFF3D5BFF), 26.dp, 34.dp) { if (playing) gp else 0.45f }
            .clip(shape)
            .background(Color(0xFF0A1448))
            .border(1.5.dp, Brush.linearGradient(listOf(Color(0xFF3D7BFF), Color(0xFF5B3DFF), Color(0xFF8A4BFF))), shape)
            .bounceClick(pressScale = 0.97f, onClick = onClick)
    ) {
        CoverArt(track, s, playing)
    }
}

@Composable
private fun TopBar(onClose: () -> Unit, onOptions: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(top = 8.dp).staggerIn(0, 50, 140, 26.dp, 0.97f, 420),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        // مع اتجاه اللغة: في العربي الإغلاق على اليمين والخيارات على الشمال (زي الصورة)
        TopCircle(Icons.Default.KeyboardArrowDown, tr("إغلاق", "Close"), onClose)
        Text(
            "MoKnight", color = Color(0xFFCFE4FF), fontFamily = Readex, fontWeight = FontWeight.Bold,
            fontSize = 26.sp, maxLines = 1,
            style = TextStyle(shadow = Shadow(Color(0xFF4C8DFF).copy(alpha = 0.8f), blurRadius = 22f))
        )
        TopCircle(Icons.Default.MoreHoriz, tr("خيارات", "Options"), onOptions)
    }
}

@Composable
private fun TopCircle(icon: ImageVector, label: String, onClick: () -> Unit) {
    Box(
        Modifier.size(52.dp)
            .bounceClick(pressScale = 0.9f, onClick = onClick)
            .clip(CircleShape)
            .background(CtlFill)
            .border(1.dp, CtlBorder, CircleShape),
        contentAlignment = Alignment.Center
    ) { Icon(icon, label, tint = Color(0xFFEAF1FF), modifier = Modifier.size(28.dp)) }
}

@Composable
private fun PlayerPanel(
    track: Track, playing: Boolean, progress: Float, position: Long, duration: Long, mode: Int,
    onToggle: () -> Unit, onNext: () -> Unit, onPrev: () -> Unit, onSeek: (Float) -> Unit,
    onMode: () -> Unit, onPlayback: () -> Unit, playbackDot: Boolean,
) {
    var scrub by remember { mutableStateOf<Float?>(null) }
    var burst by remember { mutableIntStateOf(0) }
    val gp by rememberInfiniteTransition(label = "glowp").animateFloat(
        0.55f, 0.9f, infiniteRepeatable(tween(2600, easing = androidx.compose.animation.core.CubicBezierEasing(0.42f, 0f, 0.58f, 1f)), RepeatMode.Reverse), label = "gp"
    )
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        // الاسم والفنان في النص
        Crossfade(targetState = track, animationSpec = tween(300), label = "titles", modifier = Modifier.fillMaxWidth().padding(top = 22.dp).staggerIn(2, 50, 140, 26.dp, 0.97f, 420)) { track ->
        Column(Modifier.fillMaxWidth()) {
            Text(
                track.title, color = Color.White, fontFamily = Readex, fontWeight = FontWeight.Bold,
                fontSize = 24.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                track.artist.ifBlank { kindLabel(track.kind) },
                color = Color(0xFF6F86C9), fontFamily = Readex, fontSize = 17.sp, textAlign = TextAlign.Center,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
            )
        }
        }

        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Column(Modifier.fillMaxWidth().padding(top = 18.dp).staggerIn(3, 50, 140, 26.dp, 0.97f, 420)) {
                SlimSeek(progress = progress, onScrub = { scrub = it }, onSeek = onSeek)
                Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp)) {
                    Text(
                        formatTime(scrub?.let { (duration * it).toLong() } ?: position),
                        color = Color(0xFF7F95CC), fontFamily = Readex, fontSize = 14.sp
                    )
                    Spacer(Modifier.weight(1f))
                    Text(formatTime(duration), color = Color(0xFF7F95CC), fontFamily = Readex, fontSize = 14.sp)
                }
            }

            // الأزرار: الوضع - السابق - تشغيل - التالي - الترس
            Row(
                Modifier.fillMaxWidth().padding(top = 18.dp).staggerIn(4, 50, 140, 26.dp, 0.97f, 420),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                RoundBtn(52.dp, on = mode != 0, onClick = onMode) {
                    Icon(
                        modeIcon(mode), modeLabel(mode),
                        tint = if (mode != 0) Sky else MutBlue,
                        modifier = Modifier.size(24.dp).popi(mode, enabled = mode != 0)
                    )
                }
                RoundBtn(56.dp, on = false, onClick = onPrev) {
                    Icon(Icons.Default.SkipPrevious, tr("السابق", "Previous"), tint = Tx, modifier = Modifier.size(28.dp))
                }
                Box(
                    Modifier.size(80.dp)
                        .burstRing(burst, 1.5f)
                        .glow(Color(0xFF3D6BFF), 22.dp, 40.dp) { if (playing) gp else 0.5f }
                        .bounceClick(pressScale = 0.92f) { burst++; onToggle() }
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(Color(0xFF3D8BFF), Color(0xFF6A3DFF))))
                        .border(1.5.dp, Color(0x66BFD8FF), CircleShape),
                    contentAlignment = Alignment.Center
                ) { PlayPauseIcon(playing, Color.White, 36.dp) }
                RoundBtn(56.dp, on = false, onClick = onNext) {
                    Icon(Icons.Default.SkipNext, tr("التالي", "Next"), tint = Tx, modifier = Modifier.size(28.dp))
                }
                RoundBtn(52.dp, on = false, onClick = onPlayback) {
                    Box {
                        GearIcon(MutBlue, 24.dp, pressed = false)
                        if (playbackDot) Box(Modifier.size(7.dp).align(Alignment.TopEnd).clip(CircleShape).background(Sky))
                    }
                }
            }
        }
    }
}

@Composable
private fun RoundBtn(size: Dp, on: Boolean, onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        Modifier.size(size)
            .bounceClick(pressScale = 0.9f, onClick = onClick)
            .then(if (on) Modifier.glow(Color(0xFF3D6BFF), 10.dp, size / 2, 0.45f) else Modifier)
            .clip(CircleShape)
            .background(if (on) Brush.linearGradient(listOf(Color(0xFF1B3FA8), Color(0xFF3A2A9C))) else Brush.linearGradient(listOf(CtlFill, CtlFill)))
            .border(1.dp, if (on) Color(0xFF6A5BFF) else CtlBorder, CircleShape),
        contentAlignment = Alignment.Center
    ) { content() }
}

/** الشريط السفلي: عشوائي، تكرار، واختيار التصنيف (زي الصورة). */
@Composable
private fun BottomBar(
    kind: Kind, shuffle: Boolean, repeat: Int,
    onShuffle: () -> Unit, onRepeat: () -> Unit, onKind: (Kind) -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(30.dp)
    Row(
        Modifier.fillMaxWidth().padding(top = 18.dp)
            .staggerIn(5, 50, 140, 26.dp, 0.97f, 420)
            .clip(shape)
            .background(Color(0xAA081640))
            .border(1.dp, Brush.horizontalGradient(listOf(Color(0xFF2A56D6), Color(0xFF5B3DFF))), shape)
            .padding(horizontal = 8.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        BarMode(Icons.Default.Shuffle, tr("عشوائي", "Shuffle"), shuffle, onShuffle, Modifier.weight(1f))
        BarDivider()
        BarMode(
            if (repeat == Player.REPEAT_MODE_ONE) Icons.Default.RepeatOne else Icons.Default.Repeat,
            tr("تكرار", "Repeat"), repeat != Player.REPEAT_MODE_OFF, onRepeat, Modifier.weight(1f)
        )
        BarDivider()
        Box(Modifier.weight(1.45f), contentAlignment = Alignment.Center) {
            KindChip(kind, menu) { menu = true }
        }
    }
    if (menu) {
        MenuLayer(
            tr("نقل إلى", "Move to"),
            Kind.values().filter { it != kind }.map { k -> MenuEntry(kindLabel(k), kindIcon(k)) { onKind(k) } },
        ) { menu = false }
    }
}

@Composable
private fun BarDivider() {
    Box(Modifier.width(1.dp).height(34.dp).background(Color(0x22FFFFFF)))
}

@Composable
private fun BarMode(icon: ImageVector, label: String, active: Boolean, onClick: () -> Unit, modifier: Modifier) {
    val tint = if (active) Sky else MutBlue
    Column(
        modifier.clip(RoundedCornerShape(20.dp)).bounceClick(pressScale = 0.92f, onClick = onClick).padding(vertical = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(26.dp).popi(active, enabled = active))
        Text(label, color = tint, fontFamily = Readex, fontSize = 13.sp, maxLines = 1, modifier = Modifier.padding(top = 2.dp))
    }
}

@Composable
private fun KindChip(kind: Kind, open: Boolean, onClick: () -> Unit) {
    val rot by animateFloatAsState(if (open) 180f else 0f, tween(300, easing = EaseApk), label = "chev")
    val shape = RoundedCornerShape(22.dp)
    Row(
        Modifier.clip(shape)
            .bounceClick(pressScale = 0.95f, onClick = onClick)
            .background(Color(0xFF0F2A6E))
            .border(1.dp, Color(0xFF2A56D6), shape)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(kindIcon(kind), null, tint = Sky, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(8.dp))
        Text(kindLabel(kind), color = Tx, fontFamily = Readex, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
        Spacer(Modifier.width(6.dp))
        Icon(Icons.Default.KeyboardArrowDown, null, tint = MutBlue, modifier = Modifier.size(20.dp).graphicsLayer { rotationZ = rot })
    }
}
