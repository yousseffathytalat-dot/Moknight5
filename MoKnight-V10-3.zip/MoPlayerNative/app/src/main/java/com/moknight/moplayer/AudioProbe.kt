package com.moknight.moplayer

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import java.nio.ByteOrder
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.sqrt

/**
 * تحليل خفيف للصوت نفسه: بيفك حوالي 10 ثواني من نص الملف ويقيس
 * - قوة الإيقاع المنتظم (الأناشيد الملحّنة والإيقاعية)
 * - نسبة الوقفات والصمت (التلاوة والكلام)
 * النتيجة بتتحفظ فمفيش تحليل بيتكرر لنفس الملف.
 */
object AudioProbe {
    private const val FPS = 50          // إطارات الطاقة في الثانية
    private const val WANT_FRAMES = 500 // 10 ثواني
    private val FAILED = Probe(-1f, 0f)

    fun analyze(ctx: Context, t: Track): Probe {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(ctx, t.uri, null)
            var idx = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                val m = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (m.startsWith("audio/")) { idx = i; fmt = f; break }
            }
            if (idx < 0 || fmt == null) return FAILED
            ex.selectTrack(idx)
            val mime = fmt.getString(MediaFormat.KEY_MIME) ?: return FAILED
            val durUs = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) else t.durationMs * 1000L
            val startUs = (durUs * 3 / 10).coerceAtMost((durUs - 14_000_000L).coerceAtLeast(0L)).coerceAtLeast(0L)
            if (startUs > 0) ex.seekTo(startUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC)

            var rate = if (fmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44100
            var ch = if (fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
            val c = MediaCodec.createDecoderByType(mime)
            codec = c
            c.configure(fmt, null, null, 0)
            c.start()

            val env = ArrayList<Float>(WANT_FRAMES + 8)
            val info = MediaCodec.BufferInfo()
            var inDone = false
            var outDone = false
            var acc = 0.0
            var cnt = 0
            var perFrame = (rate * ch / FPS).coerceAtLeast(1)
            val t0 = System.currentTimeMillis()

            while (!outDone && env.size < WANT_FRAMES && System.currentTimeMillis() - t0 < 6000) {
                if (!inDone) {
                    val ii = c.dequeueInputBuffer(5000)
                    if (ii >= 0) {
                        val ib = c.getInputBuffer(ii)
                        val n = if (ib != null) ex.readSampleData(ib, 0) else -1
                        if (n < 0) {
                            c.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            c.queueInputBuffer(ii, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = c.dequeueOutputBuffer(info, 5000)
                if (oi >= 0) {
                    val ob = c.getOutputBuffer(oi)
                    if (ob != null && info.size > 0) {
                        ob.position(info.offset)
                        ob.limit(info.offset + info.size)
                        val sb = ob.order(ByteOrder.nativeOrder()).asShortBuffer()
                        while (sb.hasRemaining()) {
                            val v = sb.get() / 32768.0
                            acc += v * v
                            cnt++
                            if (cnt >= perFrame) {
                                env.add(sqrt(acc / cnt).toFloat())
                                acc = 0.0
                                cnt = 0
                            }
                        }
                    }
                    c.releaseOutputBuffer(oi, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val nf = c.outputFormat
                    if (nf.containsKey(MediaFormat.KEY_SAMPLE_RATE)) rate = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    if (nf.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) ch = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    perFrame = (rate * ch / FPS).coerceAtLeast(1)
                    acc = 0.0
                    cnt = 0
                }
            }
            return features(env)
        } catch (e: Throwable) {
            return FAILED
        } finally {
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            runCatching { ex.release() }
        }
    }

    private fun features(env: List<Float>): Probe {
        if (env.size < 150) return FAILED
        var mx = 0f
        for (v in env) if (v > mx) mx = v
        if (mx < 0.003f) return FAILED

        // نسبة الوقفات: إطارات هادية جدًا بالنسبة لأعلى طاقة
        val thr = mx * 0.04f
        var quiet = 0
        for (v in env) if (v < thr) quiet++
        val pause = quiet.toFloat() / env.size

        // قوة الإيقاع: ارتباط ذاتي لارتفاعات الطاقة (حدود 0.25 - 1.2 ثانية)
        val n = env.size
        val nov = FloatArray(n)
        for (i in 1 until n) {
            val d = ln(env[i] + 1e-4f) - ln(env[i - 1] + 1e-4f)
            nov[i] = max(0f, d)
        }
        var mean = 0f
        for (v in nov) mean += v
        mean /= n
        for (i in 0 until n) nov[i] -= mean
        var ac0 = 0f
        for (v in nov) ac0 += v * v
        if (ac0 <= 1e-6f) return Probe(0f, pause)
        var best = 0f
        for (lag in 12..60) {
            var s = 0f
            for (i in lag until n) s += nov[i] * nov[i - lag]
            val r = s / ac0
            if (r > best) best = r
        }
        return Probe(best.coerceIn(0f, 1f), pause)
    }
}
