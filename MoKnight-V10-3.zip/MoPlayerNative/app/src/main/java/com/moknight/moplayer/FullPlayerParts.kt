package com.moknight.moplayer

import android.graphics.Bitmap
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

private const val TWO_PI = (2.0 * PI).toFloat()

/**
 * غلاف المشغّل الكامل: لو الملف الصوتي له صورة بتظهر هي، ولو مفيش بتظهر الصورة الافتراضية
 * (ليل ومسجد وهلال وفقاعة النوتة).
 */
@Composable
fun CoverArt(track: Track, size: Dp, playing: Boolean) {
    val ctx = LocalContext.current
    // null = لسه بيحمّل، Pair(false, null) = مفيش صورة، Pair(true, bmp) = في صورة
    val state by produceState<Pair<Boolean, Bitmap?>?>(null, track.id) {
        value = null
        val b = withContext(Dispatchers.IO) { ArtLoader.load(ctx, track, 900) }
        value = Pair(b != null, b)
    }
    Crossfade(targetState = state, animationSpec = tween(350), label = "cover") { s ->
        when {
            s == null -> Box(Modifier.fillMaxSize().background(Color(0xFF0A1448)))
            s.first && s.second != null -> Image(
                s.second!!.asImageBitmap(), null,
                contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
            )
            else -> DefaultCover(size, playing)
        }
    }
}

/** الغلاف الافتراضي زي الصورة: سماء ليلية بنجوم، هلال، مسجد ونخل، وفقاعة نوتة بموجات جنبها. */
@Composable
fun DefaultCover(size: Dp, playing: Boolean) {
    val inf = rememberInfiniteTransition(label = "dc")
    val tS = inf.animateFloat(0f, 1f, infiniteRepeatable(tween(3200, easing = LinearEasing)), label = "t")
    val glowS = inf.animateFloat(0.7f, 1f, infiniteRepeatable(tween(2600, easing = androidx.compose.animation.core.FastOutSlowInEasing), androidx.compose.animation.core.RepeatMode.Reverse), label = "g")
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val t = tS.value
            val w = this.size.width
            val h = this.size.height
            // السماء
            drawRect(
                Brush.verticalGradient(
                    listOf(Color(0xFF040A2C), Color(0xFF14196B), Color(0xFF3A1E8C), Color(0xFF7B3AA8), Color(0xFFB04E9A)),
                    startY = 0f, endY = h
                )
            )
            // نجوم
            for (i in 0 until 46) {
                val sx = ((i * 7919) % 1000) / 1000f
                val sy = ((i * 104729 + 31) % 1000) / 1000f * 0.62f
                val ph = ((i * 37) % 100) / 100f
                val tw = 0.5f + 0.5f * sin(TWO_PI * (t + ph))
                drawCircle(
                    Color(0xFFDCE6FF).copy(alpha = 0.18f + 0.6f * tw),
                    (if (i % 6 == 0) 1.7f else 1f) * density,
                    Offset(sx * w, sy * h)
                )
            }
            // الهلال
            val mc = Offset(w * 0.73f, h * 0.17f)
            val mr = w * 0.065f
            drawCircle(
                Brush.radialGradient(listOf(Color(0x66A7C8FF), Color.Transparent), center = mc, radius = mr * 3.2f),
                mr * 3.2f, mc
            )
            val a = Path().apply { addOval(Rect(mc, mr)) }
            val b = Path().apply { addOval(Rect(Offset(mc.x + mr * 0.5f, mc.y - mr * 0.2f), mr * 0.92f)) }
            drawPath(Path.combine(PathOperation.Difference, a, b), Color(0xFFBFD8FF))

            // فقاعة النوتة في النص
            val bc = Offset(w * 0.5f, h * 0.5f)
            val br = w * 0.2f
            drawCircle(
                Brush.radialGradient(listOf(Color(0x33B8A8FF), Color(0x146A7CFF)), center = bc, radius = br),
                br, bc
            )
            drawCircle(Color(0x886F86FF).copy(alpha = 0.55f * glowS.value + 0.2f), br, bc, style = Stroke(2.dp.toPx()))

            // أعمدة الصوت جنب الفقاعة
            val fr = floatArrayOf(0.38f, 0.78f, 1f, 0.62f, 0.3f)
            for (side in intArrayOf(-1, 1)) {
                for (i in fr.indices) {
                    val x = bc.x + side * (br + w * 0.045f + i * w * 0.038f)
                    val amp = if (playing) 0.7f + 0.3f * sin(TWO_PI * (t * 2f) + i * 1.2f + (if (side > 0) 1.5f else 0f)) else 0.85f
                    val bh = h * 0.2f * fr[i] * amp
                    val al = 1f - i * 0.17f
                    drawLine(
                        Brush.verticalGradient(listOf(Color(0xFF7FA6FF).copy(alpha = al), Color(0xFF9A6BFF).copy(alpha = al)), startY = bc.y - bh / 2, endY = bc.y + bh / 2),
                        Offset(x, bc.y - bh / 2), Offset(x, bc.y + bh / 2),
                        strokeWidth = 3.2f * density, cap = StrokeCap.Round
                    )
                }
            }

            drawSkyline(w, h)
        }
        Icon(
            Icons.Default.MusicNote, null, tint = Color(0xFFEDE6FF),
            modifier = Modifier.size(size * 0.24f)
        )
    }
}

private fun DrawScope.drawMinaret(cx: Float, mw: Float, top: Float, baseY: Float, c: Color) {
    val bodyTop = top + mw * 1.8f
    drawRect(c, Offset(cx - mw / 2, bodyTop), Size(mw, baseY - bodyTop))
    drawRect(c, Offset(cx - mw * 0.85f, bodyTop + mw * 1.2f), Size(mw * 1.7f, mw * 0.4f))
    val cap = Path().apply {
        moveTo(cx - mw * 0.75f, bodyTop + mw * 0.2f)
        quadraticBezierTo(cx - mw * 0.6f, top + mw * 0.7f, cx, top)
        quadraticBezierTo(cx + mw * 0.6f, top + mw * 0.7f, cx + mw * 0.75f, bodyTop + mw * 0.2f)
        close()
    }
    drawPath(cap, c)
}

private fun DrawScope.drawDome(cx: Float, r: Float, y: Float, baseY: Float, c: Color) {
    drawCircle(c, r, Offset(cx, y))
    drawRect(c, Offset(cx - r, y), Size(r * 2, baseY - y))
    drawLine(c, Offset(cx, y - r), Offset(cx, y - r * 1.35f), strokeWidth = r * 0.07f)
    drawCircle(c, r * 0.1f, Offset(cx, y - r * 1.4f))
}

private fun DrawScope.drawPalm(x: Float, baseY: Float, hgt: Float, lean: Float, c: Color) {
    val top = Offset(x + lean * hgt, baseY - hgt)
    val trunk = Path().apply {
        moveTo(x, baseY)
        quadraticBezierTo(x + lean * hgt * 0.1f, baseY - hgt * 0.6f, top.x, top.y)
    }
    drawPath(trunk, c, style = Stroke(hgt * 0.035f, cap = StrokeCap.Round))
    val len = hgt * 0.42f
    for (k in 0 until 7) {
        val ang = (-160f + k * 50f) * (PI.toFloat() / 180f)
        val dx = cos(ang) * len
        val dy = sin(ang) * len * 0.55f
        val f = Path().apply {
            moveTo(top.x, top.y)
            quadraticBezierTo(top.x + dx * 0.55f, top.y + dy - len * 0.35f, top.x + dx, top.y + dy + len * 0.28f)
        }
        drawPath(f, c, style = Stroke(hgt * 0.04f, cap = StrokeCap.Round))
    }
}

private fun DrawScope.drawSkyline(w: Float, h: Float) {
    val base = h
    val back = Color(0xFF1A1360)
    val front = Color(0xFF070824)
    // الطبقة الخلفية
    drawMinaret(w * 0.14f, w * 0.03f, h * 0.55f, base, back)
    drawMinaret(w * 0.60f, w * 0.03f, h * 0.60f, base, back)
    drawMinaret(w * 0.90f, w * 0.03f, h * 0.58f, base, back)
    // الأمامية
    drawRect(front, Offset(w * 0.22f, h * 0.86f), Size(w * 0.56f, h * 0.14f))
    drawDome(w * 0.5f, w * 0.115f, h * 0.80f, base, front)
    drawDome(w * 0.34f, w * 0.06f, h * 0.84f, base, front)
    drawDome(w * 0.66f, w * 0.06f, h * 0.84f, base, front)
    drawMinaret(w * 0.20f, w * 0.036f, h * 0.60f, base, front)
    drawMinaret(w * 0.27f, w * 0.03f, h * 0.68f, base, front)
    drawMinaret(w * 0.73f, w * 0.03f, h * 0.68f, base, front)
    drawMinaret(w * 0.805f, w * 0.036f, h * 0.55f, base, front)
    // نخل وشجر
    drawPalm(w * 0.06f, base, h * 0.32f, 0.05f, front)
    drawPalm(w * 0.12f, base, h * 0.22f, -0.04f, front)
    drawPalm(w * 0.94f, base, h * 0.30f, -0.05f, front)
    drawPalm(w * 0.88f, base, h * 0.2f, 0.04f, front)
    for (i in 0..14) drawCircle(front, h * (0.04f + 0.015f * (i % 3)), Offset(w * i / 14f, base))
}

/** شريط التقدم الرفيع بالنقطة المتوهجة (زي الصورة). */
@Composable
fun SlimSeek(
    progress: Float,
    onScrub: (Float?) -> Unit,
    onSeek: (Float) -> Unit,
    modifier: Modifier = Modifier,
) {
    var scrub by remember { mutableStateOf<Float?>(null) }
    val k by animateFloatAsState(if (scrub != null) 1f else 0f, tween(220, easing = EaseApk), label = "knob")
    Canvas(
        modifier
            .fillMaxWidth()
            .height(34.dp)
            .pointerInput(Unit) {
                detectTapGestures { o -> onSeek((o.x / size.width).coerceIn(0f, 1f)) }
            }
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { o -> val f = (o.x / size.width).coerceIn(0f, 1f); scrub = f; onScrub(f) },
                    onDragEnd = { scrub?.let(onSeek); scrub = null; onScrub(null) },
                    onDragCancel = { scrub = null; onScrub(null) },
                    onDrag = { c, _ ->
                        val f = (c.position.x / size.width).coerceIn(0f, 1f)
                        scrub = f; onScrub(f)
                    }
                )
            }
    ) {
        val w = size.width
        val cy = size.height / 2f
        val th = 6.dp.toPx()
        val pad = 10.dp.toPx()
        val tw = w - pad * 2
        val p = (scrub ?: progress).coerceIn(0f, 1f)
        val px = pad + tw * p
        drawRoundRect(Color(0xFF1B2F6E), Offset(pad, cy - th / 2), Size(tw, th), androidx.compose.ui.geometry.CornerRadius(th))
        if (px > pad) {
            drawRoundRect(
                Brush.horizontalGradient(listOf(Color(0xFF2F6BFF), Color(0xFF39B2FF), Color(0xFF7FD4FF)), startX = pad, endX = px.coerceAtLeast(pad + 1f)),
                Offset(pad, cy - th / 2), Size(px - pad, th), androidx.compose.ui.geometry.CornerRadius(th)
            )
        }
        val kr = (8f + 3f * k).dp.toPx()
        drawCircle(
            Brush.radialGradient(listOf(Color(0x884CB8FF), Color.Transparent), center = Offset(px, cy), radius = kr * 2.4f),
            kr * 2.4f, Offset(px, cy)
        )
        drawCircle(Color(0xFFBFE8FF), kr, Offset(px, cy))
        drawCircle(Color(0xFF7FD4FF), kr, Offset(px, cy), style = Stroke(1.5.dp.toPx()))
    }
}
