package com.moknight.moplayer

import android.graphics.Bitmap
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val MiniShape = RoundedCornerShape(30.dp)
private val MiniBorder = Brush.linearGradient(listOf(Color(0xFF3F7BFF), Color(0xFF7A4BFF)))
private val ArtViolet = Color(0xFF9DB0FF)

/**
 * المشغّل المصغّر بنفس شكل المشغّل الكامل: كارت كحلي بإطار متدرج أزرق-بنفسجي وتوهج بينبض وقت التشغيل،
 * غلاف مدوّر (صورة الملف أو الغلاف الافتراضي بالمسجد والهلال)، الاسم والفنان، أزرار دائرية بحدود زرقا،
 * وزر تشغيل متدرج متوهج، وشريط تقدّم رفيع بنقطة متوهجة تحت.
 */
@Composable
fun MiniPlayer(
    track: Track, playing: Boolean, idle: Boolean, progress: Float,
    onToggle: () -> Unit, onNext: () -> Unit, onPrev: () -> Unit, onOpen: () -> Unit,
    modifier: Modifier = Modifier,
    onSeek: ((Float) -> Unit)? = null,
) {
    var burst by remember { mutableIntStateOf(0) }
    val appear = remember { Animatable(0f) }
    LaunchedEffect(Unit) { appear.animateTo(1f, tween(500, easing = EaseApk)) }

    val inf = rememberInfiniteTransition(label = "mini")
    val pulse by inf.animateFloat(
        0.45f, 1f,
        infiniteRepeatable(tween(1900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse"
    )
    val glowA = if (playing) pulse * 0.5f else 0.22f

    val status = when {
        idle -> tr("آخر ما شغّلته", "Last played")
        playing -> tr("يتم التشغيل الآن", "Now playing")
        else -> tr("متوقف مؤقتًا", "Paused")
    }

    Column(
        modifier
            .widthIn(max = 720.dp)
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 14.dp, vertical = 10.dp)
            .graphicsLayer {
                translationY = (1f - appear.value) * 90.dp.toPx()
                alpha = appear.value.coerceIn(0f, 1f)
            }
            .glow(Blue, 20.dp, 30.dp) { glowA }
            .clip(MiniShape)
            .background(
                Brush.verticalGradient(listOf(Color(0xFF0A1B52), Color(0xFF061340), Color(0xFF050F33)))
            )
            .border(1.2.dp, MiniBorder, MiniShape)
            .bounceClick(pressScale = 0.985f, onClick = onOpen)
    ) {
        Row(
            Modifier.padding(start = 12.dp, end = 12.dp, top = 12.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            MiniCover(track, playing)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(status, color = ArtViolet, fontFamily = Readex, fontSize = 11.sp, maxLines = 1)
                    if (playing) {
                        Spacer(Modifier.width(6.dp))
                        EqBars(on = true, modifier = Modifier.width(14.dp).height(12.dp))
                    }
                }
                Text(
                    track.title, color = Color.White, fontFamily = Readex, fontWeight = FontWeight.Bold,
                    fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text(
                    track.artist.ifBlank { kindLabel(track.kind) }, color = ArtViolet.copy(alpha = 0.8f),
                    fontFamily = Readex, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    MiniRound(Modifier, 40, onPrev) {
                        Icon(Icons.Default.SkipPrevious, tr("السابق", "Previous"), tint = Color.White, modifier = Modifier.size(22.dp))
                    }
                    Spacer(Modifier.width(7.dp))
                    Box(
                        Modifier.size(52.dp)
                            .burstRing(burst, 1.4f)
                            .glow(Blue, 12.dp, 26.dp) { 0.35f + 0.3f * (if (playing) pulse else 0.4f) }
                            .bounceClick(pressScale = 0.9f) { burst++; onToggle() }
                            .clip(CircleShape)
                            .background(Brush.linearGradient(listOf(Color(0xFF2F8BFF), Color(0xFF6A3DFF))))
                            .border(1.2.dp, Color(0x669DB8FF), CircleShape),
                        contentAlignment = Alignment.Center
                    ) { PlayPauseIcon(playing, Color.White, 28.dp) }
                    Spacer(Modifier.width(7.dp))
                    MiniRound(Modifier, 40, onNext) {
                        Icon(Icons.Default.SkipNext, tr("التالي", "Next"), tint = Color.White, modifier = Modifier.size(22.dp))
                    }
                }
            }
        }
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            MiniProgress(progress, onSeek, Modifier.padding(start = 16.dp, end = 16.dp, bottom = 6.dp))
        }
    }
}

/** زر دائري بحدود زرقا زي أزرار المشغّل الكامل. */
@Composable
private fun MiniRound(modifier: Modifier, dp: Int, onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        modifier
            .size(dp.dp)
            .bounceClick(pressScale = 0.86f, onClick = onClick)
            .clip(CircleShape)
            .background(Color(0xFF0A1C58))
            .border(1.dp, Color(0xFF2A4FC4), CircleShape),
        contentAlignment = Alignment.Center
    ) { content() }
}

/** غلاف صغير: صورة الملف لو موجودة، وإلا الغلاف الافتراضي (ليل ومسجد وهلال) بتلاشي ناعم. */
@Composable
private fun MiniCover(track: Track, playing: Boolean) {
    val ctx = LocalContext.current
    val state by produceState<Pair<Boolean, Bitmap?>?>(null, track.id) {
        value = null
        val b = withContext(Dispatchers.IO) { ArtLoader.load(ctx, track, 220) }
        value = Pair(b != null, b)
    }
    val cs = RoundedCornerShape(20.dp)
    Box(
        Modifier.size(58.dp)
            .clip(cs)
            .background(Color(0xFF0A1448))
            .border(1.dp, MiniBorder, cs)
    ) {
        Crossfade(targetState = state, animationSpec = tween(350), label = "miniCover") { s ->
            when {
                s == null -> Box(Modifier.fillMaxSize())
                s.first && s.second != null -> Image(
                    s.second!!.asImageBitmap(), null,
                    contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
                )
                else -> DefaultCover(58.dp, playing)
            }
        }
    }
}

/** شريط تقدّم رفيع بتدرج أزرق ونقطة متوهجة. بالضغط على أي مكان فيه بينتقل (لو في onSeek). */
@Composable
private fun MiniProgress(progress: Float, onSeek: ((Float) -> Unit)?, modifier: Modifier = Modifier) {
    val p = progress.coerceIn(0f, 1f)
    Canvas(
        modifier
            .fillMaxWidth()
            .height(18.dp)
            .pointerInput(onSeek) {
                if (onSeek != null) detectTapGestures { o -> onSeek((o.x / size.width).coerceIn(0f, 1f)) }
            }
    ) {
        val cy = size.height / 2f
        val th = 4.dp.toPx()
        val pad = 6.dp.toPx()
        val tw = size.width - pad * 2
        val px = pad + tw * p
        drawRoundRect(Color(0xFF1B2F6E), Offset(pad, cy - th / 2), Size(tw, th), CornerRadius(th))
        if (px > pad + 1f) {
            drawRoundRect(
                Brush.horizontalGradient(
                    listOf(Color(0xFF2F6BFF), Color(0xFF39B2FF), Color(0xFF7FD4FF)),
                    startX = pad, endX = px
                ),
                Offset(pad, cy - th / 2), Size(px - pad, th), CornerRadius(th)
            )
        }
        val kr = 5.5f.dp.toPx()
        drawCircle(
            Brush.radialGradient(listOf(Color(0x884CB8FF), Color.Transparent), center = Offset(px, cy), radius = kr * 2.6f),
            kr * 2.6f, Offset(px, cy)
        )
        drawCircle(Color(0xFFBFE8FF), kr, Offset(px, cy))
        drawCircle(Color(0xFF7FD4FF), kr, Offset(px, cy), style = Stroke(1.2.dp.toPx()))
    }
}
