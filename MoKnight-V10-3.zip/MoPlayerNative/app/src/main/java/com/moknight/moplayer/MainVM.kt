package com.moknight.moplayer

import android.app.Application
import android.content.ComponentName
import android.os.Bundle
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainVM(app: Application) : AndroidViewModel(app) {
    private val _tracks = MutableStateFlow<List<Track>>(emptyList())
    val tracks: StateFlow<List<Track>> = _tracks

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading

    private val _current = MutableStateFlow<Track?>(null)
    val current: StateFlow<Track?> = _current

    private val _playing = MutableStateFlow(false)
    val playing: StateFlow<Boolean> = _playing

    private val _progress = MutableStateFlow(0f)
    val progress: StateFlow<Float> = _progress

    private val _position = MutableStateFlow(0L)
    val position: StateFlow<Long> = _position

    private val _duration = MutableStateFlow(0L)
    val duration: StateFlow<Long> = _duration

    private val _shuffle = MutableStateFlow(false)
    val shuffle: StateFlow<Boolean> = _shuffle

    private val _repeat = MutableStateFlow(Player.REPEAT_MODE_OFF)
    val repeat: StateFlow<Int> = _repeat

    private val store = Store(app)
    private var raw: List<Track> = emptyList()

    private val _boost = MutableStateFlow(store.boost)
    val boost: StateFlow<Int> = _boost

    private val _speed = MutableStateFlow(store.speed)
    val speed: StateFlow<Float> = _speed

    private val _sleepLeft = MutableStateFlow(0L)
    val sleepLeft: StateFlow<Long> = _sleepLeft
    private var sleepEnd = 0L

    /** آخر أغنية اتشغلت (بتظهر في المشغّل المصغّر حتى لو التطبيق اتقفل واتفتح). */
    private val _last = MutableStateFlow<Track?>(null)
    val last: StateFlow<Track?> = _last

    /** التصنيف المختار (أناشيد / قرآن / أخرى). */
    private val _cat = MutableStateFlow(kindOf(store.cat) ?: Kind.NASHEED)
    val cat: StateFlow<Kind> = _cat

    private val _playlists = MutableStateFlow(store.playlists)
    val playlists: StateFlow<List<Playlist>> = _playlists

    private var controller: MediaController? = null

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _playing.value = isPlaying
            if (!isPlaying) savePos()
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            syncCurrent()
        }

        override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
            _shuffle.value = shuffleModeEnabled
        }

        override fun onRepeatModeChanged(repeatMode: Int) {
            _repeat.value = repeatMode
        }
    }

    init {
        val ctx = getApplication<Application>()
        val token = SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))
        val future = MediaController.Builder(ctx, token).buildAsync()
        future.addListener({
            controller = future.get().also {
                it.addListener(listener)
                _playing.value = it.isPlaying
                _shuffle.value = it.shuffleModeEnabled
                _repeat.value = it.repeatMode
                it.setPlaybackSpeed(store.speed)
                sendBoost(it, store.boost)
                syncCurrent()
            }
        }, ContextCompat.getMainExecutor(ctx))

        viewModelScope.launch {
            var tick = 0
            while (isActive) {
                val c = controller
                if (c != null && c.mediaItemCount > 0) {
                    val d = if (c.duration > 0) c.duration else (_current.value?.durationMs ?: 0L)
                    val p = c.currentPosition.coerceAtLeast(0L)
                    _duration.value = d
                    _position.value = p
                    _progress.value = if (d > 0) (p.toFloat() / d).coerceIn(0f, 1f) else 0f
                    if (c.isPlaying && ++tick % 7 == 0) savePos()
                } else {
                    // مفيش حاجة مشغلة: اعرض موضع آخر أغنية اتشغلت
                    _last.value?.let { l ->
                        val lp = store.lastPos
                        _duration.value = l.durationMs
                        _position.value = lp
                        _progress.value = if (l.durationMs > 0) (lp.toFloat() / l.durationMs).coerceIn(0f, 1f) else 0f
                    }
                }
                if (sleepEnd > 0) {
                    val left = sleepEnd - System.currentTimeMillis()
                    if (left <= 0) {
                        controller?.pause()
                        sleepEnd = 0
                        _sleepLeft.value = 0
                    } else {
                        _sleepLeft.value = left
                    }
                }
                delay(300)
            }
        }
    }

    private fun syncCurrent() {
        val id = controller?.currentMediaItem?.mediaId?.toLongOrNull()
        _current.value = if (id == null) null else _tracks.value.firstOrNull { it.id == id }
        _current.value?.let {
            if (store.lastId != it.id) {
                store.lastId = it.id
                store.lastPos = 0L
            }
            _last.value = it
        }
    }

    /** يحفظ آخر أغنية وموضعها. */
    private fun savePos() {
        val c = controller ?: return
        val id = c.currentMediaItem?.mediaId?.toLongOrNull() ?: return
        store.lastId = id
        store.lastPos = c.currentPosition.coerceAtLeast(0L)
    }

    fun scan() {
        if (_loading.value) return
        _loading.value = true
        viewModelScope.launch {
            val list = withContext(Dispatchers.IO) {
                runCatching { MusicRepository.scan(getApplication()) }.getOrDefault(emptyList())
            }
            raw = list
            rebuild()
            _loading.value = false
            startProbe()
        }
    }

    /** ريفريش كامل: يمسح كاش الأغلفة ويعيد مسح الجهاز. */
    fun refreshAll() {
        ArtLoader.clear()
        scan()
    }

    private var needProbe: List<Track> = emptyList()
    private var probeJob: Job? = null

    /** تحليل الصوت للملفات اللي الاسم والجيران ما حسموش تصنيفها (في الخلفية، ومرة واحدة لكل ملف). */
    private fun startProbe() {
        val todo = needProbe.filter { store.probes[it.id] == null }
        if (todo.isEmpty() || probeJob?.isActive == true) return
        probeJob = viewModelScope.launch {
            var n = 0
            for (t in todo) {
                if (store.probes[t.id] != null) continue
                val p = withContext(Dispatchers.Default) { AudioProbe.analyze(getApplication(), t) }
                store.probes[t.id] = p
                n++
                if (n % 20 == 0) { store.save(); rebuild() }
            }
            store.save()
            rebuild()
        }
    }

    /** يطبّق التصنيف والتعديلات والإخفاء على نتيجة المسح. */
    private fun rebuild() {
        val vis = raw.filter { it.id !in store.hidden }
        val manual = HashMap<Long, Kind>()
        store.kinds.forEach { (id, name) -> kindOf(name)?.let { manual[id] = it } }
        val res = Classifier.resolve(vis, store.probes, manual)
        needProbe = res.needProbe
        _tracks.value = vis.map { t ->
            val m = store.overrides[t.id]
            val k = res.kinds[t.id] ?: Kind.OTHER
            if (m == null) t.copy(kind = k)
            else t.copy(title = m.title.ifBlank { t.title }, artist = m.artist, kind = k)
        }
        _last.value = _tracks.value.firstOrNull { it.id == store.lastId }
        syncCurrent()
    }

    private fun commitLists() {
        store.save()
        _playlists.value = store.playlists
    }

    fun createPlaylist(name: String, ids: List<Long>) {
        val id = System.currentTimeMillis()
        store.playlists = store.playlists + Playlist(id, name.trim().ifBlank { "قائمة جديدة" }, ids.distinct())
        commitLists()
    }

    fun renamePlaylist(id: Long, name: String) {
        store.playlists = store.playlists.map { if (it.id == id) it.copy(name = name.trim().ifBlank { it.name }) else it }
        commitLists()
    }

    fun deletePlaylist(id: Long) {
        store.playlists = store.playlists.filter { it.id != id }
        commitLists()
    }

    fun addToPlaylist(id: Long, ids: List<Long>) {
        store.playlists = store.playlists.map {
            if (it.id == id) it.copy(ids = (it.ids + ids).distinct()) else it
        }
        commitLists()
    }

    fun removeFromPlaylist(id: Long, ids: Set<Long>) {
        store.playlists = store.playlists.map {
            if (it.id == id) it.copy(ids = it.ids.filter { x -> x !in ids }) else it
        }
        commitLists()
    }

    fun editTrack(id: Long, title: String, artist: String) {
        store.overrides = store.overrides + (id to Meta(title.trim(), artist.trim()))
        store.save()
        rebuild()
    }

    /** نقل ملفات لتصنيف تاني يدوي. */
    fun setKind(ids: Collection<Long>, kind: Kind) {
        store.kinds = store.kinds + ids.associateWith { kind.name }
        store.save()
        rebuild()
    }

    fun setCat(k: Kind) {
        _cat.value = k
        store.cat = k.name
    }

    /** يشغل آخر أغنية اتشغلت من آخر موضع وقفت عنده، في نفس قائمة تصنيفها. */
    fun playLast() {
        val c = controller ?: return
        val t = _last.value ?: return
        val list = _tracks.value.filter { it.isRecording == t.isRecording && (t.isRecording || it.kind == t.kind) }
            .ifEmpty { listOf(t) }
        val idx = list.indexOfFirst { it.id == t.id }.coerceAtLeast(0)
        c.shuffleModeEnabled = false
        val pos = if (t.durationMs > 0 && store.lastPos >= t.durationMs - 2000) 0L else store.lastPos
        c.setMediaItems(list.map { it.toMediaItem() }, idx, pos)
        c.prepare()
        c.play()
    }

    /** إخفاء من التطبيق فقط، الملفات نفسها بتفضل على التليفون. */
    fun hide(ids: Collection<Long>) {
        store.hidden = store.hidden + ids
        store.save()
        rebuild()
    }

    /** بيشغل [list] من أول العنصر رقم [index]. */
    fun playFrom(list: List<Track>, index: Int) {
        val c = controller ?: return
        c.shuffleModeEnabled = false
        c.setMediaItems(list.map { it.toMediaItem() }, index, 0L)
        c.prepare()
        c.play()
    }

    /** تشغيل القائمة كلها بترتيب عشوائي. */
    fun playShuffled(list: List<Track>) {
        val c = controller ?: return
        if (list.isEmpty()) return
        c.setMediaItems(list.map { it.toMediaItem() }, list.indices.random(), 0L)
        c.shuffleModeEnabled = true
        c.prepare()
        c.play()
    }

    fun toggle() {
        val c = controller ?: return
        if (c.mediaItemCount == 0) { playLast(); return }
        if (c.isPlaying) c.pause() else c.play()
    }

    fun next() { controller?.seekToNext() }
    fun prev() { controller?.seekToPrevious() }

    fun seekToFraction(f: Float) {
        val c = controller ?: return
        val d = _duration.value
        if (d > 0) c.seekTo((d * f.coerceIn(0f, 1f)).toLong())
    }

    private fun sendBoost(c: MediaController, pct: Int) {
        val args = Bundle().apply { putInt("pct", pct) }
        c.sendCustomCommand(SessionCommand(PlaybackService.CMD_BOOST, Bundle.EMPTY), args)
    }

    fun setBoost(pct: Int) {
        val v = pct.coerceIn(100, 300)
        store.boost = v
        _boost.value = v
        controller?.let { sendBoost(it, v) }
    }

    fun setSpeed(r: Float) {
        store.speed = r
        _speed.value = r
        controller?.setPlaybackSpeed(r)
    }

    /** مؤقت النوم بالدقايق، 0 يعني إيقاف المؤقت. */
    fun setSleep(minutes: Int) {
        sleepEnd = if (minutes <= 0) 0L else System.currentTimeMillis() + minutes * 60_000L
        _sleepLeft.value = if (minutes <= 0) 0L else minutes * 60_000L
    }

    fun setFont(key: String) {
        store.font = key
        AppFont.key = key
    }

    fun setLang(en: Boolean) {
        store.lang = if (en) "en" else "ar"
        Lang.en = en
    }

    fun toggleShuffle() {
        val c = controller ?: return
        c.shuffleModeEnabled = !c.shuffleModeEnabled
    }

    /** أوضاع التشغيل زي الـ APK: 0 متتابع، 1 تكرار الكل، 2 تكرار واحد، 3 عشوائي. */
    fun cycleMode() {
        val c = controller ?: return
        val cur = when {
            c.shuffleModeEnabled -> 3
            c.repeatMode == Player.REPEAT_MODE_ALL -> 1
            c.repeatMode == Player.REPEAT_MODE_ONE -> 2
            else -> 0
        }
        when ((cur + 1) % 4) {
            0 -> { c.shuffleModeEnabled = false; c.repeatMode = Player.REPEAT_MODE_OFF }
            1 -> { c.shuffleModeEnabled = false; c.repeatMode = Player.REPEAT_MODE_ALL }
            2 -> { c.shuffleModeEnabled = false; c.repeatMode = Player.REPEAT_MODE_ONE }
            else -> { c.shuffleModeEnabled = true; c.repeatMode = Player.REPEAT_MODE_ALL }
        }
    }

    fun cycleRepeat() {
        val c = controller ?: return
        c.repeatMode = when (c.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    override fun onCleared() {
        savePos()
        controller?.removeListener(listener)
        controller?.release()
        controller = null
        super.onCleared()
    }
}
