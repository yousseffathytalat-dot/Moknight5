package com.moknight.moplayer

import android.app.PendingIntent
import android.content.Intent
import android.media.audiofx.LoudnessEnhancer
import android.os.Bundle
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionResult
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import kotlin.math.log10
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue

/** رقم جلسة الصوت، بيستخدمه المؤثر المرئي. */
object AudioBus {
    var sessionId by mutableIntStateOf(0)
}

/** خدمة التشغيل: صوت في الخلفية + إشعار + رفع الصوت لحد 300%. */
class PlaybackService : MediaSessionService() {
    companion object {
        const val CMD_BOOST = "moplayer.boost"
    }

    private var session: MediaSession? = null
    private var enhancer: LoudnessEnhancer? = null
    private var boostPct = 100

    private fun applyBoost(e: LoudnessEnhancer) {
        if (boostPct <= 100) {
            e.setEnabled(false)
        } else {
            e.setTargetGain((2000.0 * log10(boostPct / 100.0)).toInt())
            e.setEnabled(true)
        }
    }

    private fun rebuildEnhancer(sessionId: Int) {
        runCatching {
            enhancer?.release()
            enhancer = null
            if (sessionId != 0) {
                enhancer = LoudnessEnhancer(sessionId).also { applyBoost(it) }
            }
        }
    }

    private val callback = object : MediaSession.Callback {
        override fun onConnect(
            session: MediaSession,
            controller: MediaSession.ControllerInfo
        ): MediaSession.ConnectionResult {
            val cmds = MediaSession.ConnectionResult.DEFAULT_SESSION_COMMANDS.buildUpon()
                .add(SessionCommand(CMD_BOOST, Bundle.EMPTY))
                .build()
            return MediaSession.ConnectionResult.AcceptedResultBuilder(session)
                .setAvailableSessionCommands(cmds)
                .build()
        }

        override fun onCustomCommand(
            session: MediaSession,
            controller: MediaSession.ControllerInfo,
            customCommand: SessionCommand,
            args: Bundle
        ): ListenableFuture<SessionResult> {
            if (customCommand.customAction == CMD_BOOST) {
                boostPct = args.getInt("pct", 100).coerceIn(100, 300)
                enhancer?.let { runCatching { applyBoost(it) } }
                return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
            }
            return Futures.immediateFuture(SessionResult(SessionResult.RESULT_ERROR_NOT_SUPPORTED))
        }
    }

    override fun onCreate() {
        super.onCreate()
        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .setUsage(C.USAGE_MEDIA)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
        player.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                rebuildEnhancer(audioSessionId)
                AudioBus.sessionId = audioSessionId
            }
        })
        rebuildEnhancer(player.audioSessionId)
        AudioBus.sessionId = player.audioSessionId
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        session = MediaSession.Builder(this, player)
            .setCallback(callback)
            .setSessionActivity(open)
            .build()
    }

    /**
     * لما تشيل التطبيق من الأخيرة: لو في صوت شغال يكمل في الخلفية بإشعار،
     * ولو واقف أو مفيش حاجة مشغلة الخدمة بتقفل. الصوت ما بيقفلش غير بإيدك.
     */
    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) {
            stopSelf()
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onDestroy() {
        AudioBus.sessionId = 0
        runCatching { enhancer?.release() }
        enhancer = null
        session?.run {
            player.release()
            release()
        }
        session = null
        super.onDestroy()
    }
}
