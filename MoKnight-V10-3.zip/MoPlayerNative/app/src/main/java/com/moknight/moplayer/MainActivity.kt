package com.moknight.moplayer

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.layout.layout
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.rounded.AutoStories as RBook
import androidx.compose.material.icons.rounded.FormatListBulleted as RList
import androidx.compose.material.icons.rounded.GridView as RGrid
import androidx.compose.material.icons.rounded.MusicNote as RNote
import androidx.compose.material.icons.rounded.QueueMusic as RQueue
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val st = Store(this)
        AppFont.key = st.font
        Lang.en = st.lang == "en"
        // شريط الحالة (الساعة والبطارية والشبكة) بتاع التليفون نفسه، التطبيق بيرسم تحته من غير ما يرسم حاجة فيه
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        setContent {
            // الواجهة بتتكيّف تلقائيًا مع حجم الشاشة: تليفون صغير، تليفون كبير، تابلت، لابتوب
            val cfg = LocalConfiguration.current
            val k = (minOf(cfg.screenWidthDp, cfg.screenHeightDp) / 400f).coerceIn(0.9f, 1.25f)
            val d = LocalDensity.current
            CompositionLocalProvider(LocalDensity provides Density(d.density * k, d.fontScale)) {
                MaterialTheme(
                    colorScheme = darkColorScheme(primary = Blue, background = Bg0, surface = Navy2, onSurface = Tx),
                ) {
                    CompositionLocalProvider(LocalLayoutDirection provides (if (Lang.en) LayoutDirection.Ltr else LayoutDirection.Rtl)) {
                        App()
                    }
                }
            }
        }
    }
}

private fun tabLabels() = listOf(tr("المكتبة", "Library"), tr("التسجيلات", "Recordings"), tr("القوائم", "Playlists"))

private fun kindEmptyMsg(k: Kind) = when (k) {
    Kind.NASHEED -> tr("مفيش أناشيد اتلقت على التليفون.", "No nasheeds found on this phone.")
    Kind.QURAN -> tr("مفيش قرآن اتلقى على التليفون.", "No Quran audio found on this phone.")
    Kind.OTHER -> tr("مفيش ملفات تانية اتلقت.", "No other audio files found.")
}

private fun kindCountText(k: Kind, n: Int) = when (k) {
    Kind.NASHEED -> tr("$n أنشودة", "$n nasheeds")
    Kind.QURAN -> tr("$n ملف قرآن", "$n Quran files")
    Kind.OTHER -> tr("$n ملف", "$n files")
}

private class RowActions(
    val menu: (Track) -> Unit,
)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun App(vm: MainVM = viewModel()) {
    val ctx = LocalContext.current
    val tracks by vm.tracks.collectAsState()
    val loading by vm.loading.collectAsState()
    val current by vm.current.collectAsState()
    val last by vm.last.collectAsState()
    val playing by vm.playing.collectAsState()
    val playlists by vm.playlists.collectAsState()
    val cat by vm.cat.collectAsState()

    val perms = remember {
        if (Build.VERSION.SDK_INT >= 33)
            arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
        else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    }
    fun hasAudio() = ContextCompat.checkSelfPermission(ctx, perms[0]) == PackageManager.PERMISSION_GRANTED
    var granted by remember { mutableStateOf(hasAudio()) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = hasAudio()
        if (granted) vm.scan()
    }
    LaunchedEffect(Unit) {
        if (granted) vm.scan() else launcher.launch(perms)
    }

    var tab by remember { mutableIntStateOf(0) }
    var openId by remember { mutableStateOf<Long?>(null) }
    var sel by remember { mutableStateOf(setOf<Long>()) }
    var dlg by remember { mutableStateOf<Dlg?>(null) }
    var query by remember { mutableStateOf("") }
    var showFull by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()

    var micOk by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
    }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { micOk = it }
    LaunchedEffect(showFull) {
        val prefs = ctx.getSharedPreferences("moplayer", android.content.Context.MODE_PRIVATE)
        if (showFull && !micOk && !prefs.getBoolean("asked_mic", false)) {
            prefs.edit().putBoolean("asked_mic", true).apply()
            micLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    val openPl = openId?.let { id -> playlists.firstOrNull { it.id == id } }
    val inListsRoot = tab == 2 && openPl == null

    val base = remember(tracks, tab, openPl, cat) {
        when {
            tab == 0 -> tracks.filter { !it.isRecording && it.kind == cat }
            tab == 1 -> tracks.filter { it.isRecording }
            openPl != null -> {
                val m = tracks.associateBy { it.id }
                openPl.ids.mapNotNull { m[it] }
            }
            else -> emptyList()
        }
    }
    val shown = remember(base, query) {
        val q = query.trim()
        if (q.isEmpty()) base
        else base.filter { it.title.contains(q, true) || it.artist.contains(q, true) || it.album.contains(q, true) }
    }

    // لما تغيّر التبويب أو التصنيف أو تفتح قائمة، ارجع لأول القايمة
    LaunchedEffect(tab, cat, openId) { listState.scrollToItem(0) }

    // زر الرجوع: آخر واحد متسجل له الأولوية
    BackHandler(enabled = openPl != null) { openId = null; sel = emptySet() }
    BackHandler(enabled = sel.isNotEmpty()) { sel = emptySet() }
    BackHandler(enabled = showFull) { showFull = false }

    fun toast(s: String) = Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()

    // آخر حاجة اتشغلت بتفضل ظاهرة تحت حتى لو مفيش حاجة شغالة دلوقتي
    val miniTrack = current ?: last
    val bottomPad = if (miniTrack != null) 132.dp else 28.dp

    val rowActions = remember { RowActions(menu = { dlg = Dlg.TrackMenu(it, false) }) }

    // تقدّم التمرير (0..1) بيتحكم في تصغير الهيدر
    val scrollP = remember {
        derivedStateOf {
            if (listState.firstVisibleItemIndex > 0) 1f
            else (listState.firstVisibleItemScrollOffset / 170f).coerceIn(0f, 1f)
        }
    }

    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .background(AppBg)
    ) {
        val cols = when {
            maxWidth >= 900.dp -> 3
            maxWidth >= 600.dp -> 2
            else -> 1
        }
        val hPad = if (maxWidth >= 600.dp) 24.dp else 14.dp

        LivingBg(playing = playing)

        val full = Modifier.fillMaxWidth()

        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            // ---------- الهيدر: لير واحد ثابت فوق (MoKnight + التبويبات) ----------
            if (sel.isNotEmpty()) {
                SubHeader(hPad, { scrollP.value }) {
                    IconButton(onClick = { sel = emptySet() }) { Icon(Icons.Default.Close, tr("إلغاء", "Cancel"), tint = Tx) }
                    Text(tr("${sel.size} محدد", "${sel.size} selected"), color = Tx, fontFamily = Readex, fontSize = 16.sp, modifier = Modifier.weight(1f))
                    IconButton(onClick = { sel = shown.map { it.id }.toSet() }) { Icon(Icons.Default.SelectAll, tr("الكل", "All"), tint = Sky) }
                    if (sel.size == 1) IconButton(onClick = {
                        tracks.firstOrNull { it.id == sel.first() }?.let { dlg = Dlg.Edit(it) }
                    }) { Icon(Icons.Default.Edit, tr("تعديل", "Edit"), tint = Sky) }
                    IconButton(onClick = { dlg = Dlg.Move(sel.toList()) }) { Icon(Icons.Default.Category, tr("نقل إلى", "Move to"), tint = Sky) }
                    IconButton(onClick = { dlg = Dlg.Pick(sel.toList()) }) { Icon(Icons.Default.PlaylistAdd, tr("إضافة لقائمة", "Add to playlist"), tint = Sky) }
                    IconButton(onClick = {
                        if (openPl != null) {
                            vm.removeFromPlaylist(openPl.id, sel); sel = emptySet()
                        } else dlg = Dlg.ConfirmHide(sel.toList())
                    }) { Icon(Icons.Default.Delete, tr("حذف", "Delete"), tint = Color(0xFFFF6B6B)) }
                }
            } else if (openPl != null) {
                SubHeader(hPad, { scrollP.value }) {
                    IconButton(onClick = { openId = null }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, tr("رجوع", "Back"), tint = Tx) }
                    Text(
                        openPl.name, color = Tx, fontFamily = Readex, fontWeight = FontWeight.Bold,
                        fontSize = 22.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    GearButton { dlg = Dlg.AppSettings }
                }
            } else {
                // الترتيب بيمشي مع اتجاه اللغة: في العربي الشعار على اليمين والزرارين على الشمال (زي الصورة)
                MainHeader(
                    hPad, { scrollP.value }, tab,
                    onTab = { i -> tab = i; sel = emptySet(); query = ""; openId = null },
                    onGear = { dlg = Dlg.AppSettings },
                    onPlus = { dlg = Dlg.Plus },
                )
            }

            // ---------- المحتوى ----------
            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(bottom = bottomPad),
            ) {
                // التصنيفات بتطلع لفوق مع التمرير
                if (openPl == null && tab == 0) item(key = "cats") {
                    CategoryRow(cat, hPad) { k -> vm.setCat(k); sel = emptySet(); query = "" }
                }
                if (!inListsRoot) {
                    if (loading) item(key = "scanning") {
                        Text(
                            tr("بيمسح الجهاز…", "Scanning device…"), color = Mut, fontFamily = Readex, fontSize = 13.sp,
                            modifier = Modifier.padding(horizontal = hPad + 8.dp, vertical = 4.dp).staggerIn(0)
                        )
                    }
                    // البحث + التشغيل المتتابع + العشوائي في كارت واحد زي الصورة، وبيثبت تحت الهيدر
                    stickyHeader(key = "search") {
                        Box(
                            full.background(
                                Brush.verticalGradient(listOf(Bg0.copy(alpha = 0.97f), Bg0.copy(alpha = 0.85f), Color.Transparent))
                            )
                        ) {
                            SearchCard(
                                hPad, query, shown.isNotEmpty(),
                                onQuery = { query = it },
                                onSequential = { vm.playFrom(shown, 0) },
                                onShuffle = { vm.playShuffled(shown) },
                            )
                        }
                    }
                } else {
                    item(key = "vtitle_l") {
                        VTitle(tr("القوائم", "Playlists"), tr("${playlists.size} قائمة", "${playlists.size} playlists"), hPad)
                    }
                }

                when {
                    !granted -> item(key = "perm") {
                        Empty(tr("محتاج إذن الوصول للصوتيات عشان أعرض ملفاتك.", "Audio access permission is needed to show your files."), tr("إعطاء الإذن", "Grant permission")) { launcher.launch(perms) }
                    }

                    inListsRoot -> {
                        item(key = "lists_head") {
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = hPad + 6.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(tr("${playlists.size} قائمة", "${playlists.size} playlists"), color = Mut, fontFamily = Readex, fontSize = 13.sp, modifier = Modifier.weight(1f))
                                GradientButton(tr("قائمة جديدة", "New playlist"), Icons.Default.Add) { dlg = Dlg.NewList(emptyList()) }
                            }
                        }
                        if (playlists.isEmpty()) item(key = "lists_empty") {
                            Text(
                                tr("مفيش قوائم لسه. اعمل واحدة وضيف لها ملفات.", "No playlists yet. Create one and add files."),
                                color = Mut, fontFamily = Readex, fontSize = 14.sp,
                                modifier = Modifier.padding(24.dp)
                            )
                        }
                        itemsIndexed(playlists.chunked(cols), key = { _, r -> "pl_${r.first().id}" }) { ri, row ->
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = hPad),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                row.forEachIndexed { ci, p ->
                                    Box(Modifier.weight(1f)) {
                                        PlaylistRow(
                                            p, ri * cols + ci,
                                            onOpen = { openId = p.id; query = "" },
                                            onMenu = { dlg = Dlg.ListMenu(p) },
                                        )
                                    }
                                }
                                repeat(cols - row.size) { Spacer(Modifier.weight(1f)) }
                            }
                        }
                    }

                    !loading && shown.isEmpty() -> item(key = "empty") {
                        val msg = when {
                            query.isNotBlank() -> tr("مفيش نتايج للبحث.", "No search results.")
                            openPl != null -> tr("القائمة فاضية. حدد ملفات من المكتبة وضيفها هنا.", "Playlist is empty. Select files from the library and add them here.")
                            tab == 1 -> tr("مفيش تسجيلات اتلقت.", "No recordings found.")
                            else -> kindEmptyMsg(cat)
                        }
                        Empty(msg, tr("مسح تاني", "Scan again")) { vm.scan() }
                    }

                    else -> itemsIndexed(shown.chunked(cols), key = { _, r -> "tr_${r.first().id}" }) { ri, row ->
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = hPad),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            row.forEachIndexed { ci, t ->
                                val idx = ri * cols + ci
                                Box(Modifier.weight(1f)) {
                                    TrackRow(
                                        t = t,
                                        index = idx,
                                        active = t.id == current?.id,
                                        playing = playing,
                                        selected = t.id in sel,
                                        actions = rowActions,
                                        onClick = {
                                            if (sel.isNotEmpty()) sel = if (t.id in sel) sel - t.id else sel + t.id
                                            else vm.playFrom(shown, idx)
                                        },
                                        onLong = { sel = if (t.id in sel) sel - t.id else sel + t.id },
                                    )
                                }
                            }
                            repeat(cols - row.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                }
            }
        }

        // ---------- المشغّل المصغّر: آخر حاجة اتشغلت ----------
        miniTrack?.let { t ->
            MiniHost(
                vm = vm, track = t, playing = playing, idle = current == null,
                onOpen = {
                    if (current == null) vm.playLast()
                    showFull = true
                },
                modifier = Modifier.align(Alignment.BottomCenter)
            )
        }

        // ---------- المشغّل الكامل ----------
        AnimatedVisibility(
            visible = showFull && current != null,
            enter = slideInVertically(tween(520, easing = EaseSheet)) { (it * 0.3f).toInt() } +
                scaleIn(tween(520, easing = EaseSheet), initialScale = 0.9f, transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0.5f, 1f)) +
                fadeIn(tween(320)),
            exit = slideOutVertically(tween(420, easing = EaseSheet)) { (it * 0.3f).toInt() } +
                scaleOut(tween(420, easing = EaseSheet), targetScale = 0.9f, transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0.5f, 1f)) +
                fadeOut(tween(280)),
        ) {
            current?.let { t ->
                FullHost(
                    vm, t, playing, micOk,
                    onClose = { showFull = false },
                    onOptions = { dlg = Dlg.TrackMenu(t, true) },
                    onPlayback = { dlg = Dlg.Playback },
                )
            }
        }
    }

    // ---------- الطبقات والحوارات ----------
    when (val d = dlg) {
        null -> {}
        is Dlg.AppSettings -> SettingsLayer(
            vm,
            onRescan = { if (granted) vm.scan() else launcher.launch(perms) },
            onRefresh = {
                vm.refreshAll()
                toast(tr("اتعمل ريفريش. الأيقونات بتتحمل…", "Refreshed. Loading icons…"))
            },
            onDismiss = { dlg = null },
        )
        is Dlg.Playback -> PlaybackLayer(vm) { dlg = null }
        is Dlg.Plus -> MenuLayer(
            tr("إضافة", "Add"),
            listOf(
                MenuEntry(tr("قائمة جديدة", "New playlist"), Icons.Default.QueueMusic) { dlg = Dlg.NewList(emptyList()) },
                MenuEntry(tr("تحديث المكتبة", "Refresh library"), Icons.Default.Refresh) { if (granted) vm.scan() else launcher.launch(perms) },
            ),
        ) { dlg = null }
        is Dlg.TrackMenu -> {
            val t = d.t
            val entries = buildList {
                if (!d.fromPlayer) {
                    add(MenuEntry(tr("تشغيل", "Play"), Icons.Default.PlayArrow) {
                        val i = shown.indexOfFirst { it.id == t.id }
                        if (i >= 0) vm.playFrom(shown, i) else vm.playFrom(listOf(t), 0)
                    })
                }
                add(MenuEntry(tr("إضافة إلى قائمة", "Add to playlist"), Icons.Default.PlaylistAdd) { dlg = Dlg.Pick(listOf(t.id)) })
                add(MenuEntry(tr("تعديل الاسم والتصنيف", "Edit name & category"), Icons.Default.Edit) { dlg = Dlg.Edit(t) })
                if (!d.fromPlayer) {
                    add(MenuEntry(tr("تحديد", "Select"), Icons.Default.CheckCircle) { sel = sel + t.id })
                }
                Kind.values().filter { it != t.kind }.forEach { k ->
                    add(MenuEntry(tr("نقل إلى ${kindLabel(k)}", "Move to ${kindLabel(k)}"), Icons.Default.Category) {
                        vm.setKind(listOf(t.id), k)
                        toast(tr("اتنقلت إلى ${kindLabel(k)}", "Moved to ${kindLabel(k)}"))
                    })
                }
                add(MenuEntry(tr("إخفاء من التطبيق", "Hide from app"), Icons.Default.Delete, danger = true) { dlg = Dlg.ConfirmHide(listOf(t.id)) })
            }
            MenuLayer(t.title, entries) { dlg = null }
        }
        is Dlg.ListMenu -> MenuLayer(
            d.p.name,
            listOf(
                MenuEntry(tr("تغيير الاسم", "Rename"), Icons.Default.Edit) { dlg = Dlg.Rename(d.p) },
                MenuEntry(tr("حذف القائمة", "Delete playlist"), Icons.Default.Delete, danger = true) { dlg = Dlg.DeleteList(d.p) },
            ),
        ) { dlg = null }
        is Dlg.Move -> MenuLayer(
            tr("نقل إلى", "Move to"),
            Kind.values().map { k ->
                MenuEntry(kindLabel(k), Icons.Default.Category) {
                    vm.setKind(d.ids, k)
                    toast(tr("اتنقل ${d.ids.size} إلى ${kindLabel(k)}", "Moved ${d.ids.size} to ${kindLabel(k)}"))
                    sel = emptySet()
                }
            },
        ) { dlg = null }
        is Dlg.NewList -> NameDialog(tr("قائمة جديدة", "New playlist"), "", tr("إنشاء", "Create"), { dlg = null }) { name ->
            vm.createPlaylist(name, d.add)
            if (d.add.isNotEmpty()) toast(tr("اتضافت ${d.add.size} للقائمة", "${d.add.size} added to playlist"))
            sel = emptySet(); dlg = null
        }
        is Dlg.Rename -> NameDialog(tr("اسم القائمة", "Playlist name"), d.pl.name, tr("حفظ", "Save"), { dlg = null }) { name ->
            vm.renamePlaylist(d.pl.id, name); dlg = null
        }
        is Dlg.DeleteList -> ConfirmDialog(
            tr("حذف القائمة", "Delete playlist"), tr("هتتحذف القائمة \"${d.pl.name}\" بس، والملفات هتفضل زي ما هي.", "Only the playlist \"${d.pl.name}\" will be deleted; files stay as they are."), tr("حذف", "Delete"), { dlg = null }
        ) { vm.deletePlaylist(d.pl.id); dlg = null }
        is Dlg.Pick -> PickListDialog(
            playlists, { dlg = null },
            onPick = { p -> vm.addToPlaylist(p.id, d.ids); toast(tr("اتضاف لـ ${p.name}", "Added to ${p.name}")); sel = emptySet(); dlg = null },
            onNew = { dlg = Dlg.NewList(d.ids) },
        )
        is Dlg.Edit -> EditDialog(d.t, { dlg = null }) { title, artist, kind ->
            vm.editTrack(d.t.id, title, artist)
            if (kind != d.t.kind) vm.setKind(listOf(d.t.id), kind)
            sel = emptySet(); dlg = null
        }
        is Dlg.ConfirmHide -> ConfirmDialog(
            tr("إخفاء ${d.ids.size} من التطبيق", "Hide ${d.ids.size} from app"),
            tr("الملفات هتختفي من MoPlayer بس، والملفات نفسها هتفضل على التليفون.", "Files will be hidden from MoPlayer only; they stay on the phone."), tr("إخفاء", "Hide"), { dlg = null }
        ) { vm.hide(d.ids); sel = emptySet(); dlg = null }
    }
}

// =====================================================================
//  الهيدر: لير واحد (MoKnight + المكتبة/التسجيلات/القوائم) زي الـ APK
// =====================================================================

/** لوجو icon.svg بتاع الـ APK: مربع غامق بحدود زرقاء وحرف M متدرج. */
@Composable
private fun ApkLogo(size: Dp) {
    val sh = RoundedCornerShape(size * 0.25f)
    Box(
        Modifier
            .size(size)
            .clip(sh)
            .background(Brush.linearGradient(listOf(Color(0xFF0E1F58), Color(0xFF050B24))))
            .border(1.dp, Color(0xFF4B6BFF).copy(alpha = 0.45f), sh)
            .drawBehind {
                val w = this.size.width
                val p = androidx.compose.ui.graphics.Path().apply {
                    moveTo(w * 15f / 64f, w * 47f / 64f)
                    lineTo(w * 15f / 64f, w * 17f / 64f)
                    lineTo(w * 32f / 64f, w * 38f / 64f)
                    lineTo(w * 49f / 64f, w * 17f / 64f)
                    lineTo(w * 49f / 64f, w * 47f / 64f)
                }
                drawPath(
                    p,
                    Brush.linearGradient(listOf(Color(0xFF7FB4FF), Color(0xFF6A5CFF))),
                    style = androidx.compose.ui.graphics.drawscope.Stroke(
                        width = w * 7f / 64f,
                        cap = androidx.compose.ui.graphics.StrokeCap.Round,
                        join = androidx.compose.ui.graphics.StrokeJoin.Round,
                    )
                )
            }
    )
}

private val HeaderShape = RoundedCornerShape(30.dp)

/** غلاف الهيدر: بيثبت فوق وبيصغر بنعومة مع التمرير (المساحة بتصغر معاه). */
@Composable
private fun HeaderShell(hPad: Dp, scaleP: () -> Float, content: @Composable ColumnScope.() -> Unit) {
    val enter = remember { androidx.compose.animation.core.Animatable(0f) }
    LaunchedEffect(Unit) { enter.animateTo(1f, tween(700, easing = EaseApk)) }
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = hPad, vertical = 8.dp)
            .graphicsLayer {
                val s = 0.95f + 0.05f * enter.value
                scaleX = s
                scaleY = s
                alpha = enter.value
                transformOrigin = TransformOrigin(0.5f, 0f)
            }
            .glow(Blue, 16.dp, 30.dp, 0.22f)
            .clip(HeaderShape)
            .background(Brush.horizontalGradient(listOf(Color(0xFF040E34).copy(alpha = 0.94f), Color(0xFF071452).copy(alpha = 0.94f))))
            .border(1.dp, Brush.horizontalGradient(listOf(Color(0xFF2F6BFF).copy(alpha = 0.5f), Color(0xFF6A3DFF).copy(alpha = 0.42f))), HeaderShape)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        content = content
    )
}

/** الهيدر الرئيسي: كارت فيه الشعار + MoKnight + ترس + إضافة، وتحته شريط التبويبات (زي الصورة). */
@Composable
private fun MainHeader(
    hPad: Dp, scaleP: () -> Float, tab: Int, onTab: (Int) -> Unit,
    onGear: () -> Unit, onPlus: () -> Unit,
) {
    Column {
        HeaderShell(hPad, scaleP) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ApkLogo(46.dp)
                Spacer(Modifier.width(12.dp))
                Text(
                    "MoKnight", color = Color.White, fontFamily = Readex,
                    fontWeight = FontWeight.ExtraBold, fontSize = 26.sp, maxLines = 1,
                    style = TextStyle(shadow = Shadow(Color(0xFF4C96FF).copy(alpha = 0.75f), blurRadius = 24f)),
                    modifier = Modifier.weight(1f)
                )
                GearButton(onGear)
                Spacer(Modifier.width(10.dp))
                PlusButton(onPlus)
            }
        }
        SegTabs(tab, onTab, hPad)
    }
}

/** الترس: بيلف 60° وهو مضغوط وبيرجع (زي :active في الـ APK). */
@Composable
private fun GearButton(onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    Box(
        Modifier
            .size(46.dp)
            .bounceClick(pressScale = 0.92f, interaction = src, onClick = onClick)
            .clip(CircleShape)
            .background(Color(0x22071A55))
            .border(1.dp, Color(0x552F6BFF), CircleShape),
        contentAlignment = Alignment.Center
    ) { GearIcon(Color(0xFFEAF0FF), 24.dp, pressed = pressed, deg = 60f) }
}

/** زر الإضافة: بيلف 90° وهو مضغوط. */
@Composable
private fun PlusButton(onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val r by animateFloatAsState(if (pressed) 90f else 0f, tween(500, easing = EaseApk), label = "plus")
    Box(
        Modifier
            .size(54.dp)
            .glow(Blue, 12.dp, 27.dp, 0.55f)
            .bounceClick(pressScale = 0.92f, interaction = src, onClick = onClick)
            .clip(CircleShape)
            .background(Brush.linearGradient(listOf(Color(0xFF2F8BFF), Violet))),
        contentAlignment = Alignment.Center
    ) { Icon(Icons.Default.Add, tr("إضافة", "Add"), tint = Color.White, modifier = Modifier.size(30.dp).graphicsLayer { rotationZ = r }) }
}

/** هيدر ثانوي (تحديد / داخل قائمة): نفس الغلاف بصف واحد. */
@Composable
private fun SubHeader(hPad: Dp, scaleP: () -> Float, content: @Composable RowScope.() -> Unit) {
    HeaderShell(hPad, scaleP) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, content = content)
    }
}

/** شريط التبويبات: أيقونة + اسم، والمؤشر المتدرج بينزلق بين التبويبات وفيه توهج، وفواصل رفيعة بين غير المحدد. */
@Composable
private fun SegTabs(tab: Int, onTab: (Int) -> Unit, hPad: Dp) {
    val bar = RoundedCornerShape(26.dp)
    val pill = RoundedCornerShape(22.dp)
    val pos by animateFloatAsState(tab.toFloat(), tween(450, easing = EaseSeg), label = "tabpos")
    val icons = listOf(RBook, RList, RBook)
    BoxWithConstraints(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = hPad, vertical = 4.dp)
            .clip(bar)
            .background(Color(0xE6040E34))
            .border(1.dp, Color(0x442F6BFF), bar)
            .padding(5.dp)
    ) {
        val segW = maxWidth / 3
        Box(
            Modifier
                .offset(x = segW * pos)
                .width(segW)
                .height(46.dp)
                .glow(Blue, 12.dp, 23.dp, 0.55f)
                .clip(pill)
                .background(Brush.horizontalGradient(listOf(Color(0xFF1E8BFF), Color(0xFF5B3DFF))))
                .border(1.dp, Color(0x66FFFFFF), pill)
        )
        Row(Modifier.fillMaxWidth()) {
            tabLabels().forEachIndexed { i, label ->
                val on = tab == i
                Box(
                    Modifier
                        .weight(1f)
                        .height(46.dp)
                        .clip(pill)
                        .bounceClick(pressScale = 0.95f) { onTab(i) },
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            icons[i], null, tint = if (on) Color.White else Color(0xFFB8C6F0),
                            modifier = Modifier.size(22.dp).popi(on, enabled = on)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            label, color = if (on) Color.White else Color(0xFFB8C6F0), fontFamily = Readex,
                            fontWeight = if (on) FontWeight.Bold else FontWeight.Medium,
                            fontSize = 14.sp, maxLines = 1
                        )
                    }
                    if (i < 2 && tab != i && tab != i + 1) {
                        Box(
                            Modifier.align(Alignment.CenterEnd).width(1.dp).height(24.dp)
                                .background(Color.White.copy(alpha = 0.14f))
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun GradientButton(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    val shape = RoundedCornerShape(26.dp)
    Row(
        Modifier
            .glow(Blue, 10.dp, 26.dp, 0.4f)
            .bounceClick(onClick = onClick)
            .clip(shape)
            .background(Brush.horizontalGradient(listOf(Color(0xFF0B6BF9), Color(0xFF3A2BF0))))
            .padding(horizontal = 18.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(6.dp))
        Text(label, color = Color.White, fontFamily = Readex, fontSize = 14.sp)
    }
}

// =====================================================================
//  عنوان القسم + أزرار التصنيف + أزرار التشغيل + البحث
// =====================================================================

/** vtitle: عنوان كبير + العدد + خط متوهج. */
@Composable
private fun VTitle(title: String, count: String, hPad: Dp) {
    Column(Modifier.padding(horizontal = hPad + 6.dp).padding(top = 6.dp, bottom = 6.dp).staggerIn(2)) {
        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                title, color = Color.White, fontFamily = Readex, fontWeight = FontWeight.ExtraBold,
                fontSize = 30.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false)
            )
            Spacer(Modifier.width(10.dp))
            Text(count, color = Mut, fontFamily = Readex, fontSize = 13.sp, modifier = Modifier.padding(bottom = 6.dp), maxLines = 1)
        }
        Box(
            Modifier.padding(top = 6.dp).fillMaxWidth(0.34f).height(3.dp)
                .glow(Sky, 6.dp, 2.dp, 0.7f)
                .clip(CircleShape)
                .background(Brush.horizontalGradient(listOf(Sky, Violet)))
        )
    }
}

private class CatStyle(
    val a: Color, val b: Color, val lineA: Color, val lineB: Color, val tile: Color, val glow: Color, val label: Color,
)

private fun catStyle(k: Kind, selected: Boolean): CatStyle = when (k) {
    Kind.NASHEED ->
        if (selected) CatStyle(Color(0xFF5A2BE0), Color(0xFF2A1FA6), Color(0xFFB39CFF), Color(0xFF2FB4FF), Color(0x55A97BFF), Color(0xFF6A3DFF), Color.White)
        else CatStyle(Color(0xFF241A78), Color(0xFF181156), Color(0xFF5A4BD0), Color(0xFF2A5BD0), Color(0x449B6BFF), Color(0xFF6A3DFF), Color(0xFFD5DCFF))
    Kind.QURAN ->
        if (selected) CatStyle(Color(0xFF0B52C8), Color(0xFF062C86), Color(0xFF6FC4FF), Color(0xFF2F6BFF), Color(0x554CB8FF), Color(0xFF2F8BFF), Color.White)
        else CatStyle(Color(0xFF00266E), Color(0xFF001850), Color(0xFF1E8FE0), Color(0xFF1B4FB0), Color(0xFF0A3F8C), Color(0xFF1E8FE0), Color(0xFFD5DCFF))
    Kind.OTHER ->
        if (selected) CatStyle(Color(0xFF0C7A94), Color(0xFF064A66), Color(0xFF7FE3EE), Color(0xFF1AA3B8), Color(0x554CE0F0), Color(0xFF14A0B0), Color.White)
        else CatStyle(Color(0xFF003B5E), Color(0xFF002A46), Color(0xFF15A0BE), Color(0xFF0B5E7E), Color(0xFF0E6A8E), Color(0xFF14A0B0), Color(0xFFD5DCFF))
}

private fun catIcon(k: Kind) = when (k) {
    Kind.NASHEED -> Icons.Rounded.RNote
    Kind.QURAN -> Icons.Rounded.RBook
    Kind.OTHER -> Icons.Rounded.RGrid
}

@Composable
private fun CategoryRow(cat: Kind, hPad: Dp, onPick: (Kind) -> Unit) {
    Row(
        Modifier.padding(horizontal = hPad, vertical = 6.dp).fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        listOf(Kind.OTHER, Kind.QURAN, Kind.NASHEED).forEachIndexed { i, k ->
            CatButton(k, cat == k, Modifier.weight(1f).staggerIn(i + 1)) { onPick(k) }
        }
    }
}

@Composable
private fun CatButton(kind: Kind, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(28.dp)
    val st = catStyle(kind, selected)
    val lift by animateFloatAsState(if (selected) 1f else 0f, tween(400, easing = EaseApk), label = "lift")
    Row(
        modifier
            .glow(st.glow, 14.dp, 30.dp, 0.15f + 0.5f * lift)
            .bounceClick(onClick = onClick)
            .clip(shape)
            .background(Brush.linearGradient(listOf(st.a, st.b)))
            .border(if (selected) 1.5.dp else 1.dp, Brush.linearGradient(listOf(st.lineA, st.lineB)), shape)
            .padding(horizontal = 7.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            kindLabel(kind), color = st.label,
            fontFamily = Readex, fontSize = 13.sp, softWrap = false, maxLines = 1,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            modifier = Modifier.weight(1f)
        )
        Spacer(Modifier.width(4.dp))
        Box(
            Modifier.size(38.dp).clip(RoundedCornerShape(14.dp)).background(st.tile),
            contentAlignment = Alignment.Center
        ) {
            Icon(catIcon(kind), null, tint = Color(0xFFF2F5FF), modifier = Modifier.size(24.dp).popi(selected, enabled = selected))
        }
    }
}

/** كارت واحد: حقل البحث + تشغيل متتابع + عشوائي (زي الصورة)، والضغطة على الزر بتعمل نبضة تكبير ورجوع. */
@Composable
private fun SearchCard(
    hPad: Dp, query: String, enabled: Boolean,
    onQuery: (String) -> Unit, onSequential: () -> Unit, onShuffle: () -> Unit,
) {
    val card = RoundedCornerShape(28.dp)
    val field = RoundedCornerShape(22.dp)
    Row(
        Modifier
            .padding(horizontal = hPad, vertical = 6.dp)
            .fillMaxWidth()
            .staggerIn(1)
            .glow(Blue, 10.dp, 28.dp, 0.16f)
            .clip(card)
            .background(CardFill.copy(alpha = 0.92f))
            .border(1.dp, CardLine.copy(alpha = 0.8f), card)
            .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            Modifier
                .weight(1f)
                .clip(field)
                .background(FieldFill)
                .border(1.dp, Color(0xFF16307F), field)
                .padding(horizontal = 12.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Search, null, tint = Color(0xFFA78BFF), modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(8.dp))
            Box(Modifier.weight(1f)) {
                if (query.isEmpty()) Text(
                    tr("ابحث في المكتبة...", "Search the library..."), color = Mut, fontFamily = Readex,
                    fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                BasicTextField(
                    value = query,
                    onValueChange = onQuery,
                    singleLine = true,
                    textStyle = TextStyle(color = Tx, fontFamily = Readex, fontSize = 15.sp),
                    cursorBrush = SolidColor(Sky),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            if (query.isNotEmpty()) {
                Icon(
                    Icons.Default.Close, null, tint = Mut,
                    modifier = Modifier.size(20.dp).clip(CircleShape).clickable { onQuery("") }
                )
            }
        }
        BarDivider()
        BarAction(Icons.Default.Repeat, tr("تشغيل متتابع", "Play all"), enabled, onSequential)
        BarDivider()
        BarAction(Icons.Default.Shuffle, tr("عشوائي", "Shuffle"), enabled, onShuffle)
    }
}

@Composable
private fun BarDivider() {
    Box(Modifier.padding(horizontal = 4.dp).width(1.dp).height(40.dp).background(Color.White.copy(alpha = 0.10f)))
}

@Composable
private fun BarAction(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, enabled: Boolean, onClick: () -> Unit) {
    val k = remember { androidx.compose.animation.core.Animatable(0f) }
    var n by remember { mutableIntStateOf(0) }
    LaunchedEffect(n) {
        if (n > 0) {
            k.snapTo(0f)
            k.animateTo(1f, tween(620, easing = EaseApk))
        }
    }
    val c = if (enabled) Color(0xFF8CB4FF) else Mut.copy(alpha = 0.4f)
    Column(
        Modifier
            .graphicsLayer {
                val x = k.value
                val sc = if (x < 0.35f) 1f + 0.16f * (x / 0.35f) else 1.16f - 0.16f * ((x - 0.35f) / 0.65f)
                scaleX = sc; scaleY = sc
            }
            .clip(RoundedCornerShape(16.dp))
            .bounceClick(enabled = enabled, pressScale = 0.92f) { n++; onClick() }
            .padding(horizontal = 6.dp, vertical = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            icon, null, tint = c,
            modifier = Modifier.size(24.dp).graphicsLayer { rotationZ = 360f * k.value }
        )
        Text(label, color = if (enabled) Color(0xFFCFE0FF) else Mut.copy(alpha = 0.4f), fontFamily = Readex, fontSize = 11.5.sp, maxLines = 1)
    }
}

// =====================================================================
//  المحتوى
// =====================================================================

@Composable
private fun MiniHost(vm: MainVM, track: Track, playing: Boolean, idle: Boolean, onOpen: () -> Unit, modifier: Modifier) {
    val progress by vm.progress.collectAsState()
    MiniPlayer(track, playing, idle, progress, vm::toggle, vm::next, vm::prev, onOpen, modifier, onSeek = vm::seekToFraction)
}

@Composable
private fun FullHost(
    vm: MainVM, track: Track, playing: Boolean, micOk: Boolean,
    onClose: () -> Unit, onOptions: () -> Unit, onPlayback: () -> Unit,
) {
    val progress by vm.progress.collectAsState()
    val position by vm.position.collectAsState()
    val duration by vm.duration.collectAsState()
    val shuffle by vm.shuffle.collectAsState()
    val repeat by vm.repeat.collectAsState()
    val speed by vm.speed.collectAsState()
    val sleepLeft by vm.sleepLeft.collectAsState()
    val mode = when {
        shuffle -> 3
        repeat == androidx.media3.common.Player.REPEAT_MODE_ALL -> 1
        repeat == androidx.media3.common.Player.REPEAT_MODE_ONE -> 2
        else -> 0
    }
    FullPlayer(
        track = track, playing = playing, progress = progress, position = position, duration = duration,
        mode = mode, shuffle = shuffle, repeat = repeat, onClose = onClose,
        onToggle = vm::toggle, onNext = vm::next, onPrev = vm::prev, onSeek = vm::seekToFraction,
        onMode = vm::cycleMode, onShuffle = vm::toggleShuffle, onRepeat = vm::cycleRepeat,
        onKind = { k -> vm.setKind(listOf(track.id), k) },
        onOptions = onOptions, onPlayback = onPlayback, playbackDot = speed != 1f || sleepLeft > 0,
        micOk = micOk,
    )
}

@Composable
private fun Empty(msg: String, btn: String, onClick: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(32.dp).staggerIn(0),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(msg, color = Mut, fontFamily = Readex, fontSize = 15.sp)
        Spacer(Modifier.height(16.dp))
        GradientButton(btn, Icons.Default.Refresh, onClick)
    }
}

@Composable
private fun TrackRow(
    t: Track, index: Int, active: Boolean, playing: Boolean, selected: Boolean, actions: RowActions,
    onClick: () -> Unit, onLong: () -> Unit,
) {
    val shape = RoundedCornerShape(28.dp)
    var ring by remember { mutableIntStateOf(0) }
    val gearSrc = remember { MutableInteractionSource() }
    val gearPressed by gearSrc.collectIsPressedAsState()
    val lit = active || selected
    val litA by animateFloatAsState(if (lit) 1f else 0f, tween(450, easing = EaseApk), label = "lit")
    val fill = when {
        selected -> Brush.horizontalGradient(listOf(Blue.copy(alpha = 0.45f), Violet.copy(alpha = 0.35f)))
        active -> Brush.horizontalGradient(listOf(Color(0xFF0B2A7C), Color(0xFF1B1D86)))
        else -> SolidColor(CardFill.copy(alpha = 0.9f))
    }
    val line = if (lit) Brush.horizontalGradient(listOf(Color(0xFF3D8BFF), Color(0xFF7B4DFF)))
    else SolidColor(CardLine.copy(alpha = 0.85f))
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp)
            .staggerIn(index)
            .popRing(ring, 28.dp)
            .glow(if (selected) Sky else Violet, 14.dp, 28.dp, 0.5f * litA)
            .bounceClick(onLong = onLong, pressScale = 0.97f) { ring++; onClick() }
            .clip(shape)
            .background(fill)
            .border(if (lit) 1.5.dp else 1.dp, line, shape)
            .padding(horizontal = 10.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            Icons.Default.KeyboardArrowRight, null, tint = Color(0xFF6F8BE0),
            modifier = Modifier.size(24.dp).graphicsLayer { translationX = 3.dp.toPx() * litA }
        )
        Spacer(Modifier.width(4.dp))
        Art(t, 54.dp, 160, RoundedCornerShape(18.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                t.title, color = if (active) Color.White else Tx, fontFamily = Readex,
                fontWeight = FontWeight.Bold, fontSize = 16.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(3.dp))
            Text(
                "${t.artist.ifBlank { kindLabel(t.kind) }} · ${formatTime(t.durationMs)}",
                color = if (active) Color(0xFF9DB6F0) else Mut, fontFamily = Readex, fontSize = 13.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        if (active) {
            Spacer(Modifier.width(6.dp))
            WaveDeco(on = playing, modifier = Modifier.width(58.dp).height(40.dp))
        }
        // الترس بيلف 70° وهو مضغوط وبيفتح قايمة الملف
        Box(
            Modifier.size(44.dp).clip(CircleShape)
                .bounceClick(pressScale = 0.9f, interaction = gearSrc) { actions.menu(t) },
            contentAlignment = Alignment.Center
        ) { GearIcon(Color(0xFFC3D2FF), 25.dp, pressed = gearPressed, deg = 70f) }
        if (selected) Icon(Icons.Default.CheckCircle, null, tint = Sky, modifier = Modifier.size(24.dp))
    }
}

@Composable
private fun PlaylistRow(p: Playlist, index: Int, onOpen: () -> Unit, onMenu: () -> Unit) {
    val shape = RoundedCornerShape(28.dp)
    val menuSrc = remember { MutableInteractionSource() }
    val menuPressed by menuSrc.collectIsPressedAsState()
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp)
            .staggerIn(index)
            .bounceClick(pressScale = 0.97f, onClick = onOpen)
            .clip(shape)
            .background(CardFill.copy(alpha = 0.88f))
            .border(1.dp, CardLine, shape)
            .padding(horizontal = 12.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(56.dp).clip(RoundedCornerShape(20.dp))
                .background(Brush.linearGradient(listOf(LogoA, LogoB))),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Default.QueueMusic, null, tint = Color.White, modifier = Modifier.size(26.dp)) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(p.name, color = Tx, fontFamily = Readex, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(tr("${p.ids.size} ملف", "${p.ids.size} files"), color = Mut, fontFamily = Readex, fontSize = 13.sp)
        }
        Box(
            Modifier.size(44.dp).clip(CircleShape)
                .bounceClick(pressScale = 0.9f, interaction = menuSrc, onClick = onMenu),
            contentAlignment = Alignment.Center
        ) { GearIcon(Color(0xFF8C9CFF), 24.dp, pressed = menuPressed, deg = 70f) }
    }
}
