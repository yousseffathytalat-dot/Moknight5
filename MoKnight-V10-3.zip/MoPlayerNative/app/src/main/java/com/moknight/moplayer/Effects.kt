package com.moknight.moplayer

import android.graphics.Bitmap
import android.media.audiofx.Visualizer
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.pow
import kotlin.math.sin
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext

private const val TAU = 6.2831855f

/** نجوم صغيرة بتلمع (مواقع ثابتة، لمعان متحرك). */
private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawStars(t: Float, count: Int, maxY: Float, tint: Color) {
    val d = density
    for (i in 0 until count) {
        val sx = ((i * 7919) % 1000) / 1000f
        val sy = ((i * 104729 + 31) % 1000) / 1000f
        val ph = ((i * 37) % 100) / 100f
        val tw = 0.5f + 0.5f * sin(TAU * (t * 2f + ph))
        val a = (0.10f + 0.55f * tw) * (if (i % 5 == 0) 1f else 0.7f)
        val r = (if (i % 7 == 0) 1.5f else 0.9f) * d
        drawCircle(tint.copy(alpha = a), r, Offset(sx * size.width, sy * maxY))
    }
}

/** خطوط موجية ناعمة بتتحرك عند أسفل الشاشة (زي المنحنيات الزرقا اللي في الصور). */
private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawSwooshes(
    t: Float, baseY: Float, c1: Color, c2: Color, strength: Float,
) {
    val w = size.width
    val d = density
    val steps = 28
    for (k in 0 until 3) {
        val amp = (26f + k * 14f) * d
        val y0 = baseY + k * 34f * d
        val ph = t * TAU * (1 + k % 2) * (if (k == 1) -1f else 1f) + k * 1.7f
        val path = Path()
        for (i in 0..steps) {
            val x = w * i / steps
            val y = y0 + amp * sin(TAU * 0.65f * (x / w) + ph) * 0.6f + amp * 0.4f * sin(TAU * 1.3f * (x / w) - ph * 0.7f)
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        val br = Brush.horizontalGradient(
            listOf(Color.Transparent, c1.copy(alpha = 0.85f * strength), c2.copy(alpha = 0.85f * strength), Color.Transparent)
        )
        drawPath(path, br, style = Stroke(width = 9f * d, cap = StrokeCap.Round), alpha = 0.10f)
        drawPath(path, br, style = Stroke(width = 1.6f * d, cap = StrokeCap.Round), alpha = 0.55f - k * 0.12f)
    }
}

/**
 * خلفية التطبيق الحية على شكل الصور: كحلي غامق عميق، هالات زرقا وبنفسجي بتسبح ببطء،
 * نجوم بتلمع من فوق، ومنحنيات ضوئية زرقا بتتموج من تحت.
 */
@Composable
fun LivingBg(modifier: Modifier = Modifier, strength: Float = 1f, playing: Boolean = false) {
    val inf = rememberInfiniteTransition(label = "bg")
    val t by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(26000, easing = LinearEasing)), label = "t")
    val breathe by inf.animateFloat(0.5f, 1f, infiniteRepeatable(tween(4200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "floor")
    Canvas(modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val d = density
        drawRect(Brush.verticalGradient(listOf(Color(0xFF020716), Color(0xFF030C2A), Color(0xFF020A30))))

        fun orb(color: Color, rad: Float, cx: Float, cy: Float) {
            drawCircle(
                brush = Brush.radialGradient(listOf(color.copy(alpha = (color.alpha * strength).coerceIn(0f, 1f)), Color.Transparent), center = Offset(cx, cy), radius = rad),
                radius = rad, center = Offset(cx, cy)
            )
        }
        val a = t * TAU
        // هالة زرقا فوق اليمين، وهالة بنفسجي تحت الشمال، وهالة سماوي في الوسط
        orb(Color(0x551E40FF), w * 0.85f, w * (0.95f + 0.06f * sin(a)), h * (0.10f + 0.03f * cos(a)))
        orb(Color(0x446A3DFF), w * 0.8f, w * (0.05f + 0.07f * cos(a)), h * (0.85f + 0.03f * sin(a)))
        orb(Color(0x331B7BFF), w * 0.7f, w * (0.55f + 0.1f * sin(a + 2f)), h * (0.48f + 0.05f * cos(a + 1f)))

        drawStars(t, 38, h * 0.5f, Color(0xFFBBD2FF))

        // أرضية مضيئة بتتنفس من تحت
        val top = h * 0.72f
        drawRect(
            brush = Brush.verticalGradient(
                listOf(Color.Transparent, Color(0xFF2F6BFF).copy(alpha = (0.30f * breathe * strength).coerceIn(0f, 1f))),
                startY = top, endY = h
            ),
            topLeft = Offset(0f, top), size = Size(w, h - top)
        )
        drawSwooshes(t, h * 0.90f, Color(0xFF2F8BFF), Color(0xFF8A5BFF), strength)
    }
}

/** خلفية المشغّل الكامل: ليل بنفسجي-أزرق زي صورة المشغل، وهلال ضوء، ونجوم، ومنحنيات. */
@Composable
fun PlayerBg(modifier: Modifier = Modifier) {
    val inf = rememberInfiniteTransition(label = "pbg")
    val t by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(28000, easing = LinearEasing)), label = "t")
    val breathe by inf.animateFloat(0.55f, 1f, infiniteRepeatable(tween(5000, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pb")
    Canvas(modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        drawRect(Brush.verticalGradient(listOf(Color(0xFF020716), Color(0xFF040C30), Color(0xFF060A34))))
        val a = t * TAU
        fun orb(color: Color, rad: Float, cx: Float, cy: Float) {
            drawCircle(
                brush = Brush.radialGradient(listOf(color, Color.Transparent), center = Offset(cx, cy), radius = rad),
                radius = rad, center = Offset(cx, cy)
            )
        }
        orb(Color(0x502457E8), w * 0.9f, w * (0.15f + 0.08f * sin(a)), h * 0.10f)
        orb(Color(0x606A3DFF).copy(alpha = 0.38f * breathe), w * 0.95f, w * (0.5f + 0.1f * cos(a)), h * 0.9f)
        orb(Color(0x40B04AD8).copy(alpha = 0.22f * breathe), w * 0.7f, w * (0.9f + 0.05f * sin(a + 1f)), h * 0.62f)
        drawStars(t, 46, h * 0.55f, Color(0xFFC9D6FF))
        drawSwooshes(t, h * 0.92f, Color(0xFF3D8BFF), Color(0xFFA06BFF), 1f)
    }
}

/** زخرفة موجة جنب الأغنية الشغالة في القائمة (شكل الصورة): أعمدة رفيعة بتتراقص وتخفت للأطراف. */
@Composable
fun WaveDeco(on: Boolean, modifier: Modifier = Modifier) {
    val inf = rememberInfiniteTransition(label = "wd")
    val t by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1500, easing = LinearEasing)), label = "t")
    Canvas(modifier) {
        val n = 13
        val step = size.width / n
        val bw = 2.6.dp.toPx()
        val mid = size.height / 2f
        for (i in 0 until n) {
            val c = (n - 1) / 2f
            val env = 1f - abs(i - c) / c * 0.6f
            val wob = if (on) 0.5f + 0.5f * abs(sin(TAU * (t + i * 0.11f))) else 0.4f
            val hh = maxOf(5.dp.toPx(), size.height * env * (0.35f + 0.65f * wob))
            val x = step * (i + 0.5f)
            val col = androidx.compose.ui.graphics.lerp(Color(0xFF6A3DFF), Color(0xFF4CB8FF), i / (n - 1f))
            drawLine(col.copy(alpha = 0.25f + 0.65f * env), Offset(x, mid - hh / 2f), Offset(x, mid + hh / 2f), bw, StrokeCap.Round)
        }
    }
}

/** ثلاث أعمدة (eq) بجانب اسم الملف الشغال، زي الـ APK. */
@Composable
fun EqBars(on: Boolean, modifier: Modifier = Modifier) {
    if (!on) return
    val inf = rememberInfiniteTransition(label = "eq")
    val a by inf.animateFloat(0.3f, 1f, infiniteRepeatable(tween(400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "a")
    val b by inf.animateFloat(0.3f, 1f, infiniteRepeatable(tween(325, delayMillis = 0, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "b")
    val c by inf.animateFloat(0.3f, 1f, infiniteRepeatable(tween(475, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "c")
    Canvas(modifier.width(15.dp).height(16.dp)) {
        val bw = 3.dp.toPx()
        val gap = 3.dp.toPx()
        val full = floatArrayOf(0.55f, 1f, 0.55f)
        val sc = floatArrayOf(a, b, c)
        for (i in 0 until 3) {
            val hh = size.height * full[i] * sc[i]
            val x = i * (bw + gap)
            drawRoundRect(Sky.copy(alpha = 0.3f), Offset(x - 1.5f, size.height - hh - 1.5f), Size(bw + 3f, hh + 3f), CornerRadius(bw))
            drawRoundRect(Sky, Offset(x, size.height - hh), Size(bw, hh), CornerRadius(bw / 2f))
        }
    }
}

/**
 * شريط الموجة (زي #viz في الـ APK): 56 عمود، المتشغل بتدرج أزرق، والباقي رمادي، ومؤشر أبيض متوهج.
 * بتلمس أو تسحب عليه للتنقل في الأغنية. المؤثر حقيقي لو الإذن موجود، وحركة تزيينية لو مفيش.
 */
@Composable
fun SeekViz(
    sessionId: Int, micOk: Boolean, playing: Boolean, progress: Float, seed: Int,
    onScrub: (Float?) -> Unit, onSeek: (Float) -> Unit, modifier: Modifier = Modifier,
) {
    val n = 56
    val bars = remember { FloatArray(n) }
    val env = remember(seed) {
        val e = FloatArray(n)
        var sd = (seed * 37 + 11).toLong().let { if (it < 0) -it else it }
        for (i in 0 until n) {
            sd = (sd * 9301 + 49297) % 233280
            e[i] = 0.4f + 0.6f * (sd / 233280.0).pow(0.8).toFloat()
        }
        for (i in 1 until n - 1) e[i] = (e[i - 1] + e[i] * 2 + e[i + 1]) / 4f
        e
    }
    var frame by remember { mutableIntStateOf(0) }
    var scrub by remember { mutableStateOf<Float?>(null) }

    LaunchedEffect(sessionId, micOk, playing) {
        var viz: Visualizer? = null
        if (micOk && sessionId != 0 && playing) {
            viz = runCatching {
                Visualizer(sessionId).also {
                    it.setCaptureSize(Visualizer.getCaptureSizeRange()[1].coerceAtMost(1024))
                    it.setEnabled(true)
                }
            }.getOrNull()
        }
        val buf = viz?.let { ByteArray(it.captureSize) }
        try {
            var tm = 0f
            while (isActive) {
                val target = FloatArray(n)
                tm += 0.033f
                if (viz != null && buf != null && viz.getFft(buf) == Visualizer.SUCCESS) {
                    val bins = buf.size / 2
                    for (i in 0 until n) {
                        val lo = bins.toDouble().pow(i / n.toDouble()).toInt().coerceAtLeast(1)
                        val hi = bins.toDouble().pow((i + 1) / n.toDouble()).toInt().coerceIn(lo + 1, bins)
                        var mx = 0f
                        for (k in lo until hi) {
                            if (2 * k + 1 < buf.size) mx = maxOf(mx, hypot(buf[2 * k].toFloat(), buf[2 * k + 1].toFloat()))
                        }
                        target[i] = (mx / 110f).coerceIn(0f, 1f).pow(0.6f)
                    }
                } else if (playing) {
                    for (i in 0 until n) {
                        target[i] = (0.22f + 0.5f * abs(sin(tm * 2.3f + i * 0.55f)) * (0.55f + 0.45f * sin(tm * 0.9f + i * 0.2f)))
                    }
                } else {
                    for (i in 0 until n) target[i] = 0.05f + 0.03f * sin(tm * 1.2f + i * 0.45f)
                }
                for (i in 0 until n) bars[i] += (target[i] - bars[i]) * 0.35f
                frame++
                delay(33)
            }
        } finally {
            runCatching { viz?.setEnabled(false); viz?.release() }
        }
    }

    Canvas(
        modifier
            .fillMaxWidth()
            .height(64.dp)
            .pointerInput(Unit) {
                detectTapGestures { o ->
                    val f = (o.x / size.width).coerceIn(0f, 1f)
                    onSeek(f)
                }
            }
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { o -> val f = (o.x / size.width).coerceIn(0f, 1f); scrub = f; onScrub(f) },
                    onDragEnd = { scrub?.let(onSeek); scrub = null; onScrub(null) },
                    onDragCancel = { scrub = null; onScrub(null) },
                    onDrag = { change, _ ->
                        val f = (change.position.x / size.width).coerceIn(0f, 1f)
                        scrub = f
                        onScrub(f)
                    }
                )
            }
    ) {
        @Suppress("UNUSED_VARIABLE") val tick = frame
        val w = size.width
        val h = size.height
        val bw = w / n
        val mid = h / 2f
        val p = (scrub ?: progress).coerceIn(0f, 1f)
        val px = p * w
        val lw = maxOf(2.dp.toPx(), bw * 0.52f)
        fun barH(i: Int) = maxOf(5.dp.toPx(), (0.3f + 0.7f * bars[i]) * env[i] * (h - 10.dp.toPx()))
        val grad = Brush.horizontalGradient(listOf(Color(0xFF1D4ED8), Color(0xFF3D8BFF), Color(0xFF7FD4FF)), startX = 0f, endX = w)
        for (i in 0 until n) {
            val x = i * bw + bw / 2f
            val hh = barH(i)
            if (x > px) drawLine(Color(0x30FFFFFF), Offset(x, mid - hh / 2f), Offset(x, mid + hh / 2f), lw, StrokeCap.Round)
            else drawLine(grad, Offset(x, mid - hh / 2f), Offset(x, mid + hh / 2f), lw, StrokeCap.Round)
        }
        val hx = px.coerceIn(2f, w - 2f)
        val s = scrub != null
        drawRect(Color(0x304CB8FF), Offset(hx - 5.dp.toPx(), 3.dp.toPx()), Size(10.dp.toPx(), h - 6.dp.toPx()))
        drawCircle(Color(0x304CB8FF), (if (s) 13.dp else 11.dp).toPx(), Offset(hx, mid))
        drawRect(Color.White, Offset(hx - 1.25.dp.toPx(), 3.dp.toPx()), Size(2.5.dp.toPx(), h - 6.dp.toPx()))
        drawCircle(Color.White, (if (s) 8.dp else 6.dp).toPx(), Offset(hx, mid))
    }
}
