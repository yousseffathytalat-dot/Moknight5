package com.moknight.moplayer

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.graphics.graphicsLayer
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

/**
 * الطبقة المركزية بالشكل الجديد: كارت كحلي بإطار أزرق-بنفسجي وتوهج بينبض، بتفتح من النص بتكبير ناعم
 * وبتقفل بنعومة (بالضغط برا الكارت أو زر الرجوع)، وخلفيتها بتعتّم تدريجيًا.
 */
@Composable
fun LayerDialog(title: String, onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    val vis = remember { MutableTransitionState(false).apply { targetState = true } }
    val scope = rememberCoroutineScope()
    val close: () -> Unit = {
        if (vis.targetState) {
            vis.targetState = false
            scope.launch { delay(220); onDismiss() }
        }
    }
    Dialog(onDismissRequest = close, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        val dim by animateFloatAsState(if (vis.targetState) 1f else 0f, tween(260, easing = EaseLayer), label = "dim")
        Box(
            Modifier
                .fillMaxSize()
                .background(Color(0xFF020718).copy(alpha = 0.62f * dim))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = close)
                .padding(horizontal = 18.dp, vertical = 24.dp),
            contentAlignment = Alignment.Center
        ) {
            AnimatedVisibility(
                visibleState = vis,
                enter = fadeIn(tween(260, easing = EaseLayer)) + scaleIn(tween(300, easing = EaseLayer), initialScale = 0.9f),
                exit = fadeOut(tween(200)) + scaleOut(tween(200), targetScale = 0.94f),
            ) {
                LayerCard(title, content)
            }
        }
    }
}

@Composable
private fun LayerCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(34.dp)
    val maxH = (LocalConfiguration.current.screenHeightDp * 0.82f).dp
    val gp by rememberInfiniteTransition(label = "lg").animateFloat(
        0.4f, 0.75f, infiniteRepeatable(tween(2600, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "gp"
    )
    Column(
        Modifier
            .widthIn(max = 400.dp)
            .fillMaxWidth()
            .heightIn(max = maxH)
            .glow(Color(0xFF3D5BFF), 28.dp, 34.dp) { gp }
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0xFF0B1E58), Color(0xFF061340), Color(0xFF040C2E))))
            .border(1.2.dp, Brush.linearGradient(listOf(Color(0xFF3F7BFF), Color(0xFF7A4BFF))), shape)
            .pointerInput(Unit) { detectTapGestures { } }
            .padding(18.dp)
    ) {
        Text(
            title, color = Color(0xFFCFE4FF), fontFamily = Readex, fontWeight = FontWeight.Bold,
            style = TextStyle(shadow = Shadow(Color(0xFF4C8DFF).copy(alpha = 0.7f), blurRadius = 18f)),
            fontSize = 20.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(start = 4.dp, end = 4.dp, top = 2.dp, bottom = 14.dp).staggerIn(0, 30, 0, 0.dp, 0.95f, 260)
        )
        Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState())) { content() }
    }
}

/** سطر في الطبقة: أيقونة داخل دايرة بحدود زرقا + اسم + قيمة اختيارية. الأيقونة بتتنطط لما تضغط. */
@Composable
fun LayerItem(
    label: String,
    index: Int,
    icon: ImageVector? = null,
    value: String? = null,
    selected: Boolean = false,
    danger: Boolean = false,
    family: FontFamily = Readex,
    onClick: () -> Unit,
) {
    val shape = RoundedCornerShape(22.dp)
    val tint = if (danger) Color(0xFFFF8FA3) else if (selected) Color(0xFF9FE0FF) else Sky
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val ic by animateFloatAsState(if (pressed) 1.3f else 1f, tween(320, easing = EaseSeg), label = "ic")
    Row(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp)
            .staggerIn(index, 30, 50, 0.dp, 0.95f, 260)
            .bounceClick(pressScale = 0.98f, interaction = src, onClick = onClick)
            .then(if (selected) Modifier.glow(Color(0xFF3D5BFF), 8.dp, 22.dp, 0.35f) else Modifier)
            .clip(shape)
            .background(
                if (selected) Brush.linearGradient(listOf(Color(0xFF1B3FA8), Color(0xFF3A2A9C)))
                else SolidColor(Color(0xAA0A1C58))
            )
            .border(
                1.dp,
                if (selected) Brush.linearGradient(listOf(Color(0xFF7FD4FF), Color(0xFF8A6BFF)))
                else SolidColor(Color(0xFF1B3A8F)),
                shape
            )
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            Box(
                Modifier.size(38.dp).clip(CircleShape)
                    .background(Color(0xCC0A1A55))
                    .border(1.dp, if (danger) Color(0x66FF8FA3) else Color(0xFF22408F), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    icon, null, tint = tint,
                    modifier = Modifier.size(21.dp).graphicsLayer { scaleX = ic; scaleY = ic; rotationZ = (ic - 1f) * 30f }
                )
            }
            Spacer(Modifier.width(12.dp))
        } else {
            Spacer(Modifier.width(4.dp))
        }
        Text(
            label, color = if (danger) Color(0xFFFF8FA3) else Tx, fontFamily = family, fontSize = 15.sp,
            modifier = Modifier.weight(1f)
        )
        if (value != null) {
            Spacer(Modifier.width(8.dp))
            Text(
                value, color = if (value == "✓") Sky else Mut, fontFamily = Readex, fontSize = 13.sp,
                fontWeight = if (value == "✓") FontWeight.Bold else FontWeight.Normal,
                modifier = Modifier.padding(end = 4.dp).then(if (value == "✓") Modifier.popi(selected, enabled = true) else Modifier)
            )
        }
    }
}

@Composable
fun LayerLabel(label: String, value: String, valueColor: Color = Color(0xFF9BD8FF)) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Mut, fontFamily = Readex, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        if (value.isNotEmpty()) Text(value, color = valueColor, fontFamily = Readex, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun LayerBtn(label: String, primary: Boolean, danger: Boolean, onClick: () -> Unit, modifier: Modifier) {
    val shape = RoundedCornerShape(24.dp)
    val bg = when {
        danger -> Brush.linearGradient(listOf(Color(0xFFFF5C78), Color(0xFFB3173A)))
        primary -> Brush.linearGradient(listOf(Color(0xFF3D8BFF), Color(0xFF6A3DFF)))
        else -> SolidColor(Color(0xCC0A1A55))
    }
    Box(
        modifier
            .bounceClick(onClick = onClick)
            .then(if (primary) Modifier.glow(if (danger) Color(0xFFFF4D6A) else Blue, 12.dp, 24.dp, 0.5f) else Modifier)
            .clip(shape)
            .background(bg)
            .border(1.dp, if (primary) Color(0x66BFD8FF) else Color(0xFF22408F), shape)
            .padding(vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) { Text(label, color = Color.White, fontFamily = Readex, fontWeight = FontWeight.Bold, fontSize = 15.sp) }
}

@Composable
fun LayerButtons(cancel: String?, ok: String, danger: Boolean = false, onCancel: () -> Unit = {}, onOk: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        if (cancel != null) LayerBtn(cancel, false, false, onCancel, Modifier.weight(1f))
        LayerBtn(ok, true, danger, onOk, Modifier.weight(1f))
    }
}

/** شريط اختيار بمؤشر بينزلق بنطّة زنبركية (زي أشرطة السرعة والنوم في الـ APK). */
@Composable
fun SegSelector(labels: List<String>, index: Int, onPick: (Int) -> Unit) {
    val n = labels.size.coerceAtLeast(1)
    val shape = RoundedCornerShape(26.dp)
    val frac by animateFloatAsState(index.toFloat(), tween(500, easing = EaseSeg), label = "seg")
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        BoxWithConstraints(
            Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(Color(0xAA061340))
                .border(1.dp, Color(0xFF1B3A8F), shape)
                .padding(4.dp)
        ) {
            val segW = maxWidth / n
            Box(
                Modifier
                    .offset(x = segW * frac)
                    .width(segW)
                    .height(42.dp)
                    .glow(Color(0xFF3D5BFF), 8.dp, 22.dp, 0.4f)
                    .clip(RoundedCornerShape(22.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF3D8BFF), Color(0xFF6A3DFF))))
            )
            Row(Modifier.fillMaxWidth().height(42.dp)) {
                labels.forEachIndexed { i, l ->
                    Box(
                        Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(22.dp)).bounceClick { onPick(i) },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            l, color = if (i == index) Color.White else Color(0xFF8FA3CF), fontFamily = Readex,
                            fontWeight = FontWeight.Bold, fontSize = 13.5.sp, maxLines = 1
                        )
                    }
                }
            }
        }
    }
}

class MenuEntry(val label: String, val icon: ImageVector, val danger: Boolean = false, val onClick: () -> Unit)

/** قائمة اختيارات في الطبقة المركزية (بتحل محل القوائم المنسدلة القديمة). */
@Composable
fun MenuLayer(title: String, entries: List<MenuEntry>, onDismiss: () -> Unit) {
    LayerDialog(title, onDismiss) {
        entries.forEachIndexed { i, e ->
            LayerItem(e.label, i, e.icon, danger = e.danger) { onDismiss(); e.onClick() }
        }
    }
}
