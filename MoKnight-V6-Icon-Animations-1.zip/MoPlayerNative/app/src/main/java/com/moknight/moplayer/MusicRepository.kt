package com.moknight.moplayer

import android.content.Context
import android.os.Build
import android.provider.MediaStore

object MusicRepository {
    /** يمسح كل ملفات الصوت الموجودة على التليفون عن طريق MediaStore. */
    @Suppress("DEPRECATION")
    fun scan(ctx: Context): List<Track> {
        val out = ArrayList<Track>()
        val pathCol = if (Build.VERSION.SDK_INT >= 29) MediaStore.Audio.Media.RELATIVE_PATH
        else MediaStore.Audio.Media.DATA
        val projList = mutableListOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DISPLAY_NAME,
            pathCol,
        )
        // عمود النوع (Genre) موجود من أندرويد 11 وطالع
        val hasGenre = Build.VERSION.SDK_INT >= 30
        if (hasGenre) projList.add(MediaStore.Audio.Media.GENRE)
        val proj = projList.toTypedArray()
        val sel = "${MediaStore.Audio.Media.DURATION} >= 3000"
        val order = "${MediaStore.Audio.Media.DATE_ADDED} DESC"
        ctx.contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, proj, sel, null, order
        )?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val iTitle = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val iArtist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val iAlbum = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val iAlbumId = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val iDur = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val iPath = c.getColumnIndexOrThrow(pathCol)
            val iFile = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
            val iGenre = if (hasGenre) c.getColumnIndex(MediaStore.Audio.Media.GENRE) else -1
            while (c.moveToNext()) {
                val artist = c.getString(iArtist).orEmpty().let { if (it == "<unknown>") "" else it }
                val title = c.getString(iTitle).orEmpty().ifBlank { "بدون اسم" }
                val album = c.getString(iAlbum).orEmpty()
                val path = c.getString(iPath).orEmpty()
                val file = c.getString(iFile).orEmpty()
                val genre = if (iGenre >= 0) c.getString(iGenre).orEmpty() else ""
                out.add(
                    Track(
                        id = c.getLong(iId),
                        title = title,
                        artist = artist,
                        album = album,
                        albumId = c.getLong(iAlbumId),
                        durationMs = c.getLong(iDur),
                        path = path,
                        kind = Classifier.classify(title, file, artist, album, genre, path),
                    )
                )
            }
        }
        return out
    }
}
