package com.moknight.moplayer

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

sealed interface Dlg {
    data class NewList(val add: List<Long>) : Dlg
    data class Rename(val pl: Playlist) : Dlg
    data class DeleteList(val pl: Playlist) : Dlg
    data class Pick(val ids: List<Long>) : Dlg
    data class Edit(val t: Track) : Dlg
    data class ConfirmHide(val ids: List<Long>) : Dlg
}

@Composable
private fun DlgText(s: String, color: androidx.compose.ui.graphics.Color = Tx, size: Int = 15) =
    Text(s, color = color, fontFamily = Readex, fontSize = size.sp)

@Composable
private fun field(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = onChange, singleLine = true,
        label = { Text(label, fontFamily = Readex) },
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = Tx, unfocusedTextColor = Tx,
            focusedBorderColor = Sky, unfocusedBorderColor = Mut,
            cursorColor = Sky, focusedLabelColor = Sky, unfocusedLabelColor = Mut,
        ),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
fun NameDialog(title: String, initial: String, ok: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var name by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Navy2,
        title = { DlgText(title, size = 18) },
        text = { field(tr("الاسم", "Name"), name) { name = it } },
        confirmButton = { TextButton(onClick = { onOk(name) }) { DlgText(ok, Sky) } },
        dismissButton = { TextButton(onClick = onDismiss) { DlgText(tr("إلغاء", "Cancel"), Mut) } },
    )
}

@Composable
fun EditDialog(t: Track, onDismiss: () -> Unit, onOk: (String, String, Kind) -> Unit) {
    var title by remember { mutableStateOf(t.title) }
    var artist by remember { mutableStateOf(t.artist) }
    var kind by remember { mutableStateOf(t.kind) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Navy2,
        title = { DlgText(tr("تعديل الملف", "Edit file"), size = 18) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                field(tr("الاسم", "Name"), title) { title = it }
                field(tr("الفنان", "Artist"), artist) { artist = it }
                DlgText(tr("التصنيف", "Category"), Mut, 13)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Kind.values().forEach { k ->
                        val on = kind == k
                        Box(
                            Modifier
                                .clip(RoundedCornerShape(50))
                                .background(if (on) Blue else Color.White.copy(alpha = 0.08f))
                                .clickable { kind = k }
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) { DlgText(kindLabel(k), if (on) Color.White else Mut, 13) }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onOk(title, artist, kind) }) { DlgText(tr("حفظ", "Save"), Sky) } },
        dismissButton = { TextButton(onClick = onDismiss) { DlgText(tr("إلغاء", "Cancel"), Mut) } },
    )
}

@Composable
fun ConfirmDialog(title: String, msg: String, ok: String, onDismiss: () -> Unit, onOk: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Navy2,
        title = { DlgText(title, size = 18) },
        text = { DlgText(msg, Mut, 14) },
        confirmButton = { TextButton(onClick = onOk) { DlgText(ok, Sky) } },
        dismissButton = { TextButton(onClick = onDismiss) { DlgText(tr("إلغاء", "Cancel"), Mut) } },
    )
}

@Composable
fun PickListDialog(
    lists: List<Playlist>, onDismiss: () -> Unit, onPick: (Playlist) -> Unit, onNew: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Navy2,
        title = { DlgText(tr("إضافة لقائمة", "Add to playlist"), size = 18) },
        text = {
            Column {
                Row(
                    Modifier.fillMaxWidth().clickable(onClick = onNew).padding(vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Add, null, tint = Sky)
                    Spacer(Modifier.width(10.dp))
                    DlgText(tr("قائمة جديدة", "New playlist"), Sky)
                }
                LazyColumn(Modifier.heightIn(max = 260.dp)) {
                    items(lists, key = { it.id }) { p ->
                        Row(
                            Modifier.fillMaxWidth().clickable { onPick(p) }.padding(vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.QueueMusic, null, tint = Mut)
                            Spacer(Modifier.width(10.dp))
                            DlgText(p.name)
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { DlgText(tr("إلغاء", "Cancel"), Mut) } },
    )
}
