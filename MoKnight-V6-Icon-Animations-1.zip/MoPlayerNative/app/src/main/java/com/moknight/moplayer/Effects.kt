package com.moknight.moplayer

import android.graphics.Bitmap
import android.media.audiofx.Visualizer
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.pow
import kotlin.math.sin
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext

/** خلفية حية: دوائر ضوء بتتحرك ببطء. */
@Composable
fun LivingBg(modifier: Modifier = Modifier, strength: Float = 0.48f) {
    val tr = rememberInfiniteTransition(label = "bg")
    val a by tr.animateFloat(0f, 1f, infiniteRepeatable(tween(14000, easing = LinearEasing), RepeatMode.Reverse), label = "a")
    val b by tr.animateFloat(0f, 1f, infiniteRepeatable(tween(19000, easing = LinearEasing), RepeatMode.Reverse), label = "b")
    val c by tr.animateFloat(0f, 1f, infiniteRepeatable(tween(23000, easing = LinearEasing), RepeatMode.Reverse), label = "c")
    Canvas(modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        fun orb(color: Color, cx: Float, cy: Float, r: Float) {
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(color.copy(alpha = 0.34f * strength), Color.Transparent),
                    center = Offset(cx, cy), radius = r
                ),
                radius = r, center = Offset(cx, cy)
            )
        }
        // هالات ضوئية كبيرة تتحرك ببطء لتدي إحساس شفق متحرك بدل الخطوط الثابتة.
        orb(Blue, w * (0.15f + 0.62f * a), h * (0.18f + 0.24f * b), w * 0.88f)
        orb(Sky, w * (0.92f - 0.72f * b), h * (0.52f + 0.20f * c), w * 0.82f)
        orb(Color(0xFF6A3DFF), w * (0.22f + 0.56f * c), h * (0.88f - 0.30f * a), w * 0.86f)

        // ستائر ضوئية عريضة وناعمة تتحرك مع الزمن؛ ليست خطوطًا حادة في الخلفية.
        val aurora1 = Path().apply {
            moveTo(-w * 0.15f, h * (0.48f + 0.10f * a))
            cubicTo(w * 0.22f, h * (0.30f + 0.12f * b), w * 0.58f, h * (0.70f - 0.12f * c), w * 1.15f, h * (0.38f + 0.10f * a))
            lineTo(w * 1.15f, h * 0.58f)
            cubicTo(w * 0.62f, h * (0.88f - 0.12f * b), w * 0.28f, h * (0.42f + 0.10f * c), -w * 0.15f, h * 0.68f)
            close()
        }
        drawPath(aurora1, Brush.verticalGradient(listOf(Color(0xFF185BFF).copy(alpha = 0.075f * strength), Color(0xFF6B35FF).copy(alpha = 0.035f * strength), Color.Transparent), startY = h * 0.28f, endY = h * 0.78f))

        val aurora2 = Path().apply {
            moveTo(-w * 0.1f, h * (0.78f - 0.08f * c))
            cubicTo(w * 0.3f, h * (0.60f + 0.12f * a), w * 0.66f, h * (0.92f - 0.10f * b), w * 1.1f, h * (0.65f + 0.08f * c))
            lineTo(w * 1.1f, h * 0.82f)
            cubicTo(w * 0.66f, h * 1.02f, w * 0.28f, h * (0.76f + 0.08f * b), -w * 0.1f, h * 0.94f)
            close()
        }
        drawPath(aurora2, Brush.verticalGradient(listOf(Color(0xFF572BFF).copy(alpha = 0.06f * strength), Color.Transparent), startY = h * 0.62f, endY = h))

        // خيوط ضوئية متموجة تتحرك أفقيًا ببطء في الخلفية، بلون أزرق/بنفسجي خافت.
        val phases = listOf(a * 2.2f, b * 2.6f + 1.4f, c * 2.0f + 3.1f)
        val ys = listOf(0.34f, 0.63f, 0.82f)
        val colors = listOf(Color(0xFF168BFF), Color(0xFF6B55FF), Color(0xFF20BFFF))
        for (j in phases.indices) {
            var prev = Offset(0f, h * ys[j])
            for (i in 1..72) {
                val x = w * i / 72f
                val wave = sin(i * 0.115f + phases[j]) * h * 0.035f + sin(i * 0.047f - phases[j] * 0.7f) * h * 0.018f
                val y = (h * ys[j] + wave).toFloat()
                val next = Offset(x, y)
                drawLine(
                    color = colors[j].copy(alpha = 0.12f * strength),
                    start = prev,
                    end = next,
                    strokeWidth = 1.3.dp.toPx()
                )
                prev = next
            }
        }
    }
}

/** موجة صوت صغيرة بتتحرك في الصف اللي شغال دلوقتي. */
@Composable
fun WaveBars(on: Boolean, modifier: Modifier = Modifier) {
    val tr = rememberInfiniteTransition(label = "wave")
    val ph by tr.animateFloat(0f, 6.2832f, infiniteRepeatable(tween(1300, easing = LinearEasing), RepeatMode.Restart), label = "ph")
    Canvas(modifier) {
        val n = 14
        val gap = 4.dp.toPx()
        val bw = (size.width - gap * (n - 1)) / n
        for (i in 0 until n) {
            val base = 0.3f + 0.7f * abs(sin(i * 0.9f))
            val f = if (on) 0.55f + 0.45f * sin(ph + i * 0.7f) else 0.45f
            val h = (size.height * base * f).coerceAtLeast(4.dp.toPx())
            val a = 0.15f + 0.85f * (1f - abs(i - (n - 1) / 2f) / ((n - 1) / 2f))
            drawRoundRect(
                color = Color(0xFF5B55F0).copy(alpha = a),
                topLeft = Offset(i * (bw + gap), (size.height - h) / 2f),
                size = Size(bw, h),
                cornerRadius = CornerRadius(bw / 2f)
            )
        }
    }
}

/** غلاف الأغنية مطموس كخلفية للمشغّل الكامل. */
@Composable
fun CoverBg(t: Track, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, t.id) {
        value = withContext(Dispatchers.IO) { ArtLoader.load(ctx, t, 640) }
    }
    bmp?.let {
        Image(
            it.asImageBitmap(), null, contentScale = ContentScale.Crop,
            modifier = modifier.fillMaxSize().blur(50.dp).alpha(0.5f)
        )
    }
}

/** حلقة نبض حوالين زر التشغيل وقت التشغيل. */
@Composable
fun Modifier.pulseRing(on: Boolean): Modifier {
    if (!on) return this
    val tr = rememberInfiniteTransition(label = "ring")
    val p by tr.animateFloat(0f, 1f, infiniteRepeatable(tween(1600, easing = LinearOutSlowInEasing)), label = "p")
    return this.drawBehind {
        val r = size.minDimension / 2
        drawCircle(Sky.copy(alpha = (1f - p) * 0.55f), radius = r * (1f + p * 0.55f), style = Stroke(2.dp.toPx()))
    }
}

/** المؤثر المرئي: حقيقي لو الإذن موجود، وحركة تزيينية لو مفيش إذن. */
@Composable
fun VizBars(sessionId: Int, micOk: Boolean, playing: Boolean, modifier: Modifier = Modifier) {
    val n = 36
    val bars = remember { FloatArray(n) }
    var frame by remember { mutableIntStateOf(0) }

    LaunchedEffect(sessionId, micOk, playing) {
        var viz: Visualizer? = null
        if (micOk && sessionId != 0 && playing) {
            viz = runCatching {
                Visualizer(sessionId).also {
                    it.setCaptureSize(Visualizer.getCaptureSizeRange()[1].coerceAtMost(1024))
                    it.setEnabled(true)
                }
            }.getOrNull()
        }
        val buf = viz?.let { ByteArray(it.captureSize) }
        try {
            var tm = 0f
            while (isActive) {
                val target = FloatArray(n)
                if (viz != null && buf != null && viz.getFft(buf) == Visualizer.SUCCESS) {
                    val bins = buf.size / 2
                    for (i in 0 until n) {
                        val lo = bins.toDouble().pow(i / n.toDouble()).toInt().coerceAtLeast(1)
                        val hi = bins.toDouble().pow((i + 1) / n.toDouble()).toInt().coerceIn(lo + 1, bins)
                        var mx = 0f
                        for (k in lo until hi) {
                            if (2 * k + 1 < buf.size) {
                                mx = maxOf(mx, hypot(buf[2 * k].toFloat(), buf[2 * k + 1].toFloat()))
                            }
                        }
                        target[i] = (mx / 110f).coerceIn(0f, 1f).pow(0.6f)
                    }
                } else if (playing) {
                    tm += 0.12f
                    for (i in 0 until n) {
                        target[i] = ((0.25f + 0.2f * sin(tm * 1.3f + i * 0.5f) + 0.15f * sin(tm * 2.1f + i * 1.1f))
                            .coerceIn(0.05f, 1f)) * 0.6f
                    }
                }
                for (i in 0 until n) {
                    bars[i] = if (target[i] > bars[i]) bars[i] + (target[i] - bars[i]) * 0.6f else bars[i] * 0.88f
                }
                frame++
                delay(33)
            }
        } finally {
            runCatching { viz?.setEnabled(false); viz?.release() }
        }
    }

    Canvas(modifier.fillMaxWidth().height(56.dp)) {
        @Suppress("UNUSED_VARIABLE") val tick = frame
        val gap = 4.dp.toPx()
        val bw = (size.width - gap * (n - 1)) / n
        for (i in 0 until n) {
            val h = (bars[i] * size.height).coerceAtLeast(3.dp.toPx())
            drawRoundRect(
                brush = Brush.verticalGradient(listOf(Sky, Blue), startY = size.height - h, endY = size.height),
                topLeft = Offset(i * (bw + gap), size.height - h),
                size = Size(bw, h),
                cornerRadius = CornerRadius(bw / 2)
            )
        }
    }
}
