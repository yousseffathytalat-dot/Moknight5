package com.moknight.moplayer

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyGridItemSpanScope
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Settings as OSettings
import androidx.compose.material.icons.rounded.AutoStories as RBook
import androidx.compose.material.icons.rounded.FormatListBulleted as RList
import androidx.compose.material.icons.rounded.GridView as RGrid
import androidx.compose.material.icons.rounded.MusicNote as RNote
import androidx.compose.material.icons.rounded.QueueMusic as RQueue
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val st = Store(this)
        AppFont.key = st.font
        Lang.en = st.lang == "en"
        // شريط الحالة (الساعة والبطارية والشبكة) بتاع التليفون نفسه، التطبيق بيرسم تحته من غير ما يرسم حاجة فيه
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        setContent {
            // الواجهة بتتكيّف تلقائيًا مع حجم الشاشة: تليفون صغير، تليفون كبير، تابلت، لابتوب
            val cfg = LocalConfiguration.current
            val k = (minOf(cfg.screenWidthDp, cfg.screenHeightDp) / 400f).coerceIn(0.9f, 1.25f)
            val d = LocalDensity.current
            CompositionLocalProvider(LocalDensity provides Density(d.density * k, d.fontScale)) {
                MaterialTheme(
                    colorScheme = darkColorScheme(primary = Blue, background = Bg0, surface = Navy2, onSurface = Tx),
                ) {
                    CompositionLocalProvider(LocalLayoutDirection provides (if (Lang.en) LayoutDirection.Ltr else LayoutDirection.Rtl)) {
                        App()
                    }
                }
            }
        }
    }
}

private fun tabLabels() = listOf(tr("المكتبة", "Library"), tr("التسجيلات", "Recordings"), tr("القوائم", "Playlists"))

private fun kindEmptyMsg(k: Kind) = when (k) {
    Kind.NASHEED -> tr("مفيش أناشيد اتلقت على التليفون.", "No nasheeds found on this phone.")
    Kind.QURAN -> tr("مفيش قرآن اتلقى على التليفون.", "No Quran audio found on this phone.")
    Kind.OTHER -> tr("مفيش ملفات تانية اتلقت.", "No other audio files found.")
}

private fun kindCountText(k: Kind, n: Int) = when (k) {
    Kind.NASHEED -> tr("$n أنشودة", "$n nasheeds")
    Kind.QURAN -> tr("$n ملف قرآن", "$n Quran files")
    Kind.OTHER -> tr("$n ملف", "$n files")
}

private class RowActions(
    val edit: (Track) -> Unit,
    val addToList: (Track) -> Unit,
    val move: (Track, Kind) -> Unit,
    val hide: (Track) -> Unit,
)

@Composable
fun App(vm: MainVM = viewModel()) {
    val ctx = LocalContext.current
    val tracks by vm.tracks.collectAsState()
    val loading by vm.loading.collectAsState()
    val current by vm.current.collectAsState()
    val last by vm.last.collectAsState()
    val playing by vm.playing.collectAsState()
    val playlists by vm.playlists.collectAsState()
    val cat by vm.cat.collectAsState()

    val perms = remember {
        if (Build.VERSION.SDK_INT >= 33)
            arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
        else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    }
    fun hasAudio() = ContextCompat.checkSelfPermission(ctx, perms[0]) == PackageManager.PERMISSION_GRANTED
    var granted by remember { mutableStateOf(hasAudio()) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = hasAudio()
        if (granted) vm.scan()
    }
    LaunchedEffect(Unit) {
        if (granted) vm.scan() else launcher.launch(perms)
    }

    var tab by remember { mutableIntStateOf(0) }
    var openId by remember { mutableStateOf<Long?>(null) }
    var sel by remember { mutableStateOf(setOf<Long>()) }
    var dlg by remember { mutableStateOf<Dlg?>(null) }
    var query by remember { mutableStateOf("") }
    var showFull by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }

    var micOk by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
    }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { micOk = it }
    LaunchedEffect(showFull) {
        val prefs = ctx.getSharedPreferences("moplayer", android.content.Context.MODE_PRIVATE)
        if (showFull && !micOk && !prefs.getBoolean("asked_mic", false)) {
            prefs.edit().putBoolean("asked_mic", true).apply()
            micLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    val openPl = openId?.let { id -> playlists.firstOrNull { it.id == id } }
    val inListsRoot = tab == 2 && openPl == null

    val base = remember(tracks, tab, openPl, cat) {
        when {
            tab == 0 -> tracks.filter { !it.isRecording && it.kind == cat }
            tab == 1 -> tracks.filter { it.isRecording }
            openPl != null -> {
                val m = tracks.associateBy { it.id }
                openPl.ids.mapNotNull { m[it] }
            }
            else -> emptyList()
        }
    }
    val shown = remember(base, query) {
        val q = query.trim()
        if (q.isEmpty()) base
        else base.filter { it.title.contains(q, true) || it.artist.contains(q, true) || it.album.contains(q, true) }
    }

    // زر الرجوع: آخر واحد متسجل له الأولوية
    BackHandler(enabled = openPl != null) { openId = null; sel = emptySet() }
    BackHandler(enabled = sel.isNotEmpty()) { sel = emptySet() }
    BackHandler(enabled = showFull) { showFull = false }
    BackHandler(enabled = showSettings) { showSettings = false }

    fun toast(s: String) = Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()

    // آخر حاجة اتشغلت بتفضل ظاهرة تحت حتى لو مفيش حاجة شغالة دلوقتي
    val miniTrack = current ?: last
    val bottomPad = if (miniTrack != null) 128.dp else 28.dp

    val rowActions = remember {
        RowActions(
            edit = { dlg = Dlg.Edit(it) },
            addToList = { dlg = Dlg.Pick(listOf(it.id)) },
            move = { t, k ->
                vm.setKind(listOf(t.id), k)
                toast(tr("اتنقلت إلى ${kindLabel(k)}", "Moved to ${kindLabel(k)}"))
            },
            hide = { dlg = Dlg.ConfirmHide(listOf(it.id)) },
        )
    }

    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .background(AppBg)
    ) {
        val cols = when {
            maxWidth >= 900.dp -> 3
            maxWidth >= 600.dp -> 2
            else -> 1
        }
        val hPad = if (maxWidth >= 600.dp) 24.dp else 14.dp
        // في الوضع الأفقي على التليفون المساحة قليلة، فالتبويبات والأزرار بتتحرك مع القايمة
        val compactH = maxHeight < 480.dp

        LivingBg()

        val headerBlock: @Composable () -> Unit = {
            if (openPl == null) {
                TabBar(tab, hPad) { i -> tab = i; sel = emptySet(); query = ""; openId = null }
            }
            if (tab == 0 && openPl == null) {
                CategoryRow(cat, hPad) { k -> vm.setCat(k); sel = emptySet(); query = "" }
            }
            if (!inListsRoot) {
                ActionCard(
                    hPad = hPad, query = query, onQuery = { query = it }, enabled = shown.isNotEmpty(),
                    onSequential = { vm.playFrom(shown, 0) },
                    onShuffle = { vm.playShuffled(shown) },
                )
                Text(
                    if (loading) tr("بيمسح الجهاز…", "Scanning device…")
                    else if (tab == 0) kindCountText(cat, shown.size)
                    else tr("${shown.size} ملف", "${shown.size} files"),
                    color = Mut, fontFamily = Readex, fontSize = 13.sp,
                    modifier = Modifier.padding(horizontal = hPad + 6.dp).padding(bottom = 4.dp)
                )
            }
        }

        val full: LazyGridItemSpanScope.() -> GridItemSpan = { GridItemSpan(maxLineSpan) }

        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            // ---------- الهيدر ----------
            if (sel.isNotEmpty()) {
                HeaderCard(hPad) {
                    IconButton(onClick = { sel = emptySet() }) { Icon(Icons.Default.Close, tr("إلغاء", "Cancel"), tint = Tx) }
                    Text(tr("${sel.size} محدد", "${sel.size} selected"), color = Tx, fontFamily = Readex, fontSize = 16.sp, modifier = Modifier.weight(1f))
                    IconButton(onClick = { sel = shown.map { it.id }.toSet() }) { Icon(Icons.Default.SelectAll, tr("الكل", "All"), tint = Sky) }
                    if (sel.size == 1) IconButton(onClick = {
                        tracks.firstOrNull { it.id == sel.first() }?.let { dlg = Dlg.Edit(it) }
                    }) { Icon(Icons.Default.Edit, tr("تعديل", "Edit"), tint = Sky) }
                    MoveMenu { k ->
                        vm.setKind(sel, k)
                        toast(tr("اتنقل ${sel.size} إلى ${kindLabel(k)}", "Moved ${sel.size} to ${kindLabel(k)}"))
                        sel = emptySet()
                    }
                    IconButton(onClick = { dlg = Dlg.Pick(sel.toList()) }) { Icon(Icons.Default.PlaylistAdd, tr("إضافة لقائمة", "Add to playlist"), tint = Sky) }
                    IconButton(onClick = {
                        if (openPl != null) {
                            vm.removeFromPlaylist(openPl.id, sel); sel = emptySet()
                        } else dlg = Dlg.ConfirmHide(sel.toList())
                    }) { Icon(Icons.Default.Delete, tr("حذف", "Delete"), tint = Color(0xFFFF6B6B)) }
                }
            } else {
                if (openPl != null) {
                    HeaderCard(hPad) {
                        IconButton(onClick = { openId = null }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, tr("رجوع", "Back"), tint = Tx) }
                        Text(
                            openPl.name, color = Tx, fontFamily = Readex, fontWeight = FontWeight.Bold,
                            fontSize = 22.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        RoundButton(Icons.Outlined.OSettings, tr("الإعدادات", "Settings")) { showSettings = true }
                    }
                } else {
                    // الهيدر الرئيسي بترتيب الصورة: + ثم الإعدادات يسارًا، الاسم في المنتصف، وشعار M يمينًا.
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        HeaderCard(hPad) {
                            PlusMenu(
                                onNewList = { dlg = Dlg.NewList(emptyList()) },
                                onRefresh = { if (granted) vm.scan() else launcher.launch(perms) },
                            )
                            Spacer(Modifier.width(10.dp))
                            RoundButton(Icons.Outlined.OSettings, tr("الإعدادات", "Settings")) { showSettings = true }
                            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                                Text(
                                    "MoKnight", color = Color.White, fontFamily = FontFamily.Serif,
                                    fontWeight = FontWeight.Bold, fontSize = 30.sp, maxLines = 1
                                )
                            }
                            HeaderLogo(50.dp)
                        }
                    }
                }
            }

            if (!compactH) headerBlock()

            // ---------- المحتوى ----------
            LazyVerticalGrid(
                columns = GridCells.Fixed(cols),
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(start = hPad, end = hPad, top = 4.dp, bottom = bottomPad),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                if (compactH) item(key = "header", span = full) { Column { headerBlock() } }

                when {
                    !granted -> item(key = "perm", span = full) {
                        Empty(tr("محتاج إذن الوصول للصوتيات عشان أعرض ملفاتك.", "Audio access permission is needed to show your files."), tr("إعطاء الإذن", "Grant permission")) { launcher.launch(perms) }
                    }

                    inListsRoot -> {
                        item(key = "lists_head", span = full) {
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(tr("${playlists.size} قائمة", "${playlists.size} playlists"), color = Mut, fontFamily = Readex, fontSize = 13.sp, modifier = Modifier.weight(1f))
                                GradientButton(tr("قائمة جديدة", "New playlist"), Icons.Default.Add) { dlg = Dlg.NewList(emptyList()) }
                            }
                        }
                        if (playlists.isEmpty()) item(key = "lists_empty", span = full) {
                            Text(
                                tr("مفيش قوائم لسه. اعمل واحدة وضيف لها ملفات.", "No playlists yet. Create one and add files."),
                                color = Mut, fontFamily = Readex, fontSize = 14.sp,
                                modifier = Modifier.padding(24.dp)
                            )
                        }
                        items(playlists, key = { "pl_${it.id}" }) { p ->
                            PlaylistRow(
                                p,
                                onOpen = { openId = p.id; query = "" },
                                onRename = { dlg = Dlg.Rename(p) },
                                onDelete = { dlg = Dlg.DeleteList(p) },
                            )
                        }
                    }

                    !loading && shown.isEmpty() -> item(key = "empty", span = full) {
                        val msg = when {
                            query.isNotBlank() -> tr("مفيش نتايج للبحث.", "No search results.")
                            openPl != null -> tr("القائمة فاضية. حدد ملفات من المكتبة وضيفها هنا.", "Playlist is empty. Select files from the library and add them here.")
                            tab == 1 -> tr("مفيش تسجيلات اتلقت.", "No recordings found.")
                            else -> kindEmptyMsg(cat)
                        }
                        Empty(msg, tr("مسح تاني", "Scan again")) { vm.scan() }
                    }

                    else -> itemsIndexed(shown, key = { _, t -> t.id }) { i, t ->
                        TrackRow(
                            t = t,
                            active = t.id == current?.id,
                            playing = playing,
                            selected = t.id in sel,
                            actions = rowActions,
                            onClick = {
                                if (sel.isNotEmpty()) sel = if (t.id in sel) sel - t.id else sel + t.id
                                else vm.playFrom(shown, i)
                            },
                            onLong = { sel = if (t.id in sel) sel - t.id else sel + t.id },
                        )
                    }
                }
            }
        }

        // ---------- المشغّل المصغّر: آخر حاجة اتشغلت ----------
        miniTrack?.let { t ->
            MiniHost(
                vm = vm, track = t, playing = playing, idle = current == null,
                onOpen = {
                    if (current == null) vm.playLast()
                    showFull = true
                },
                modifier = Modifier.align(Alignment.BottomCenter)
            )
        }

        // ---------- المشغّل الكامل ----------
        AnimatedVisibility(
            visible = showFull && current != null,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut(),
        ) {
            current?.let { t -> FullHost(vm, t, playing, micOk, { showFull = false }, { showSettings = true }) }
        }

        AnimatedVisibility(
            visible = showSettings,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut(),
        ) {
            SettingsHost(vm) { showSettings = false }
        }
    }

    // ---------- الحوارات ----------
    when (val d = dlg) {
        null -> {}
        is Dlg.NewList -> NameDialog(tr("قائمة جديدة", "New playlist"), "", tr("إنشاء", "Create"), { dlg = null }) { name ->
            vm.createPlaylist(name, d.add)
            if (d.add.isNotEmpty()) toast(tr("اتضافت ${d.add.size} للقائمة", "${d.add.size} added to playlist"))
            sel = emptySet(); dlg = null
        }
        is Dlg.Rename -> NameDialog(tr("اسم القائمة", "Playlist name"), d.pl.name, tr("حفظ", "Save"), { dlg = null }) { name ->
            vm.renamePlaylist(d.pl.id, name); dlg = null
        }
        is Dlg.DeleteList -> ConfirmDialog(
            tr("حذف القائمة", "Delete playlist"), tr("هتتحذف القائمة \"${d.pl.name}\" بس، والملفات هتفضل زي ما هي.", "Only the playlist \"${d.pl.name}\" will be deleted; files stay as they are."), tr("حذف", "Delete"), { dlg = null }
        ) { vm.deletePlaylist(d.pl.id); dlg = null }
        is Dlg.Pick -> PickListDialog(
            playlists, { dlg = null },
            onPick = { p -> vm.addToPlaylist(p.id, d.ids); toast(tr("اتضاف لـ ${p.name}", "Added to ${p.name}")); sel = emptySet(); dlg = null },
            onNew = { dlg = Dlg.NewList(d.ids) },
        )
        is Dlg.Edit -> EditDialog(d.t, { dlg = null }) { title, artist, kind ->
            vm.editTrack(d.t.id, title, artist)
            if (kind != d.t.kind) vm.setKind(listOf(d.t.id), kind)
            sel = emptySet(); dlg = null
        }
        is Dlg.ConfirmHide -> ConfirmDialog(
            tr("إخفاء ${d.ids.size} من التطبيق", "Hide ${d.ids.size} from app"),
            tr("الملفات هتختفي من MoPlayer بس، والملفات نفسها هتفضل على التليفون.", "Files will be hidden from MoPlayer only; they stay on the phone."), tr("إخفاء", "Hide"), { dlg = null }
        ) { vm.hide(d.ids); sel = emptySet(); dlg = null }
    }
}

// =====================================================================
//  الهيدر
// =====================================================================

private enum class IconMotion { PULSE, ROTATE, SWAY, NONE }

/** حركات صغيرة مختلفة حسب وظيفة الأيقونة، من غير تغيير شكل الواجهة. */
@Composable
private fun TaskIcon(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    desc: String?,
    tint: Color,
    modifier: Modifier = Modifier,
    motion: IconMotion = IconMotion.NONE,
    active: Boolean = false,
) {
    val transition = rememberInfiniteTransition(label = "task-icon-$motion")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (motion) {
                    IconMotion.PULSE -> 1150
                    IconMotion.ROTATE -> 1800
                    IconMotion.SWAY -> 900
                    IconMotion.NONE -> 1500
                },
                easing = LinearEasing,
            ),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "phase",
    )
    val amount = if (active) 1f else if (motion == IconMotion.PULSE) 0.22f else 0f
    val scale = when (motion) {
        IconMotion.PULSE -> 1f + (0.055f * phase * amount)
        IconMotion.ROTATE, IconMotion.SWAY, IconMotion.NONE -> 1f
    }
    val rotation = when (motion) {
        IconMotion.ROTATE -> 360f * phase * amount
        IconMotion.SWAY -> (phase - 0.5f) * 12f * amount
        else -> 0f
    }
    Icon(icon, desc, tint = tint, modifier = modifier.graphicsLayer {
        scaleX = scale
        scaleY = scale
        rotationZ = rotation
    })
}

@Composable
private fun HeaderCard(hPad: Dp, content: @Composable RowScope.() -> Unit) {
    val shape = RoundedCornerShape(28.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = hPad, vertical = 10.dp)
            .clip(shape)
            .background(Color(0xFF020E34).copy(alpha = 0.92f))
            .border(1.dp, Color(0xFF14307A), shape)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        content = content
    )
}

@Composable
private fun RoundButton(icon: androidx.compose.ui.graphics.vector.ImageVector, desc: String, onClick: () -> Unit) {
    Box(
        Modifier
            .size(46.dp)
            .clip(CircleShape)
            .background(Color(0xFF041240))
            .border(1.dp, Color(0xFF1B3275), CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { TaskIcon(icon, desc, tint = Color(0xFFEAF0FF), modifier = Modifier.size(26.dp), motion = IconMotion.SWAY, active = true) }
}

/** لوجو الهيدر: مربع غامق وحرف M متدرج (أزرق ← بنفسجي). */
@Composable
private fun HeaderLogo(size: Dp) {
    Box(
        Modifier
            .size(size)
            .clip(RoundedCornerShape(size * 0.28f))
            .background(Color(0xFF01062E))
            .border(1.dp, Color(0xFF2A2FA8), RoundedCornerShape(size * 0.28f)),
        contentAlignment = Alignment.Center
    ) {
        Text(
            "M",
            style = TextStyle(
                brush = Brush.linearGradient(listOf(Color(0xFF4CB8FF), Color(0xFF9B4DFF))),
                fontWeight = FontWeight.Bold,
                fontSize = (size.value * 0.62f).sp,
            )
        )
    }
}

/** زرار + : قائمة جديدة / تحديث المكتبة. */
@Composable
private fun PlusMenu(onNewList: () -> Unit, onRefresh: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    Box {
        Box(
            Modifier
                .size(52.dp)
                .shadow(14.dp, CircleShape, ambientColor = Blue, spotColor = Blue)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(Color(0xFF2F8BFF), Violet)))
                .clickable { menu = true },
            contentAlignment = Alignment.Center
        ) { TaskIcon(Icons.Default.Add, tr("إضافة", "Add"), tint = Color.White, modifier = Modifier.size(30.dp), motion = IconMotion.ROTATE, active = menu) }
        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
            DropdownMenuItem(
                text = { Text(tr("قائمة جديدة", "New playlist"), fontFamily = Readex) },
                leadingIcon = { Icon(Icons.Default.QueueMusic, null) },
                onClick = { menu = false; onNewList() }
            )
            DropdownMenuItem(
                text = { Text(tr("تحديث المكتبة", "Refresh library"), fontFamily = Readex) },
                leadingIcon = { Icon(Icons.Default.Refresh, null) },
                onClick = { menu = false; onRefresh() }
            )
        }
    }
}

/** نقل الملفات المحددة لتصنيف تاني. */
@Composable
private fun MoveMenu(onMove: (Kind) -> Unit) {
    var menu by remember { mutableStateOf(false) }
    Box {
        IconButton(onClick = { menu = true }) { Icon(Icons.Default.Category, tr("نقل إلى", "Move to"), tint = Sky) }
        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
            Kind.values().forEach { k ->
                DropdownMenuItem(
                    text = { Text(tr("نقل إلى ${kindLabel(k)}", "Move to ${kindLabel(k)}"), fontFamily = Readex) },
                    onClick = { menu = false; onMove(k) }
                )
            }
        }
    }
}

@Composable
private fun GradientButton(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier
            .clip(shape)
            .background(Brush.horizontalGradient(listOf(Color(0xFF0B6BF9), Color(0xFF3A2BF0))))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(6.dp))
        Text(label, color = Color.White, fontFamily = Readex, fontSize = 14.sp)
    }
}

// =====================================================================
//  التبويبات
// =====================================================================

@Composable
private fun TabBar(tab: Int, hPad: Dp, onTab: (Int) -> Unit) {
    val bar = RoundedCornerShape(24.dp)
    val pill = RoundedCornerShape(19.dp)
    val icons = listOf(Icons.Rounded.RBook, Icons.Rounded.RList, Icons.Rounded.RQueue)
    Row(
        Modifier
            .padding(horizontal = hPad, vertical = 4.dp)
            .fillMaxWidth()
            .clip(bar)
            .background(CardFill.copy(alpha = 0.8f))
            .border(1.dp, CardLine, bar)
            .padding(5.dp)
    ) {
        tabLabels().forEachIndexed { i, label ->
            val on = tab == i
            Row(
                Modifier
                    .weight(1f)
                    .then(if (on) Modifier.shadow(12.dp, pill, ambientColor = Blue, spotColor = Blue) else Modifier)
                    .clip(pill)
                    .then(
                        if (on) Modifier
                            .background(Brush.horizontalGradient(listOf(Color(0xFF0B6BF9), Color(0xFF3A2BF0))))
                            .border(1.dp, Sky.copy(alpha = 0.6f), pill)
                        else Modifier
                    )
                    .clickable { onTab(i) }
                    .padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TaskIcon(icons[i], null, tint = if (on) Color(0xFFEAF0FF) else Color(0xFFA9B8F0), modifier = Modifier.size(24.dp), motion = IconMotion.PULSE, active = on)
                Spacer(Modifier.width(7.dp))
                Text(
                    label, color = if (on) Color.White else Color(0xFFA9B8F0), fontFamily = Readex,
                    fontWeight = if (on) FontWeight.Bold else FontWeight.Medium,
                    fontSize = 14.sp, maxLines = 1
                )
            }
        }
    }
}

// =====================================================================
//  أزرار التصنيف: أخرى / القرآن الكريم / أناشيد
// =====================================================================

private class CatStyle(
    val a: Color, val b: Color, val lineA: Color, val lineB: Color, val tile: Color, val glow: Color, val label: Color,
)

private fun catStyle(k: Kind, selected: Boolean): CatStyle = when (k) {
    Kind.NASHEED ->
        if (selected) CatStyle(Color(0xFF5A2BE0), Color(0xFF2A1FA6), Color(0xFFB39CFF), Color(0xFF2FB4FF), Color(0x55A97BFF), Color(0xFF6A3DFF), Color.White)
        else CatStyle(Color(0xFF241A78), Color(0xFF181156), Color(0xFF5A4BD0), Color(0xFF2A5BD0), Color(0x449B6BFF), Color(0xFF6A3DFF), Color(0xFFD5DCFF))
    Kind.QURAN ->
        if (selected) CatStyle(Color(0xFF0B52C8), Color(0xFF062C86), Color(0xFF6FC4FF), Color(0xFF2F6BFF), Color(0x554CB8FF), Color(0xFF2F8BFF), Color.White)
        else CatStyle(Color(0xFF00266E), Color(0xFF001850), Color(0xFF1E8FE0), Color(0xFF1B4FB0), Color(0xFF0A3F8C), Color(0xFF1E8FE0), Color(0xFFD5DCFF))
    Kind.OTHER ->
        if (selected) CatStyle(Color(0xFF0C7A94), Color(0xFF064A66), Color(0xFF7FE3EE), Color(0xFF1AA3B8), Color(0x554CE0F0), Color(0xFF14A0B0), Color.White)
        else CatStyle(Color(0xFF003B5E), Color(0xFF002A46), Color(0xFF15A0BE), Color(0xFF0B5E7E), Color(0xFF0E6A8E), Color(0xFF14A0B0), Color(0xFFD5DCFF))
}

private fun catIcon(k: Kind) = when (k) {
    Kind.NASHEED -> Icons.Rounded.RNote
    Kind.QURAN -> Icons.Rounded.RBook
    Kind.OTHER -> Icons.Rounded.RGrid
}

@Composable
private fun CategoryRow(cat: Kind, hPad: Dp, onPick: (Kind) -> Unit) {
    // الترتيب زي التصميم: أخرى، القرآن الكريم، أناشيد (من اليمين لليسار)
    Row(
        Modifier.padding(horizontal = hPad, vertical = 8.dp).fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        listOf(Kind.OTHER, Kind.QURAN, Kind.NASHEED).forEach { k ->
            CatButton(k, cat == k, Modifier.weight(1f)) { onPick(k) }
        }
    }
}

@Composable
private fun CatButton(kind: Kind, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    val st = catStyle(kind, selected)
    Row(
        modifier
            .shadow(if (selected) 18.dp else 6.dp, shape, ambientColor = st.glow, spotColor = st.glow)
            .clip(shape)
            .background(Brush.linearGradient(listOf(st.a, st.b)))
            .border(if (selected) 1.5.dp else 1.dp, Brush.linearGradient(listOf(st.lineA, st.lineB)), shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 6.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // الاسم على اليمين في سطر واحد، والأيقونة على الشمال (زي التصميم)
        Text(
            kindLabel(kind), color = st.label,
            fontFamily = Readex, fontSize = 12.sp, softWrap = false, maxLines = 1,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            modifier = Modifier.weight(1f)
        )
        Spacer(Modifier.width(4.dp))
        Box(
            Modifier.size(36.dp).clip(RoundedCornerShape(12.dp)).background(st.tile),
            contentAlignment = Alignment.Center
        ) { TaskIcon(catIcon(kind), null, tint = Color(0xFFF2F5FF), modifier = Modifier.size(24.dp), motion = IconMotion.PULSE, active = selected) }
    }
}

// =====================================================================
//  البحث + تشغيل متتابع + عشوائي
// =====================================================================

@Composable
private fun ActionCard(
    hPad: Dp, query: String, onQuery: (String) -> Unit, enabled: Boolean,
    onSequential: () -> Unit, onShuffle: () -> Unit,
) {
    val shape = RoundedCornerShape(24.dp)
    val field = RoundedCornerShape(18.dp)
    Row(
        Modifier
            .padding(horizontal = hPad, vertical = 8.dp)
            .fillMaxWidth()
            .clip(shape)
            .background(CardFill.copy(alpha = 0.8f))
            .border(1.dp, CardLine, shape)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            Modifier
                .weight(1f)
                .clip(field)
                .background(FieldFill)
                .border(1.dp, CardLine, field)
                .padding(horizontal = 12.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TaskIcon(Icons.Default.Search, null, tint = Color(0xFFA78BFF), modifier = Modifier.size(22.dp), motion = IconMotion.PULSE, active = query.isNotEmpty())
            Spacer(Modifier.width(8.dp))
            Box(Modifier.weight(1f)) {
                if (query.isEmpty()) Text(
                    tr("ابحث في المكتبة...", "Search the library..."), color = Mut, fontFamily = Readex,
                    fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                BasicTextField(
                    value = query,
                    onValueChange = onQuery,
                    singleLine = true,
                    textStyle = TextStyle(color = Tx, fontFamily = Readex, fontSize = 15.sp),
                    cursorBrush = SolidColor(Sky),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
        Spacer(Modifier.width(6.dp))
        ActionButton(Icons.Default.Repeat, tr("تشغيل متتابع", "Play all"), enabled, onSequential)
        Box(Modifier.width(1.dp).height(38.dp).background(CardLine))
        ActionButton(Icons.Default.Shuffle, tr("عشوائي", "Shuffle"), enabled, onShuffle)
    }
}

@Composable
private fun ActionButton(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, enabled: Boolean, onClick: () -> Unit) {
    var fired by remember { mutableStateOf(false) }
    LaunchedEffect(fired) {
        if (fired) {
            kotlinx.coroutines.delay(520)
            fired = false
        }
    }
    val isShuffle = label.contains("عشوائي") || label.contains("Shuffle", true)
    Column(
        Modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable(enabled = enabled) { fired = true; onClick() }
            .padding(horizontal = 10.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        TaskIcon(
            icon, label, tint = if (enabled) Color(0xFF8C9CFF) else Mut.copy(alpha = 0.4f),
            modifier = Modifier.size(26.dp),
            motion = if (isShuffle) IconMotion.SWAY else IconMotion.ROTATE,
            active = fired,
        )
        Text(label, color = if (enabled) Mut else Mut.copy(alpha = 0.4f), fontFamily = Readex, fontSize = 11.sp, maxLines = 1)
    }
}

// =====================================================================
//  المحتوى
// =====================================================================

@Composable
private fun MiniHost(vm: MainVM, track: Track, playing: Boolean, idle: Boolean, onOpen: () -> Unit, modifier: Modifier) {
    val progress by vm.progress.collectAsState()
    MiniPlayer(track, playing, idle, progress, vm::toggle, vm::next, vm::prev, onOpen, modifier)
}

@Composable
private fun FullHost(vm: MainVM, track: Track, playing: Boolean, micOk: Boolean, onClose: () -> Unit, onSettings: () -> Unit) {
    val progress by vm.progress.collectAsState()
    val position by vm.position.collectAsState()
    val duration by vm.duration.collectAsState()
    val shuffle by vm.shuffle.collectAsState()
    val repeat by vm.repeat.collectAsState()
    FullPlayer(
        track = track, playing = playing, progress = progress, position = position, duration = duration,
        shuffle = shuffle, repeat = repeat, onClose = onClose,
        onToggle = vm::toggle, onNext = vm::next, onPrev = vm::prev, onSeek = vm::seekToFraction,
        onShuffle = vm::toggleShuffle, onRepeat = vm::cycleRepeat, onSettings = onSettings, micOk = micOk,
    )
}

@Composable
private fun Empty(msg: String, btn: String, onClick: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(msg, color = Mut, fontFamily = Readex, fontSize = 15.sp)
        Spacer(Modifier.height(16.dp))
        GradientButton(btn, Icons.Default.Refresh, onClick)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun TrackRow(
    t: Track, active: Boolean, playing: Boolean, selected: Boolean, actions: RowActions,
    onClick: () -> Unit, onLong: () -> Unit,
) {
    val shape = RoundedCornerShape(22.dp)
    var menu by remember { mutableStateOf(false) }
    val fill = when {
        selected -> Blue.copy(alpha = 0.35f)
        active -> Color(0xFF0A2468)
        else -> CardFill.copy(alpha = 0.85f)
    }
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp)
            .then(if (active || selected) Modifier.shadow(14.dp, shape, ambientColor = Violet, spotColor = Blue) else Modifier)
            .clip(shape)
            .background(fill)
            .border(if (active || selected) 1.5.dp else 1.dp, if (active || selected) Color(0xFF5B8CFF) else CardLine, shape)
            .combinedClickable(onClick = onClick, onLongClick = onLong)
            .padding(horizontal = 12.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // في الواجهة العربية أول عنصر يظهر ناحية اليمين: غلاف مربع، أو M إذا مفيش غلاف.
        Art(t, 54.dp, 160, RoundedCornerShape(15.dp))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    t.title, modifier = Modifier.weight(1f),
                    color = if (active) Color.White else Tx, fontFamily = Readex,
                    fontWeight = FontWeight.Bold, fontSize = 16.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                if (active) {
                    Spacer(Modifier.width(8.dp))
                    WaveBars(on = playing, modifier = Modifier.width(42.dp).height(24.dp))
                }
            }
            Spacer(Modifier.height(3.dp))
            Text(
                "${t.artist.ifBlank { kindLabel(t.kind) }} · ${formatTime(t.durationMs)}",
                color = Mut, fontFamily = Readex, fontSize = 13.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        Box {
            IconButton(onClick = { menu = true }) {
                Icon(Icons.Outlined.OSettings, tr("خيارات", "Options"), tint = Color(0xFFA9B8FF), modifier = Modifier.size(26.dp))
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(
                    text = { Text(tr("تعديل الاسم", "Edit"), fontFamily = Readex) },
                    onClick = { menu = false; actions.edit(t) }
                )
                DropdownMenuItem(
                    text = { Text(tr("إضافة لقائمة", "Add to playlist"), fontFamily = Readex) },
                    onClick = { menu = false; actions.addToList(t) }
                )
                Kind.values().filter { it != t.kind }.forEach { k ->
                    DropdownMenuItem(
                        text = { Text(tr("نقل إلى ${kindLabel(k)}", "Move to ${kindLabel(k)}"), fontFamily = Readex) },
                        onClick = { menu = false; actions.move(t, k) }
                    )
                }
                DropdownMenuItem(
                    text = { Text(tr("إخفاء من التطبيق", "Hide from app"), fontFamily = Readex) },
                    onClick = { menu = false; actions.hide(t) }
                )
            }
        }
        // سهم فتح الملف في أقصى اليسار.
        Icon(Icons.Default.ChevronLeft, null, tint = Mut, modifier = Modifier.size(22.dp))
    }
}

@Composable
private fun PlaylistRow(p: Playlist, onOpen: () -> Unit, onRename: () -> Unit, onDelete: () -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    var menu by remember { mutableStateOf(false) }
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp)
            .clip(shape)
            .background(CardFill.copy(alpha = 0.85f))
            .border(1.dp, CardLine, shape)
            .clickable(onClick = onOpen)
            .padding(horizontal = 12.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.ChevronRight, null, tint = Mut, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(6.dp))
        Box(
            Modifier.size(54.dp).clip(RoundedCornerShape(15.dp))
                .background(Brush.linearGradient(listOf(LogoA, LogoB))),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Default.QueueMusic, null, tint = Color.White, modifier = Modifier.size(26.dp)) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(p.name, color = Tx, fontFamily = Readex, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(tr("${p.ids.size} ملف", "${p.ids.size} files"), color = Mut, fontFamily = Readex, fontSize = 13.sp)
        }
        Box {
            IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, tr("خيارات", "Options"), tint = Color(0xFF8C9CFF)) }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text(tr("تغيير الاسم", "Rename"), fontFamily = Readex) }, onClick = { menu = false; onRename() })
                DropdownMenuItem(text = { Text(tr("حذف القائمة", "Delete playlist"), fontFamily = Readex) }, onClick = { menu = false; onDelete() })
            }
        }
    }
}

/** المشغّل المصغّر: بيظهر تحت دايمًا ومعاه آخر حاجة اتشغلت. */
@Composable
private fun MiniPlayer(
    track: Track, playing: Boolean, idle: Boolean, progress: Float,
    onToggle: () -> Unit, onNext: () -> Unit, onPrev: () -> Unit, onOpen: () -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(28.dp)
    val status = when {
        idle -> tr("آخر ما شغّلته", "Last played")
        playing -> tr("يتم التشغيل الآن", "Now playing")
        else -> tr("متوقف مؤقتًا", "Paused")
    }
    Column(
        modifier
            .widthIn(max = 720.dp)
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 12.dp, vertical = 10.dp)
            .shadow(20.dp, shape, ambientColor = Violet, spotColor = Blue)
            .clip(shape)
            .background(Brush.horizontalGradient(listOf(Color(0xFF0B2A80), Color(0xFF2A1A92))))
            .border(1.5.dp, Brush.horizontalGradient(listOf(Sky, Violet)), shape)
            .clickable(onClick = onOpen)
    ) {
        Row(
            Modifier.padding(start = 12.dp, end = 12.dp, top = 10.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Art(track, 52.dp, 128, RoundedCornerShape(16.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(status, color = Sky, fontFamily = Readex, fontSize = 11.sp, maxLines = 1)
                Text(
                    track.title, color = Color.White, fontFamily = Readex, fontWeight = FontWeight.Bold,
                    fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text(
                    when (track.kind) {
                        Kind.NASHEED -> tr("أنشودة", "Nasheed")
                        Kind.QURAN -> tr("القرآن الكريم", "Quran")
                        Kind.OTHER -> tr("أخرى", "Other")
                    }, color = Mut, fontFamily = Readex,
                    fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
            // أزرار التحكم دايمًا من الشمال لليمين
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onPrev) { Icon(Icons.Default.SkipPrevious, tr("السابق", "Previous"), tint = Tx) }
                    Box(
                        Modifier.size(48.dp).pulseRing(playing).clip(CircleShape)
                            .background(Brush.linearGradient(listOf(Blue, Violet)))
                            .clickable(onClick = onToggle),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, tr("تشغيل/إيقاف", "Play/Pause"), tint = Color.White, modifier = Modifier.size(28.dp))
                    }
                    IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, tr("التالي", "Next"), tint = Tx) }
                }
            }
        }
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier.fillMaxWidth().height(3.dp),
            color = Sky, trackColor = Color.White.copy(alpha = 0.08f)
        )
    }
}
