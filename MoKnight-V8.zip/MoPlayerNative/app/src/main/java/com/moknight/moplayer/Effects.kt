package com.moknight.moplayer

import android.graphics.Bitmap
import android.media.audiofx.Visualizer
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.pow
import kotlin.math.sin
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext

/**
 * خلفية حية (زي خلفية نسخة الويب): هالات ضوء كبيرة بتسبح ببطء، أرضية مضيئة بتتنفس،
 * ستائر شفق ناعمة، وغبار ضوء صغير بيطلع لفوق. لو فيه تشغيل الهالات بتنبض مع الإيقاع.
 */
@Composable
fun LivingBg(modifier: Modifier = Modifier, strength: Float = 0.48f, playing: Boolean = false) {
    val inf = rememberInfiniteTransition(label = "bg")
    // دورة 60 ثانية، وكل الحركات مضاعفات صحيحة منها فبتتكرر من غير قفزة
    val t by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(60000, easing = LinearEasing)), label = "t")
    val live by animateFloatAsState(if (playing) 1.35f else 1f, tween(900), label = "live")
    val dust = remember {
        List(26) { i ->
            val r1 = ((i * 7919) % 1000) / 1000f
            val r2 = ((i * 104729) % 997) / 997f
            val r3 = ((i * 15485863) % 991) / 991f
            floatArrayOf(r1, r2, r3)
        }
    }
    Canvas(modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val tau = 6.2831855f
        val k = strength * live

        fun orb(color: Color, cx: Float, cy: Float, r: Float, a: Float) {
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(color.copy(alpha = (a * k).coerceIn(0f, 1f)), Color.Transparent),
                    center = Offset(cx, cy), radius = r
                ),
                radius = r, center = Offset(cx, cy)
            )
        }

        val beat = if (playing) 1f + 0.05f * sin(t * tau * 30f) else 1f
        // ثلاث هالات بتتحرك في مسارات بيضاوية وبتكبر وتصغر
        orb(Blue, w * (0.22f + 0.20f * sin(t * tau * 3f)), h * (0.20f + 0.12f * sin(t * tau * 2f + 1f)), w * (0.80f + 0.10f * sin(t * tau * 5f)) * beat, 0.62f)
        orb(Sky, w * (0.80f + 0.16f * sin(t * tau * 2f + 2f)), h * (0.55f + 0.14f * sin(t * tau * 3f + 4f)), w * (0.72f + 0.10f * sin(t * tau * 4f)) * beat, 0.5f)
        orb(Color(0xFF6A3DFF), w * (0.30f + 0.26f * sin(t * tau * 2f + 3f)), h * (0.86f + 0.07f * sin(t * tau * 3f + 1f)), w * (0.78f + 0.10f * sin(t * tau * 3f + 2f)) * beat, 0.55f)

        // أرضية مضيئة بتتنفس من تحت
        val breathe = 0.55f + 0.45f * sin(t * tau * 6f)
        drawRect(
            brush = Brush.verticalGradient(
                listOf(Color.Transparent, Blue.copy(alpha = (0.34f * breathe * k * 1.4f).coerceIn(0f, 1f))),
                startY = h * 0.55f, endY = h
            ),
            topLeft = Offset(0f, h * 0.55f), size = Size(w, h * 0.45f)
        )

        // ستائر شفق ناعمة
        val a1 = 0.5f + 0.5f * sin(t * tau * 2f)
        val b1 = 0.5f + 0.5f * sin(t * tau * 3f + 1.3f)
        val c1 = 0.5f + 0.5f * sin(t * tau * 2f + 2.6f)
        val aurora1 = Path().apply {
            moveTo(-w * 0.15f, h * (0.48f + 0.10f * a1))
            cubicTo(w * 0.22f, h * (0.30f + 0.12f * b1), w * 0.58f, h * (0.70f - 0.12f * c1), w * 1.15f, h * (0.38f + 0.10f * a1))
            lineTo(w * 1.15f, h * 0.58f)
            cubicTo(w * 0.62f, h * (0.88f - 0.12f * b1), w * 0.28f, h * (0.42f + 0.10f * c1), -w * 0.15f, h * 0.68f)
            close()
        }
        drawPath(aurora1, Brush.verticalGradient(listOf(Color(0xFF185BFF).copy(alpha = 0.10f * k), Color(0xFF6B35FF).copy(alpha = 0.05f * k), Color.Transparent), startY = h * 0.28f, endY = h * 0.78f))
        val aurora2 = Path().apply {
            moveTo(-w * 0.1f, h * (0.78f - 0.08f * c1))
            cubicTo(w * 0.3f, h * (0.60f + 0.12f * a1), w * 0.66f, h * (0.92f - 0.10f * b1), w * 1.1f, h * (0.65f + 0.08f * c1))
            lineTo(w * 1.1f, h * 0.82f)
            cubicTo(w * 0.66f, h * 1.02f, w * 0.28f, h * (0.76f + 0.08f * b1), -w * 0.1f, h * 0.94f)
            close()
        }
        drawPath(aurora2, Brush.verticalGradient(listOf(Color(0xFF572BFF).copy(alpha = 0.09f * k), Color.Transparent), startY = h * 0.62f, endY = h))

        // خيوط ضوء متموجة بتتحرك ببطء
        val colors = listOf(Color(0xFF168BFF), Color(0xFF6B55FF), Color(0xFF20BFFF))
        val ys = listOf(0.34f, 0.63f, 0.82f)
        for (j in 0 until 3) {
            val ph = t * tau * (j + 2)
            val p = Path()
            for (i in 0..48) {
                val x = w * i / 48f
                val y = h * ys[j] + sin(i * 0.17f + ph) * h * 0.035f + sin(i * 0.07f - ph * 0.7f) * h * 0.018f
                if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
            }
            drawPath(p, colors[j].copy(alpha = (0.16f * k).coerceIn(0f, 1f)), style = Stroke(1.4.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        }

        // غبار ضوء صغير بيطلع لفوق
        for (i in dust.indices) {
            val d = dust[i]
            val speed = 1 + (i % 3)
            val life = (t * speed + d[1]) % 1f
            val x = w * d[0] + sin(t * tau * 2f + d[2] * tau) * w * 0.03f
            val y = h * (1.06f - life * 1.12f)
            val fade = sin(life * 3.1415927f)
            val rad = (1.2f + d[2] * 2.2f).dp.toPx()
            val col = if (i % 2 == 0) Sky else Color(0xFFB8A6FF)
            drawCircle(col.copy(alpha = (0.55f * fade * live).coerceIn(0f, 1f)), radius = rad, center = Offset(x, y))
            drawCircle(col.copy(alpha = (0.14f * fade * live).coerceIn(0f, 1f)), radius = rad * 3.2f, center = Offset(x, y))
        }
    }
}

/** موجة صوت صغيرة بتتحرك في الصف اللي شغال دلوقتي. */
@Composable
fun WaveBars(on: Boolean, modifier: Modifier = Modifier) {
    val tr = rememberInfiniteTransition(label = "wave")
    val ph by tr.animateFloat(0f, 6.2832f, infiniteRepeatable(tween(1300, easing = LinearEasing), RepeatMode.Restart), label = "ph")
    Canvas(modifier) {
        val n = 14
        val gap = 4.dp.toPx()
        val bw = (size.width - gap * (n - 1)) / n
        for (i in 0 until n) {
            val base = 0.3f + 0.7f * abs(sin(i * 0.9f))
            val f = if (on) 0.55f + 0.45f * sin(ph + i * 0.7f) else 0.45f
            val h = (size.height * base * f).coerceAtLeast(4.dp.toPx())
            val a = 0.15f + 0.85f * (1f - abs(i - (n - 1) / 2f) / ((n - 1) / 2f))
            drawRoundRect(
                color = Color(0xFF5B55F0).copy(alpha = a),
                topLeft = Offset(i * (bw + gap), (size.height - h) / 2f),
                size = Size(bw, h),
                cornerRadius = CornerRadius(bw / 2f)
            )
        }
    }
}

/** غلاف الأغنية مطموس كخلفية للمشغّل الكامل. */
@Composable
fun CoverBg(t: Track, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, t.id) {
        value = withContext(Dispatchers.IO) { ArtLoader.load(ctx, t, 640) }
    }
    bmp?.let {
        Image(
            it.asImageBitmap(), null, contentScale = ContentScale.Crop,
            modifier = modifier.fillMaxSize().blur(50.dp).alpha(0.5f)
        )
    }
}

/** حلقة نبض حوالين زر التشغيل وقت التشغيل. */
@Composable
fun Modifier.pulseRing(on: Boolean): Modifier {
    if (!on) return this
    val tr = rememberInfiniteTransition(label = "ring")
    val p by tr.animateFloat(0f, 1f, infiniteRepeatable(tween(1600, easing = LinearOutSlowInEasing)), label = "p")
    return this.drawBehind {
        val r = size.minDimension / 2
        drawCircle(Sky.copy(alpha = (1f - p) * 0.55f), radius = r * (1f + p * 0.55f), style = Stroke(2.dp.toPx()))
    }
}

/** المؤثر المرئي: حقيقي لو الإذن موجود، وحركة تزيينية لو مفيش إذن. */
@Composable
fun VizBars(sessionId: Int, micOk: Boolean, playing: Boolean, modifier: Modifier = Modifier) {
    val n = 36
    val bars = remember { FloatArray(n) }
    var frame by remember { mutableIntStateOf(0) }

    LaunchedEffect(sessionId, micOk, playing) {
        var viz: Visualizer? = null
        if (micOk && sessionId != 0 && playing) {
            viz = runCatching {
                Visualizer(sessionId).also {
                    it.setCaptureSize(Visualizer.getCaptureSizeRange()[1].coerceAtMost(1024))
                    it.setEnabled(true)
                }
            }.getOrNull()
        }
        val buf = viz?.let { ByteArray(it.captureSize) }
        try {
            var tm = 0f
            while (isActive) {
                val target = FloatArray(n)
                if (viz != null && buf != null && viz.getFft(buf) == Visualizer.SUCCESS) {
                    val bins = buf.size / 2
                    for (i in 0 until n) {
                        val lo = bins.toDouble().pow(i / n.toDouble()).toInt().coerceAtLeast(1)
                        val hi = bins.toDouble().pow((i + 1) / n.toDouble()).toInt().coerceIn(lo + 1, bins)
                        var mx = 0f
                        for (k in lo until hi) {
                            if (2 * k + 1 < buf.size) {
                                mx = maxOf(mx, hypot(buf[2 * k].toFloat(), buf[2 * k + 1].toFloat()))
                            }
                        }
                        target[i] = (mx / 110f).coerceIn(0f, 1f).pow(0.6f)
                    }
                } else if (playing) {
                    tm += 0.12f
                    for (i in 0 until n) {
                        target[i] = ((0.25f + 0.2f * sin(tm * 1.3f + i * 0.5f) + 0.15f * sin(tm * 2.1f + i * 1.1f))
                            .coerceIn(0.05f, 1f)) * 0.6f
                    }
                }
                for (i in 0 until n) {
                    bars[i] = if (target[i] > bars[i]) bars[i] + (target[i] - bars[i]) * 0.6f else bars[i] * 0.88f
                }
                frame++
                delay(33)
            }
        } finally {
            runCatching { viz?.setEnabled(false); viz?.release() }
        }
    }

    Canvas(modifier.fillMaxWidth().height(56.dp)) {
        @Suppress("UNUSED_VARIABLE") val tick = frame
        val gap = 4.dp.toPx()
        val bw = (size.width - gap * (n - 1)) / n
        for (i in 0 until n) {
            val h = (bars[i] * size.height).coerceAtLeast(3.dp.toPx())
            drawRoundRect(
                brush = Brush.verticalGradient(listOf(Sky, Blue), startY = size.height - h, endY = size.height),
                topLeft = Offset(i * (bw + gap), size.height - h),
                size = Size(bw, h),
                cornerRadius = CornerRadius(bw / 2)
            )
        }
    }
}
