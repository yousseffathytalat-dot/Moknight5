package com.moknight.moplayer

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player

/** مشغّل كامل بتصميم ليلي أزرق/بنفسجي، مع غلاف كبير وتحكم واضح. */
@Composable
fun FullPlayer(
    track: Track,
    playing: Boolean,
    progress: Float,
    position: Long,
    duration: Long,
    shuffle: Boolean,
    repeat: Int,
    onClose: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onPrev: () -> Unit,
    onSeek: (Float) -> Unit,
    onShuffle: () -> Unit,
    onRepeat: () -> Unit,
    onOptions: () -> Unit,
    onPlayback: () -> Unit,
    playbackDot: Boolean,
    micOk: Boolean,
) {
    BoxWithConstraints(
        Modifier.fillMaxSize().background(AppBg)
            .pointerInput(Unit) { detectTapGestures { } }
    ) {
        val boxW = maxWidth
        val boxH = maxHeight
        val landscape = boxW > boxH * 1.15f
        CoverBg(track)
        LivingBg(strength = 0.8f, playing = playing)
        Box(Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xCC020A2A), Color(0xEE020A25), Bg0.copy(alpha = 0.96f)))
        ))

        val cover: @Composable (androidx.compose.ui.unit.Dp) -> Unit = { s ->
            val sc by animateFloatAsState(
                if (playing) 1f else 0.96f,
                spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
                label = "cover"
            )
            Box(
                Modifier.size(s).glow(Violet, 30.dp, 38.dp) { if (playing) 0.75f else 0.4f }
                    .clip(RoundedCornerShape(38.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF073A9A), Color(0xFF27106D))))
                    .border(1.5.dp, Brush.linearGradient(listOf(Sky, Violet)), RoundedCornerShape(38.dp))
                    .padding(3.dp)
            ) {
                Art(track, s - 6.dp, 900, RoundedCornerShape(35.dp), Modifier.graphicsLayer { scaleX = sc; scaleY = sc })
            }
        }

        if (landscape) {
            val coverSize = minOf(boxW * 0.38f, boxH - 90.dp, 420.dp).coerceAtLeast(120.dp)
            Row(
                Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.Center) { cover(coverSize) }
                Spacer(Modifier.width(18.dp))
                Column(
                    Modifier.weight(1.2f).fillMaxHeight().verticalScroll(rememberScrollState()),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    TopBar(onClose, onOptions)
                    Spacer(Modifier.height(8.dp))
                    PlayerPanel(track, playing, progress, position, duration, shuffle, repeat,
                        onToggle, onNext, onPrev, onSeek, onShuffle, onRepeat, micOk, onPlayback, playbackDot)
                }
            }
        } else {
            Column(
                Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
                    .padding(horizontal = 22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                TopBar(onClose, onOptions)
                Spacer(Modifier.weight(0.25f))
                val coverSize = minOf(boxW - 30.dp, boxH * 0.39f, 440.dp).coerceAtLeast(120.dp)
                cover(coverSize)
                Spacer(Modifier.height(22.dp))
                PlayerPanel(track, playing, progress, position, duration, shuffle, repeat,
                    onToggle, onNext, onPrev, onSeek, onShuffle, onRepeat, micOk, onPlayback, playbackDot)
                Spacer(Modifier.weight(0.45f))
            }
        }
    }
}

@Composable
private fun TopBar(onClose: () -> Unit, onSettings: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(top = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        PlayerRoundButton(Icons.Default.MoreHoriz, tr("خيارات", "Options"), onSettings, 48)
        Text(
            "MoKnight",
            color = Color(0xFFEAF2FF),
            fontFamily = androidx.compose.ui.text.font.FontFamily.Serif,
            fontWeight = FontWeight.Bold,
            fontSize = 25.sp,
            maxLines = 1,
            modifier = Modifier.weight(1f),
            textAlign = TextAlign.Center
        )
        PlayerRoundButton(Icons.Default.KeyboardArrowDown, tr("رجوع", "Back"), onClose, 48)
    }
}

@Composable
private fun PlayerRoundButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit,
    size: Int
) {
    Box(
        Modifier.size(size.dp).clip(CircleShape)
            .background(Brush.linearGradient(listOf(Color(0xFF102D75), Color(0xFF091945))))
            .border(1.dp, Color(0xFF3554B4), CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, label, tint = Color(0xFFEAF1FF), modifier = Modifier.size(29.dp))
    }
}

@Composable
private fun PlayerPanel(
    track: Track, playing: Boolean, progress: Float, position: Long, duration: Long,
    shuffle: Boolean, repeat: Int,
    onToggle: () -> Unit, onNext: () -> Unit, onPrev: () -> Unit, onSeek: (Float) -> Unit,
    onShuffle: () -> Unit, onRepeat: () -> Unit, micOk: Boolean,
    onPlayback: () -> Unit, playbackDot: Boolean,
) {
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            track.title, color = Color.White, fontFamily = Readex, fontWeight = FontWeight.Bold,
            fontSize = 23.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
        )
        Text(
            when (track.kind) {
                Kind.NASHEED -> tr("أنشودة", "Nasheed")
                Kind.QURAN -> tr("القرآن الكريم", "Quran")
                Kind.OTHER -> tr("أخرى", "Other")
            },
            color = Color(0xFF9DB8FF), fontFamily = Readex, fontSize = 16.sp,
            maxLines = 1, textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(top = 5.dp)
        )

        Spacer(Modifier.height(12.dp))
        VizBars(AudioBus.sessionId, micOk, playing)
        Spacer(Modifier.height(4.dp))

        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            var drag by remember(track.id) { mutableStateOf<Float?>(null) }
            val value = (drag ?: progress).coerceIn(0f, 1f)
            Slider(
                value = value,
                onValueChange = { drag = it },
                onValueChangeFinished = { drag?.let(onSeek); drag = null },
                colors = SliderDefaults.colors(
                    thumbColor = Color(0xFFB8F7FF),
                    activeTrackColor = Color(0xFF13CFFF),
                    inactiveTrackColor = Color(0xFF244783),
                ),
                modifier = Modifier.fillMaxWidth()
            )
            Row(Modifier.fillMaxWidth().padding(horizontal = 5.dp)) {
                Text(formatTime(if (drag != null) (duration * value).toLong() else position),
                    color = Color(0xFFAEC6FF), fontFamily = Readex, fontSize = 13.sp)
                Spacer(Modifier.weight(1f))
                Text(formatTime(duration), color = Color(0xFFAEC6FF), fontFamily = Readex, fontSize = 13.sp)
            }
            Spacer(Modifier.height(12.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                PlayerControl(Icons.Default.Shuffle, tr("عشوائي", "Shuffle"), shuffle, onShuffle, 54)
                PlayerControl(Icons.Default.SkipPrevious, tr("السابق", "Previous"), false, onPrev, 54, 34)
                Box(
                    Modifier.size(78.dp).glow(Blue, 20.dp, 39.dp) { if (playing) 0.8f else 0.45f }
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(Color(0xFF05A9FF), Color(0xFF283BFF), Color(0xFF7C1DFF))))
                        .border(2.dp, Color(0xFF70E9FF), CircleShape).bounceClick(onClick = onToggle),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow,
                        tr("تشغيل/إيقاف", "Play/Pause"), tint = Color.White, modifier = Modifier.size(42.dp))
                }
                PlayerControl(Icons.Default.SkipNext, tr("التالي", "Next"), false, onNext, 54, 34)
                PlayerControl(
                    if (repeat == Player.REPEAT_MODE_ONE) Icons.Default.RepeatOne else Icons.Default.Repeat,
                    tr("تكرار", "Repeat"), repeat != Player.REPEAT_MODE_OFF, onRepeat, 54
                )
            }
        }

        Spacer(Modifier.height(15.dp))
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(30.dp))
                .background(Color(0xB9081A49))
                .border(1.dp, Color(0xFF243E91), RoundedCornerShape(30.dp))
                .padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                Modifier.weight(1.1f).clip(RoundedCornerShape(24.dp))
                    .background(Brush.horizontalGradient(listOf(Color(0xFF0C4AB4), Color(0xFF171E70))))
                    .border(1.dp, Color(0xFF2455D4), RoundedCornerShape(24.dp))
                    .padding(horizontal = 10.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    when (track.kind) {
                        Kind.NASHEED -> Icons.Default.MusicNote
                        Kind.QURAN -> Icons.Default.MenuBook
                        Kind.OTHER -> Icons.Default.GridView
                    }, null, tint = Color(0xFF24D8FF), modifier = Modifier.size(23.dp)
                )
                Spacer(Modifier.width(7.dp))
                Text(
                    when (track.kind) {
                        Kind.NASHEED -> tr("أناشيد", "Nasheeds")
                        Kind.QURAN -> tr("القرآن الكريم", "Quran")
                        Kind.OTHER -> tr("أخرى", "Other")
                    }, color = Color.White, fontFamily = Readex, fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(Modifier.width(8.dp))
            Column(
                Modifier.weight(0.8f).clip(RoundedCornerShape(24.dp)).bounceClick(onClick = onPlayback)
                    .padding(horizontal = 4.dp, vertical = 3.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box {
                    GearIcon(Color(0xFF79BFFF), 23.dp, spinKey = 0, idle = true)
                    if (playbackDot) Box(Modifier.size(8.dp).align(Alignment.TopEnd).clip(CircleShape).background(Sky))
                }
                Text(tr("إعدادات التشغيل", "Playback"), color = Color(0xFFD8E5FF), fontFamily = Readex, fontSize = 12.sp, maxLines = 1)
            }
        }
    }
}

@Composable
private fun PlayerControl(
    icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, active: Boolean,
    onClick: () -> Unit, size: Int, iconSize: Int = 27
) {
    Box(
        Modifier.size(size.dp).clip(CircleShape)
            .background(if (active) Color(0xFF142C86) else Color(0x990A1D4B))
            .border(1.dp, if (active) Violet else Color(0xFF263F87), CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, label, tint = if (active) Color(0xFF41D9FF) else Color.White,
            modifier = Modifier.size(iconSize.dp))
    }
}

@Composable
private fun RowScope.BottomMode(
    icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, active: Boolean, onClick: () -> Unit
) {
    Column(
        Modifier.weight(0.8f).clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick)
            .padding(horizontal = 4.dp, vertical = 3.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, label, tint = if (active) Color(0xFF40D9FF) else Color(0xFF79BFFF),
            modifier = Modifier.size(23.dp))
        Text(label, color = Color(0xFFD8E5FF), fontFamily = Readex, fontSize = 12.sp, maxLines = 1)
    }
}
