package com.moknight.moplayer

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

/**
 * الطبقة المركزية (زي طبقة نسخة الـ APK): بتفتح من النص بتكبير ناعم، بكيرفات كبيرة وجلو أزرق،
 * وعناصرها بتظهر واحدورا التاني.
 */
@Composable
fun LayerDialog(title: String, onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        val vis = remember { MutableTransitionState(false).apply { targetState = true } }
        Box(
            Modifier
                .fillMaxSize()
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onDismiss)
                .padding(horizontal = 18.dp, vertical = 24.dp),
            contentAlignment = Alignment.Center
        ) {
            AnimatedVisibility(
                visibleState = vis,
                enter = fadeIn(tween(200)) + scaleIn(initialScale = 0.86f, animationSpec = spring(dampingRatio = 0.7f, stiffness = 380f)),
            ) {
                LayerCard(title, content)
            }
        }
    }
}

@Composable
private fun LayerCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(36.dp)
    val inf = rememberInfiniteTransition(label = "layer")
    val pulse by inf.animateFloat(0.55f, 1f, infiniteRepeatable(tween(2600, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse")
    val maxH = (LocalConfiguration.current.screenHeightDp * 0.82f).dp
    Column(
        Modifier
            .widthIn(max = 400.dp)
            .fillMaxWidth()
            .heightIn(max = maxH)
            .glow(Blue, 28.dp, 36.dp) { 0.6f * pulse }
            .clip(shape)
            .background(Brush.linearGradient(listOf(Color(0xFF10307A).copy(alpha = 0.97f), Color(0xFF060F2A).copy(alpha = 0.98f))))
            .border(1.dp, Brush.linearGradient(listOf(Color(0xFF4C96FF).copy(alpha = 0.75f), Color(0xFF6A3DFF).copy(alpha = 0.45f))), shape)
            .pointerInput(Unit) { detectTapGestures { } }
            .padding(18.dp)
    ) {
        Text(
            title, color = Color.White, fontFamily = Readex, fontWeight = FontWeight.Bold, fontSize = 19.sp,
            maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(start = 4.dp, end = 4.dp, top = 2.dp, bottom = 14.dp).staggerIn(0)
        )
        Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState())) { content() }
    }
}

/** سطر في الطبقة: أيقونة + اسم + قيمة اختيارية. */
@Composable
fun LayerItem(
    label: String,
    index: Int,
    icon: ImageVector? = null,
    value: String? = null,
    selected: Boolean = false,
    danger: Boolean = false,
    family: FontFamily = Readex,
    onClick: () -> Unit,
) {
    val shape = RoundedCornerShape(24.dp)
    val tint = if (danger) Color(0xFFFF8FA3) else Sky
    Row(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp)
            .staggerIn(index + 1)
            .bounceClick(onClick = onClick)
            .clip(shape)
            .background(
                if (selected) Brush.linearGradient(listOf(Color(0xFF153B92), Color(0xFF0B1E4D)))
                else SolidColor(Color.White.copy(alpha = 0.055f))
            )
            .border(1.dp, if (selected) Color(0xFF7FD4FF) else Color.White.copy(alpha = 0.09f), shape)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            Icon(icon, null, tint = tint, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(12.dp))
        }
        Text(
            label, color = if (danger) Color(0xFFFF8FA3) else Tx, fontFamily = family, fontSize = 15.sp,
            modifier = Modifier.weight(1f)
        )
        if (value != null) {
            Spacer(Modifier.width(8.dp))
            Text(value, color = if (value == "✓") Sky else Mut, fontFamily = Readex, fontSize = 13.sp)
        }
    }
}

@Composable
fun LayerLabel(label: String, value: String, valueColor: Color = Color(0xFF9BD8FF)) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Mut, fontFamily = Readex, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        if (value.isNotEmpty()) Text(value, color = valueColor, fontFamily = Readex, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun LayerBtn(label: String, primary: Boolean, danger: Boolean, onClick: () -> Unit, modifier: Modifier) {
    val shape = RoundedCornerShape(24.dp)
    val bg = when {
        danger -> Brush.linearGradient(listOf(Color(0xFFFF5C78), Color(0xFFB3173A)))
        primary -> Brush.linearGradient(listOf(Color(0xFF3D7BFF), Color(0xFF1C3FB8)))
        else -> SolidColor(Color.White.copy(alpha = 0.08f))
    }
    Box(
        modifier
            .bounceClick(onClick = onClick)
            .then(if (primary) Modifier.glow(if (danger) Color(0xFFFF4D6A) else Blue, 12.dp, 24.dp, 0.5f) else Modifier)
            .clip(shape)
            .background(bg)
            .padding(vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) { Text(label, color = Color.White, fontFamily = Readex, fontWeight = FontWeight.Bold, fontSize = 15.sp) }
}

@Composable
fun LayerButtons(cancel: String?, ok: String, danger: Boolean = false, onCancel: () -> Unit = {}, onOk: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        if (cancel != null) LayerBtn(cancel, false, false, onCancel, Modifier.weight(1f))
        LayerBtn(ok, true, danger, onOk, Modifier.weight(1f))
    }
}

/** شريط اختيار بمؤشر بينزلق بنطّة زنبركية (زي أشرطة السرعة والنوم في الـ APK). */
@Composable
fun SegSelector(labels: List<String>, index: Int, onPick: (Int) -> Unit) {
    val n = labels.size.coerceAtLeast(1)
    val shape = RoundedCornerShape(26.dp)
    val frac by animateFloatAsState(index.toFloat(), spring(dampingRatio = 0.55f, stiffness = 300f), label = "seg")
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        BoxWithConstraints(
            Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(Color(0x8802081F))
                .border(1.dp, Color.White.copy(alpha = 0.07f), shape)
                .padding(4.dp)
        ) {
            val segW = maxWidth / n
            Box(
                Modifier
                    .offset(x = segW * frac)
                    .width(segW)
                    .height(42.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF5A9BFF), Color(0xFF2147C9))))
            )
            Row(Modifier.fillMaxWidth().height(42.dp)) {
                labels.forEachIndexed { i, l ->
                    Box(
                        Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(22.dp)).bounceClick { onPick(i) },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            l, color = if (i == index) Color.White else Color(0xFF8FA3CF), fontFamily = Readex,
                            fontWeight = FontWeight.Bold, fontSize = 13.5.sp, maxLines = 1
                        )
                    }
                }
            }
        }
    }
}

class MenuEntry(val label: String, val icon: ImageVector, val danger: Boolean = false, val onClick: () -> Unit)

/** قائمة اختيارات في الطبقة المركزية (بتحل محل القوائم المنسدلة القديمة). */
@Composable
fun MenuLayer(title: String, entries: List<MenuEntry>, onDismiss: () -> Unit) {
    LayerDialog(title, onDismiss) {
        entries.forEachIndexed { i, e ->
            LayerItem(e.label, i, e.icon, danger = e.danger) { onDismiss(); e.onClick() }
        }
    }
}
