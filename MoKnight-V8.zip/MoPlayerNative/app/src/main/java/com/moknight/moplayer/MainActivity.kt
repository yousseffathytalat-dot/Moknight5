package com.moknight.moplayer

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.rounded.AutoStories as RBook
import androidx.compose.material.icons.rounded.FormatListBulleted as RList
import androidx.compose.material.icons.rounded.GridView as RGrid
import androidx.compose.material.icons.rounded.MusicNote as RNote
import androidx.compose.material.icons.rounded.QueueMusic as RQueue
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val st = Store(this)
        AppFont.key = st.font
        Lang.en = st.lang == "en"
        // شريط الحالة (الساعة والبطارية والشبكة) بتاع التليفون نفسه، التطبيق بيرسم تحته من غير ما يرسم حاجة فيه
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        setContent {
            // الواجهة بتتكيّف تلقائيًا مع حجم الشاشة: تليفون صغير، تليفون كبير، تابلت، لابتوب
            val cfg = LocalConfiguration.current
            val k = (minOf(cfg.screenWidthDp, cfg.screenHeightDp) / 400f).coerceIn(0.9f, 1.25f)
            val d = LocalDensity.current
            CompositionLocalProvider(LocalDensity provides Density(d.density * k, d.fontScale)) {
                MaterialTheme(
                    colorScheme = darkColorScheme(primary = Blue, background = Bg0, surface = Navy2, onSurface = Tx),
                ) {
                    CompositionLocalProvider(LocalLayoutDirection provides (if (Lang.en) LayoutDirection.Ltr else LayoutDirection.Rtl)) {
                        App()
                    }
                }
            }
        }
    }
}

private fun tabLabels() = listOf(tr("المكتبة", "Library"), tr("التسجيلات", "Recordings"), tr("القوائم", "Playlists"))

private fun kindEmptyMsg(k: Kind) = when (k) {
    Kind.NASHEED -> tr("مفيش أناشيد اتلقت على التليفون.", "No nasheeds found on this phone.")
    Kind.QURAN -> tr("مفيش قرآن اتلقى على التليفون.", "No Quran audio found on this phone.")
    Kind.OTHER -> tr("مفيش ملفات تانية اتلقت.", "No other audio files found.")
}

private fun kindCountText(k: Kind, n: Int) = when (k) {
    Kind.NASHEED -> tr("$n أنشودة", "$n nasheeds")
    Kind.QURAN -> tr("$n ملف قرآن", "$n Quran files")
    Kind.OTHER -> tr("$n ملف", "$n files")
}

private class RowActions(
    val menu: (Track) -> Unit,
)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun App(vm: MainVM = viewModel()) {
    val ctx = LocalContext.current
    val tracks by vm.tracks.collectAsState()
    val loading by vm.loading.collectAsState()
    val current by vm.current.collectAsState()
    val last by vm.last.collectAsState()
    val playing by vm.playing.collectAsState()
    val playlists by vm.playlists.collectAsState()
    val cat by vm.cat.collectAsState()

    val perms = remember {
        if (Build.VERSION.SDK_INT >= 33)
            arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
        else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    }
    fun hasAudio() = ContextCompat.checkSelfPermission(ctx, perms[0]) == PackageManager.PERMISSION_GRANTED
    var granted by remember { mutableStateOf(hasAudio()) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = hasAudio()
        if (granted) vm.scan()
    }
    LaunchedEffect(Unit) {
        if (granted) vm.scan() else launcher.launch(perms)
    }

    var tab by remember { mutableIntStateOf(0) }
    var openId by remember { mutableStateOf<Long?>(null) }
    var sel by remember { mutableStateOf(setOf<Long>()) }
    var dlg by remember { mutableStateOf<Dlg?>(null) }
    var query by remember { mutableStateOf("") }
    var showFull by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()

    var micOk by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
    }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { micOk = it }
    LaunchedEffect(showFull) {
        val prefs = ctx.getSharedPreferences("moplayer", android.content.Context.MODE_PRIVATE)
        if (showFull && !micOk && !prefs.getBoolean("asked_mic", false)) {
            prefs.edit().putBoolean("asked_mic", true).apply()
            micLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    val openPl = openId?.let { id -> playlists.firstOrNull { it.id == id } }
    val inListsRoot = tab == 2 && openPl == null

    val base = remember(tracks, tab, openPl, cat) {
        when {
            tab == 0 -> tracks.filter { !it.isRecording && it.kind == cat }
            tab == 1 -> tracks.filter { it.isRecording }
            openPl != null -> {
                val m = tracks.associateBy { it.id }
                openPl.ids.mapNotNull { m[it] }
            }
            else -> emptyList()
        }
    }
    val shown = remember(base, query) {
        val q = query.trim()
        if (q.isEmpty()) base
        else base.filter { it.title.contains(q, true) || it.artist.contains(q, true) || it.album.contains(q, true) }
    }

    // لما تغيّر التبويب أو التصنيف أو تفتح قائمة، ارجع لأول القايمة
    LaunchedEffect(tab, cat, openId) { listState.scrollToItem(0) }

    // زر الرجوع: آخر واحد متسجل له الأولوية
    BackHandler(enabled = openPl != null) { openId = null; sel = emptySet() }
    BackHandler(enabled = sel.isNotEmpty()) { sel = emptySet() }
    BackHandler(enabled = showFull) { showFull = false }

    fun toast(s: String) = Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()

    // آخر حاجة اتشغلت بتفضل ظاهرة تحت حتى لو مفيش حاجة شغالة دلوقتي
    val miniTrack = current ?: last
    val bottomPad = if (miniTrack != null) 132.dp else 28.dp

    val rowActions = remember { RowActions(menu = { dlg = Dlg.TrackMenu(it, false) }) }

    // تقدّم التمرير (0..1) بيتحكم في تصغير الهيدر
    val scrollP = remember {
        derivedStateOf {
            if (listState.firstVisibleItemIndex > 0) 1f
            else (listState.firstVisibleItemScrollOffset / 170f).coerceIn(0f, 1f)
        }
    }

    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .background(AppBg)
    ) {
        val cols = when {
            maxWidth >= 900.dp -> 3
            maxWidth >= 600.dp -> 2
            else -> 1
        }
        val hPad = if (maxWidth >= 600.dp) 24.dp else 14.dp

        LivingBg(playing = playing)

        val full = Modifier.fillMaxWidth()

        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            // ---------- الهيدر (بيفضل ثابت فوق وهو بيصغر بنعومة مع التمرير) ----------
            if (sel.isNotEmpty()) {
                HeaderCard(hPad, { scrollP.value }) {
                    IconButton(onClick = { sel = emptySet() }) { Icon(Icons.Default.Close, tr("إلغاء", "Cancel"), tint = Tx) }
                    Text(tr("${sel.size} محدد", "${sel.size} selected"), color = Tx, fontFamily = Readex, fontSize = 16.sp, modifier = Modifier.weight(1f))
                    IconButton(onClick = { sel = shown.map { it.id }.toSet() }) { Icon(Icons.Default.SelectAll, tr("الكل", "All"), tint = Sky) }
                    if (sel.size == 1) IconButton(onClick = {
                        tracks.firstOrNull { it.id == sel.first() }?.let { dlg = Dlg.Edit(it) }
                    }) { Icon(Icons.Default.Edit, tr("تعديل", "Edit"), tint = Sky) }
                    IconButton(onClick = { dlg = Dlg.Move(sel.toList()) }) { Icon(Icons.Default.Category, tr("نقل إلى", "Move to"), tint = Sky) }
                    IconButton(onClick = { dlg = Dlg.Pick(sel.toList()) }) { Icon(Icons.Default.PlaylistAdd, tr("إضافة لقائمة", "Add to playlist"), tint = Sky) }
                    IconButton(onClick = {
                        if (openPl != null) {
                            vm.removeFromPlaylist(openPl.id, sel); sel = emptySet()
                        } else dlg = Dlg.ConfirmHide(sel.toList())
                    }) { Icon(Icons.Default.Delete, tr("حذف", "Delete"), tint = Color(0xFFFF6B6B)) }
                }
            } else if (openPl != null) {
                HeaderCard(hPad, { scrollP.value }) {
                    IconButton(onClick = { openId = null }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, tr("رجوع", "Back"), tint = Tx) }
                    Text(
                        openPl.name, color = Tx, fontFamily = Readex, fontWeight = FontWeight.Bold,
                        fontSize = 22.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    GearButton { dlg = Dlg.AppSettings }
                }
            } else {
                // الهيدر الرئيسي: + ثم الإعدادات يسارًا، الاسم في المنتصف، وشعار M يمينًا.
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    HeaderCard(hPad, { scrollP.value }) {
                        PlusButton(active = dlg is Dlg.Plus) { dlg = Dlg.Plus }
                        Spacer(Modifier.width(10.dp))
                        GearButton { dlg = Dlg.AppSettings }
                        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                            Text(
                                "MoKnight", color = Color.White, fontFamily = FontFamily.Serif,
                                fontWeight = FontWeight.Bold, fontSize = 30.sp, maxLines = 1,
                                style = TextStyle(shadow = Shadow(Color(0xFF4C96FF).copy(alpha = 0.85f), blurRadius = 28f))
                            )
                        }
                        HeaderLogo(50.dp)
                    }
                }
            }

            // ---------- المحتوى ----------
            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(bottom = bottomPad),
            ) {
                // التبويبات والتصنيفات بتطلع لفوق مع التمرير
                if (openPl == null) {
                    item(key = "tabs") {
                        TabBar(tab, hPad) { i -> tab = i; sel = emptySet(); query = ""; openId = null }
                    }
                    if (tab == 0) item(key = "cats") {
                        CategoryRow(cat, hPad) { k -> vm.setCat(k); sel = emptySet(); query = "" }
                    }
                }
                // البحث بيطلع ويثبت تحت MoKnight
                if (!inListsRoot) {
                    stickyHeader(key = "search") {
                        Box(
                            full.background(
                                Brush.verticalGradient(listOf(Bg0.copy(alpha = 0.97f), Bg0.copy(alpha = 0.9f), Color.Transparent))
                            )
                        ) {
                            ActionCard(
                                hPad = hPad, query = query, onQuery = { query = it }, enabled = shown.isNotEmpty(),
                                onSequential = { vm.playFrom(shown, 0) },
                                onShuffle = { vm.playShuffled(shown) },
                            )
                        }
                    }
                    item(key = "count") {
                        Text(
                            if (loading) tr("بيمسح الجهاز…", "Scanning device…")
                            else if (tab == 0) kindCountText(cat, shown.size)
                            else tr("${shown.size} ملف", "${shown.size} files"),
                            color = Mut, fontFamily = Readex, fontSize = 13.sp,
                            modifier = Modifier.padding(horizontal = hPad + 6.dp).padding(bottom = 4.dp)
                        )
                    }
                }

                when {
                    !granted -> item(key = "perm") {
                        Empty(tr("محتاج إذن الوصول للصوتيات عشان أعرض ملفاتك.", "Audio access permission is needed to show your files."), tr("إعطاء الإذن", "Grant permission")) { launcher.launch(perms) }
                    }

                    inListsRoot -> {
                        item(key = "lists_head") {
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = hPad + 6.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(tr("${playlists.size} قائمة", "${playlists.size} playlists"), color = Mut, fontFamily = Readex, fontSize = 13.sp, modifier = Modifier.weight(1f))
                                GradientButton(tr("قائمة جديدة", "New playlist"), Icons.Default.Add) { dlg = Dlg.NewList(emptyList()) }
                            }
                        }
                        if (playlists.isEmpty()) item(key = "lists_empty") {
                            Text(
                                tr("مفيش قوائم لسه. اعمل واحدة وضيف لها ملفات.", "No playlists yet. Create one and add files."),
                                color = Mut, fontFamily = Readex, fontSize = 14.sp,
                                modifier = Modifier.padding(24.dp)
                            )
                        }
                        itemsIndexed(playlists.chunked(cols), key = { _, r -> "pl_${r.first().id}" }) { ri, row ->
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = hPad),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                row.forEachIndexed { ci, p ->
                                    Box(Modifier.weight(1f)) {
                                        PlaylistRow(
                                            p, ri * cols + ci,
                                            onOpen = { openId = p.id; query = "" },
                                            onMenu = { dlg = Dlg.ListMenu(p) },
                                        )
                                    }
                                }
                                repeat(cols - row.size) { Spacer(Modifier.weight(1f)) }
                            }
                        }
                    }

                    !loading && shown.isEmpty() -> item(key = "empty") {
                        val msg = when {
                            query.isNotBlank() -> tr("مفيش نتايج للبحث.", "No search results.")
                            openPl != null -> tr("القائمة فاضية. حدد ملفات من المكتبة وضيفها هنا.", "Playlist is empty. Select files from the library and add them here.")
                            tab == 1 -> tr("مفيش تسجيلات اتلقت.", "No recordings found.")
                            else -> kindEmptyMsg(cat)
                        }
                        Empty(msg, tr("مسح تاني", "Scan again")) { vm.scan() }
                    }

                    else -> itemsIndexed(shown.chunked(cols), key = { _, r -> "tr_${r.first().id}" }) { ri, row ->
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = hPad),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            row.forEachIndexed { ci, t ->
                                val idx = ri * cols + ci
                                Box(Modifier.weight(1f)) {
                                    TrackRow(
                                        t = t,
                                        index = idx,
                                        active = t.id == current?.id,
                                        playing = playing,
                                        selected = t.id in sel,
                                        actions = rowActions,
                                        onClick = {
                                            if (sel.isNotEmpty()) sel = if (t.id in sel) sel - t.id else sel + t.id
                                            else vm.playFrom(shown, idx)
                                        },
                                        onLong = { sel = if (t.id in sel) sel - t.id else sel + t.id },
                                    )
                                }
                            }
                            repeat(cols - row.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                }
            }
        }

        // ---------- المشغّل المصغّر: آخر حاجة اتشغلت ----------
        miniTrack?.let { t ->
            MiniHost(
                vm = vm, track = t, playing = playing, idle = current == null,
                onOpen = {
                    if (current == null) vm.playLast()
                    showFull = true
                },
                modifier = Modifier.align(Alignment.BottomCenter)
            )
        }

        // ---------- المشغّل الكامل ----------
        AnimatedVisibility(
            visible = showFull && current != null,
            enter = slideInVertically(tween(480, easing = FastOutSlowInEasing)) { it } + fadeIn(tween(380)) + scaleIn(tween(480), initialScale = 0.92f),
            exit = slideOutVertically(tween(360, easing = FastOutSlowInEasing)) { it } + fadeOut(tween(300)) + scaleOut(tween(360), targetScale = 0.92f),
        ) {
            current?.let { t ->
                FullHost(
                    vm, t, playing, micOk,
                    onClose = { showFull = false },
                    onOptions = { dlg = Dlg.TrackMenu(t, true) },
                    onPlayback = { dlg = Dlg.Playback },
                )
            }
        }
    }

    // ---------- الطبقات والحوارات ----------
    when (val d = dlg) {
        null -> {}
        is Dlg.AppSettings -> SettingsLayer(
            vm,
            onRescan = { if (granted) vm.scan() else launcher.launch(perms) },
            onRefresh = {
                vm.refreshAll()
                toast(tr("اتعمل ريفريش. الأيقونات بتتحمل…", "Refreshed. Loading icons…"))
            },
            onDismiss = { dlg = null },
        )
        is Dlg.Playback -> PlaybackLayer(vm) { dlg = null }
        is Dlg.Plus -> MenuLayer(
            tr("إضافة", "Add"),
            listOf(
                MenuEntry(tr("قائمة جديدة", "New playlist"), Icons.Default.QueueMusic) { dlg = Dlg.NewList(emptyList()) },
                MenuEntry(tr("تحديث المكتبة", "Refresh library"), Icons.Default.Refresh) { if (granted) vm.scan() else launcher.launch(perms) },
            ),
        ) { dlg = null }
        is Dlg.TrackMenu -> {
            val t = d.t
            val entries = buildList {
                if (!d.fromPlayer) {
                    add(MenuEntry(tr("تشغيل", "Play"), Icons.Default.PlayArrow) {
                        val i = shown.indexOfFirst { it.id == t.id }
                        if (i >= 0) vm.playFrom(shown, i) else vm.playFrom(listOf(t), 0)
                    })
                }
                add(MenuEntry(tr("إضافة إلى قائمة", "Add to playlist"), Icons.Default.PlaylistAdd) { dlg = Dlg.Pick(listOf(t.id)) })
                add(MenuEntry(tr("تعديل الاسم والتصنيف", "Edit name & category"), Icons.Default.Edit) { dlg = Dlg.Edit(t) })
                if (!d.fromPlayer) {
                    add(MenuEntry(tr("تحديد", "Select"), Icons.Default.CheckCircle) { sel = sel + t.id })
                }
                Kind.values().filter { it != t.kind }.forEach { k ->
                    add(MenuEntry(tr("نقل إلى ${kindLabel(k)}", "Move to ${kindLabel(k)}"), Icons.Default.Category) {
                        vm.setKind(listOf(t.id), k)
                        toast(tr("اتنقلت إلى ${kindLabel(k)}", "Moved to ${kindLabel(k)}"))
                    })
                }
                add(MenuEntry(tr("إخفاء من التطبيق", "Hide from app"), Icons.Default.Delete, danger = true) { dlg = Dlg.ConfirmHide(listOf(t.id)) })
            }
            MenuLayer(t.title, entries) { dlg = null }
        }
        is Dlg.ListMenu -> MenuLayer(
            d.p.name,
            listOf(
                MenuEntry(tr("تغيير الاسم", "Rename"), Icons.Default.Edit) { dlg = Dlg.Rename(d.p) },
                MenuEntry(tr("حذف القائمة", "Delete playlist"), Icons.Default.Delete, danger = true) { dlg = Dlg.DeleteList(d.p) },
            ),
        ) { dlg = null }
        is Dlg.Move -> MenuLayer(
            tr("نقل إلى", "Move to"),
            Kind.values().map { k ->
                MenuEntry(kindLabel(k), Icons.Default.Category) {
                    vm.setKind(d.ids, k)
                    toast(tr("اتنقل ${d.ids.size} إلى ${kindLabel(k)}", "Moved ${d.ids.size} to ${kindLabel(k)}"))
                    sel = emptySet()
                }
            },
        ) { dlg = null }
        is Dlg.NewList -> NameDialog(tr("قائمة جديدة", "New playlist"), "", tr("إنشاء", "Create"), { dlg = null }) { name ->
            vm.createPlaylist(name, d.add)
            if (d.add.isNotEmpty()) toast(tr("اتضافت ${d.add.size} للقائمة", "${d.add.size} added to playlist"))
            sel = emptySet(); dlg = null
        }
        is Dlg.Rename -> NameDialog(tr("اسم القائمة", "Playlist name"), d.pl.name, tr("حفظ", "Save"), { dlg = null }) { name ->
            vm.renamePlaylist(d.pl.id, name); dlg = null
        }
        is Dlg.DeleteList -> ConfirmDialog(
            tr("حذف القائمة", "Delete playlist"), tr("هتتحذف القائمة \"${d.pl.name}\" بس، والملفات هتفضل زي ما هي.", "Only the playlist \"${d.pl.name}\" will be deleted; files stay as they are."), tr("حذف", "Delete"), { dlg = null }
        ) { vm.deletePlaylist(d.pl.id); dlg = null }
        is Dlg.Pick -> PickListDialog(
            playlists, { dlg = null },
            onPick = { p -> vm.addToPlaylist(p.id, d.ids); toast(tr("اتضاف لـ ${p.name}", "Added to ${p.name}")); sel = emptySet(); dlg = null },
            onNew = { dlg = Dlg.NewList(d.ids) },
        )
        is Dlg.Edit -> EditDialog(d.t, { dlg = null }) { title, artist, kind ->
            vm.editTrack(d.t.id, title, artist)
            if (kind != d.t.kind) vm.setKind(listOf(d.t.id), kind)
            sel = emptySet(); dlg = null
        }
        is Dlg.ConfirmHide -> ConfirmDialog(
            tr("إخفاء ${d.ids.size} من التطبيق", "Hide ${d.ids.size} from app"),
            tr("الملفات هتختفي من MoPlayer بس، والملفات نفسها هتفضل على التليفون.", "Files will be hidden from MoPlayer only; they stay on the phone."), tr("إخفاء", "Hide"), { dlg = null }
        ) { vm.hide(d.ids); sel = emptySet(); dlg = null }
    }
}

// =====================================================================
//  الهيدر
// =====================================================================

private enum class IconMotion { PULSE, ROTATE, SWAY, NONE }

/** حركات صغيرة مختلفة حسب وظيفة الأيقونة، من غير تغيير شكل الواجهة. */
@Composable
private fun TaskIcon(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    desc: String?,
    tint: Color,
    modifier: Modifier = Modifier,
    motion: IconMotion = IconMotion.NONE,
    active: Boolean = false,
) {
    val transition = rememberInfiniteTransition(label = "task-icon-$motion")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (motion) {
                    IconMotion.PULSE -> 1150
                    IconMotion.ROTATE -> 1800
                    IconMotion.SWAY -> 900
                    IconMotion.NONE -> 1500
                },
                easing = LinearEasing,
            ),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "phase",
    )
    val amount = if (active) 1f else if (motion == IconMotion.PULSE) 0.22f else 0f
    val scale = when (motion) {
        IconMotion.PULSE -> 1f + (0.07f * phase * amount)
        IconMotion.ROTATE, IconMotion.SWAY, IconMotion.NONE -> 1f
    }
    val rotation = when (motion) {
        IconMotion.ROTATE -> 360f * phase * amount
        IconMotion.SWAY -> (phase - 0.5f) * 12f * amount
        else -> 0f
    }
    Icon(icon, desc, tint = tint, modifier = modifier.graphicsLayer {
        scaleX = scale
        scaleY = scale
        rotationZ = rotation
    })
}

@Composable
private fun HeaderCard(hPad: Dp, scaleP: () -> Float, content: @Composable RowScope.() -> Unit) {
    val shape = RoundedCornerShape(34.dp)
    // دخول ناعم للهيدر مرة واحدة
    val enter = remember { androidx.compose.animation.core.Animatable(0f) }
    LaunchedEffect(Unit) { enter.animateTo(1f, tween(800, easing = FastOutSlowInEasing)) }
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = hPad, vertical = 10.dp)
            .graphicsLayer {
                val s = (1f - 0.11f * scaleP()) * (0.94f + 0.06f * enter.value)
                scaleX = s
                scaleY = s
                alpha = enter.value
                transformOrigin = TransformOrigin(0.5f, 0f)
            }
            .glow(Blue, 18.dp, 34.dp) { 0.3f + 0.35f * scaleP() }
            .clip(shape)
            .background(Brush.horizontalGradient(listOf(Color(0xFF031038).copy(alpha = 0.95f), Color(0xFF07154A).copy(alpha = 0.95f))))
            .border(1.dp, Brush.horizontalGradient(listOf(Color(0xFF2F6BFF).copy(alpha = 0.55f), Color(0xFF6A3DFF).copy(alpha = 0.5f))), shape)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        content = content
    )
}

/** زر الترس: بيلف ببطء، ولما تضغط عليه بيلف لفة وتفتح الإعدادات. */
@Composable
private fun GearButton(onClick: () -> Unit) {
    var spin by remember { mutableIntStateOf(0) }
    Box(
        Modifier
            .size(48.dp)
            .glow(Sky, 10.dp, 24.dp, 0.28f)
            .bounceClick { spin++; onClick() }
            .clip(CircleShape)
            .background(Color(0xFF041240))
            .border(1.dp, Color(0xFF2A4DAA), CircleShape),
        contentAlignment = Alignment.Center
    ) { GearIcon(Color(0xFFEAF0FF), 27.dp, spinKey = spin) }
}

/** لوجو الهيدر: مربع غامق وحرف M متدرج (أزرق ← بنفسجي) بيتنفس. */
@Composable
private fun HeaderLogo(size: Dp) {
    val inf = rememberInfiniteTransition(label = "logo")
    val p by inf.animateFloat(0.35f, 0.9f, infiniteRepeatable(tween(2400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "lp")
    val sh = RoundedCornerShape(size * 0.34f)
    Box(
        Modifier
            .size(size)
            .glow(Color(0xFF6A3DFF), 12.dp, size * 0.34f) { p * 0.7f }
            .clip(sh)
            .background(Color(0xFF01062E))
            .border(1.dp, Color(0xFF2A2FA8), sh),
        contentAlignment = Alignment.Center
    ) {
        Text(
            "M",
            style = TextStyle(
                brush = Brush.linearGradient(listOf(Color(0xFF4CB8FF), Color(0xFF9B4DFF))),
                fontWeight = FontWeight.Bold,
                fontSize = (size.value * 0.62f).sp,
            )
        )
    }
}

/** زرار + : بيفتح قايمة: قائمة جديدة / تحديث المكتبة. */
@Composable
private fun PlusButton(active: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .size(54.dp)
            .glow(Blue, 14.dp, 27.dp, 0.5f)
            .bounceClick(onClick = onClick)
            .clip(CircleShape)
            .background(Brush.linearGradient(listOf(Color(0xFF2F8BFF), Violet))),
        contentAlignment = Alignment.Center
    ) { TaskIcon(Icons.Default.Add, tr("إضافة", "Add"), tint = Color.White, modifier = Modifier.size(30.dp), motion = IconMotion.ROTATE, active = active) }
}

@Composable
private fun GradientButton(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    val shape = RoundedCornerShape(26.dp)
    Row(
        Modifier
            .glow(Blue, 10.dp, 26.dp, 0.4f)
            .bounceClick(onClick = onClick)
            .clip(shape)
            .background(Brush.horizontalGradient(listOf(Color(0xFF0B6BF9), Color(0xFF3A2BF0))))
            .padding(horizontal = 18.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(6.dp))
        Text(label, color = Color.White, fontFamily = Readex, fontSize = 14.sp)
    }
}

// =====================================================================
//  التبويبات
// =====================================================================

@Composable
private fun TabBar(tab: Int, hPad: Dp, onTab: (Int) -> Unit) {
    val bar = RoundedCornerShape(34.dp)
    val pill = RoundedCornerShape(28.dp)
    val icons = listOf(Icons.Rounded.RBook, Icons.Rounded.RList, Icons.Rounded.RQueue)
    val pos by animateFloatAsState(tab.toFloat(), spring(dampingRatio = 0.62f, stiffness = 380f), label = "tabpos")
    BoxWithConstraints(
        Modifier
            .padding(horizontal = hPad, vertical = 4.dp)
            .fillMaxWidth()
            .staggerIn(0)
            .glow(Blue, 14.dp, 34.dp, 0.2f)
            .clip(bar)
            .background(CardFill.copy(alpha = 0.92f))
            .border(1.dp, CardLine, bar)
            .padding(5.dp)
    ) {
        val segW = maxWidth / 3
        // المؤشر بينزلق بين التبويبات (الإزاحة بتتعكس لوحدها في العربي)
        Box(
            Modifier
                .offset(x = segW * pos)
                .width(segW)
                .height(50.dp)
                .glow(Blue, 12.dp, 28.dp, 0.65f)
                .clip(pill)
                .background(Brush.horizontalGradient(listOf(Color(0xFF0B6BF9), Color(0xFF3A2BF0))))
                .border(1.dp, Sky.copy(alpha = 0.6f), pill)
        )
        Row(Modifier.fillMaxWidth()) {
            tabLabels().forEachIndexed { i, label ->
                val on = tab == i
                Row(
                    Modifier
                        .weight(1f)
                        .height(50.dp)
                        .clip(pill)
                        .bounceClick { onTab(i) },
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TaskIcon(icons[i], null, tint = if (on) Color(0xFFEAF0FF) else Color(0xFFA9B8F0), modifier = Modifier.size(24.dp), motion = IconMotion.PULSE, active = on)
                    Spacer(Modifier.width(7.dp))
                    Text(
                        label, color = if (on) Color.White else Color(0xFFA9B8F0), fontFamily = Readex,
                        fontWeight = if (on) FontWeight.Bold else FontWeight.Medium,
                        fontSize = 14.sp, maxLines = 1
                    )
                }
            }
        }
    }
}

// =====================================================================
//  أزرار التصنيف: أخرى / القرآن الكريم / أناشيد
// =====================================================================

private class CatStyle(
    val a: Color, val b: Color, val lineA: Color, val lineB: Color, val tile: Color, val glow: Color, val label: Color,
)

private fun catStyle(k: Kind, selected: Boolean): CatStyle = when (k) {
    Kind.NASHEED ->
        if (selected) CatStyle(Color(0xFF5A2BE0), Color(0xFF2A1FA6), Color(0xFFB39CFF), Color(0xFF2FB4FF), Color(0x55A97BFF), Color(0xFF6A3DFF), Color.White)
        else CatStyle(Color(0xFF241A78), Color(0xFF181156), Color(0xFF5A4BD0), Color(0xFF2A5BD0), Color(0x449B6BFF), Color(0xFF6A3DFF), Color(0xFFD5DCFF))
    Kind.QURAN ->
        if (selected) CatStyle(Color(0xFF0B52C8), Color(0xFF062C86), Color(0xFF6FC4FF), Color(0xFF2F6BFF), Color(0x554CB8FF), Color(0xFF2F8BFF), Color.White)
        else CatStyle(Color(0xFF00266E), Color(0xFF001850), Color(0xFF1E8FE0), Color(0xFF1B4FB0), Color(0xFF0A3F8C), Color(0xFF1E8FE0), Color(0xFFD5DCFF))
    Kind.OTHER ->
        if (selected) CatStyle(Color(0xFF0C7A94), Color(0xFF064A66), Color(0xFF7FE3EE), Color(0xFF1AA3B8), Color(0x554CE0F0), Color(0xFF14A0B0), Color.White)
        else CatStyle(Color(0xFF003B5E), Color(0xFF002A46), Color(0xFF15A0BE), Color(0xFF0B5E7E), Color(0xFF0E6A8E), Color(0xFF14A0B0), Color(0xFFD5DCFF))
}

private fun catIcon(k: Kind) = when (k) {
    Kind.NASHEED -> Icons.Rounded.RNote
    Kind.QURAN -> Icons.Rounded.RBook
    Kind.OTHER -> Icons.Rounded.RGrid
}

@Composable
private fun CategoryRow(cat: Kind, hPad: Dp, onPick: (Kind) -> Unit) {
    // الترتيب زي التصميم: أخرى، القرآن الكريم، أناشيد (من اليمين لليسار)
    Row(
        Modifier.padding(horizontal = hPad, vertical = 8.dp).fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        listOf(Kind.OTHER, Kind.QURAN, Kind.NASHEED).forEachIndexed { i, k ->
            CatButton(k, cat == k, Modifier.weight(1f).staggerIn(i + 1)) { onPick(k) }
        }
    }
}

@Composable
private fun CatButton(kind: Kind, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(30.dp)
    val st = catStyle(kind, selected)
    val lift by animateFloatAsState(if (selected) 1f else 0f, spring(dampingRatio = 0.6f, stiffness = 400f), label = "lift")
    Row(
        modifier
            .graphicsLayer { translationY = -4.dp.toPx() * lift }
            .glow(st.glow, 14.dp, 30.dp) { 0.15f + 0.5f * lift }
            .bounceClick(onClick = onClick)
            .clip(shape)
            .background(Brush.linearGradient(listOf(st.a, st.b)))
            .border(if (selected) 1.5.dp else 1.dp, Brush.linearGradient(listOf(st.lineA, st.lineB)), shape)
            .padding(horizontal = 6.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // الاسم على اليمين في سطر واحد، والأيقونة على الشمال (زي التصميم)
        Text(
            kindLabel(kind), color = st.label,
            fontFamily = Readex, fontSize = 12.sp, softWrap = false, maxLines = 1,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            modifier = Modifier.weight(1f)
        )
        Spacer(Modifier.width(4.dp))
        Box(
            Modifier.size(38.dp).clip(RoundedCornerShape(19.dp)).background(st.tile),
            contentAlignment = Alignment.Center
        ) { TaskIcon(catIcon(kind), null, tint = Color(0xFFF2F5FF), modifier = Modifier.size(24.dp), motion = IconMotion.PULSE, active = selected) }
    }
}

// =====================================================================
//  البحث + تشغيل متتابع + عشوائي
// =====================================================================

@Composable
private fun ActionCard(
    hPad: Dp, query: String, onQuery: (String) -> Unit, enabled: Boolean,
    onSequential: () -> Unit, onShuffle: () -> Unit,
) {
    val shape = RoundedCornerShape(34.dp)
    val field = RoundedCornerShape(26.dp)
    Row(
        Modifier
            .padding(horizontal = hPad, vertical = 8.dp)
            .fillMaxWidth()
            .glow(Blue, 12.dp, 34.dp, 0.22f)
            .clip(shape)
            .background(Brush.horizontalGradient(listOf(Color(0xFF041444).copy(alpha = 0.97f), Color(0xFF061A52).copy(alpha = 0.97f))))
            .border(1.dp, CardLine, shape)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            Modifier
                .weight(1f)
                .clip(field)
                .background(FieldFill)
                .border(1.dp, CardLine, field)
                .padding(horizontal = 14.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TaskIcon(Icons.Default.Search, null, tint = Color(0xFFA78BFF), modifier = Modifier.size(22.dp), motion = IconMotion.PULSE, active = query.isNotEmpty())
            Spacer(Modifier.width(8.dp))
            Box(Modifier.weight(1f)) {
                if (query.isEmpty()) Text(
                    tr("ابحث في المكتبة...", "Search the library..."), color = Mut, fontFamily = Readex,
                    fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                BasicTextField(
                    value = query,
                    onValueChange = onQuery,
                    singleLine = true,
                    textStyle = TextStyle(color = Tx, fontFamily = Readex, fontSize = 15.sp),
                    cursorBrush = SolidColor(Sky),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
        Spacer(Modifier.width(4.dp))
        ActionButton(Icons.Default.Repeat, tr("تشغيل متتابع", "Play all"), enabled, onSequential)
        ActionButton(Icons.Default.Shuffle, tr("عشوائي", "Shuffle"), enabled, onShuffle)
    }
}

@Composable
private fun ActionButton(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, enabled: Boolean, onClick: () -> Unit) {
    var fired by remember { mutableStateOf(false) }
    LaunchedEffect(fired) {
        if (fired) {
            kotlinx.coroutines.delay(620)
            fired = false
        }
    }
    // لما تضغط: الزر بيكبر ويلمع وبعدين يرجع لوحده (زي زر التشغيل المتتالي في الـ APK)
    val grow by animateFloatAsState(
        if (fired) 1.14f else 1f,
        spring(dampingRatio = 0.45f, stiffness = 320f), label = "grow"
    )
    val isShuffle = label.contains("عشوائي") || label.contains("Shuffle", true)
    Column(
        Modifier
            .graphicsLayer { scaleX = grow; scaleY = grow }
            .glow(Sky, 12.dp, 22.dp) { if (fired) 0.7f else 0f }
            .clip(RoundedCornerShape(22.dp))
            .clickable(enabled = enabled) { fired = true; onClick() }
            .padding(horizontal = 10.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        TaskIcon(
            icon, label, tint = if (enabled) Color(0xFF8C9CFF) else Mut.copy(alpha = 0.4f),
            modifier = Modifier.size(26.dp),
            motion = if (isShuffle) IconMotion.SWAY else IconMotion.ROTATE,
            active = fired,
        )
        Text(label, color = if (enabled) Mut else Mut.copy(alpha = 0.4f), fontFamily = Readex, fontSize = 11.sp, maxLines = 1)
    }
}

// =====================================================================
//  المحتوى
// =====================================================================

@Composable
private fun MiniHost(vm: MainVM, track: Track, playing: Boolean, idle: Boolean, onOpen: () -> Unit, modifier: Modifier) {
    val progress by vm.progress.collectAsState()
    MiniPlayer(track, playing, idle, progress, vm::toggle, vm::next, vm::prev, onOpen, modifier)
}

@Composable
private fun FullHost(
    vm: MainVM, track: Track, playing: Boolean, micOk: Boolean,
    onClose: () -> Unit, onOptions: () -> Unit, onPlayback: () -> Unit,
) {
    val progress by vm.progress.collectAsState()
    val position by vm.position.collectAsState()
    val duration by vm.duration.collectAsState()
    val shuffle by vm.shuffle.collectAsState()
    val repeat by vm.repeat.collectAsState()
    val speed by vm.speed.collectAsState()
    val sleepLeft by vm.sleepLeft.collectAsState()
    FullPlayer(
        track = track, playing = playing, progress = progress, position = position, duration = duration,
        shuffle = shuffle, repeat = repeat, onClose = onClose,
        onToggle = vm::toggle, onNext = vm::next, onPrev = vm::prev, onSeek = vm::seekToFraction,
        onShuffle = vm::toggleShuffle, onRepeat = vm::cycleRepeat,
        onOptions = onOptions, onPlayback = onPlayback, playbackDot = speed != 1f || sleepLeft > 0,
        micOk = micOk,
    )
}

@Composable
private fun Empty(msg: String, btn: String, onClick: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(32.dp).staggerIn(0),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(msg, color = Mut, fontFamily = Readex, fontSize = 15.sp)
        Spacer(Modifier.height(16.dp))
        GradientButton(btn, Icons.Default.Refresh, onClick)
    }
}

@Composable
private fun TrackRow(
    t: Track, index: Int, active: Boolean, playing: Boolean, selected: Boolean, actions: RowActions,
    onClick: () -> Unit, onLong: () -> Unit,
) {
    val shape = RoundedCornerShape(30.dp)
    var spin by remember { mutableIntStateOf(0) }
    val inf = rememberInfiniteTransition(label = "row")
    val pulse by inf.animateFloat(0.45f, 1f, infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "rp")
    val lit = active || selected
    val fill = when {
        selected -> Brush.horizontalGradient(listOf(Blue.copy(alpha = 0.45f), Violet.copy(alpha = 0.35f)))
        active -> Brush.horizontalGradient(listOf(Color(0xFF0A2468), Color(0xFF1A1673)))
        else -> SolidColor(CardFill.copy(alpha = 0.88f))
    }
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp)
            .staggerIn(index)
            .glow(if (selected) Sky else Violet, 14.dp, 30.dp) { if (lit) (if (playing && active) 0.3f + 0.4f * pulse else 0.5f) else 0f }
            .bounceClick(onLong = onLong, onClick = onClick)
            .clip(shape)
            .background(fill)
            .border(if (lit) 1.5.dp else 1.dp, if (lit) Color(0xFF5B8CFF) else CardLine, shape)
            .padding(horizontal = 12.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // في الواجهة العربية أول عنصر يظهر ناحية اليمين: غلاف مربع، أو M إذا مفيش غلاف.
        Art(t, 56.dp, 160, RoundedCornerShape(20.dp))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    t.title, modifier = Modifier.weight(1f),
                    color = if (active) Color.White else Tx, fontFamily = Readex,
                    fontWeight = FontWeight.Bold, fontSize = 16.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                if (active) {
                    Spacer(Modifier.width(8.dp))
                    WaveBars(on = playing, modifier = Modifier.width(42.dp).height(24.dp))
                }
            }
            Spacer(Modifier.height(3.dp))
            Text(
                "${t.artist.ifBlank { kindLabel(t.kind) }} · ${formatTime(t.durationMs)}",
                color = Mut, fontFamily = Readex, fontSize = 13.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        // الترس: بيلف لفة لما تضغط عليه وبيفتح قايمة الملف
        Box(
            Modifier.size(44.dp).clip(CircleShape).clickable { spin++; actions.menu(t) },
            contentAlignment = Alignment.Center
        ) { GearIcon(Color(0xFFA9B8FF), 26.dp, spinKey = spin, idle = false) }
        // علامة التحديد أو سهم فتح الملف في أقصى اليسار.
        if (selected) Icon(Icons.Default.CheckCircle, null, tint = Sky, modifier = Modifier.size(24.dp))
        else Icon(Icons.Default.ChevronLeft, null, tint = Mut, modifier = Modifier.size(22.dp))
    }
}

@Composable
private fun PlaylistRow(p: Playlist, index: Int, onOpen: () -> Unit, onMenu: () -> Unit) {
    val shape = RoundedCornerShape(30.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp)
            .staggerIn(index)
            .bounceClick(onClick = onOpen)
            .clip(shape)
            .background(CardFill.copy(alpha = 0.88f))
            .border(1.dp, CardLine, shape)
            .padding(horizontal = 12.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.ChevronRight, null, tint = Mut, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(6.dp))
        Box(
            Modifier.size(56.dp).clip(RoundedCornerShape(20.dp))
                .background(Brush.linearGradient(listOf(LogoA, LogoB))),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Default.QueueMusic, null, tint = Color.White, modifier = Modifier.size(26.dp)) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(p.name, color = Tx, fontFamily = Readex, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(tr("${p.ids.size} ملف", "${p.ids.size} files"), color = Mut, fontFamily = Readex, fontSize = 13.sp)
        }
        Box(
            Modifier.size(44.dp).clip(CircleShape).clickable(onClick = onMenu),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Default.MoreVert, tr("خيارات", "Options"), tint = Color(0xFF8C9CFF)) }
    }
}

/** المشغّل المصغّر: بيظهر تحت دايمًا ومعاه آخر حاجة اتشغلت. غلاف دوّار، ضوء بيعدّي، موجة، وشريط تقدّم بيلمع. */
@Composable
private fun MiniPlayer(
    track: Track, playing: Boolean, idle: Boolean, progress: Float,
    onToggle: () -> Unit, onNext: () -> Unit, onPrev: () -> Unit, onOpen: () -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(38.dp)
    val spin by rememberSpin(playing)
    val inf = rememberInfiniteTransition(label = "mini")
    val pulse by inf.animateFloat(0.4f, 1f, infiniteRepeatable(tween(1600, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "mp")
    val sweep by inf.animateFloat(-0.4f, 1.2f, infiniteRepeatable(tween(4200, easing = LinearEasing)), label = "ms")
    val appear = remember { androidx.compose.animation.core.Animatable(0f) }
    LaunchedEffect(Unit) { appear.animateTo(1f, spring(dampingRatio = 0.7f, stiffness = 260f)) }
    val status = when {
        idle -> tr("آخر ما شغّلته", "Last played")
        playing -> tr("يتم التشغيل الآن", "Now playing")
        else -> tr("متوقف مؤقتًا", "Paused")
    }
    val kindName = when (track.kind) {
        Kind.NASHEED -> tr("أنشودة", "Nasheed")
        Kind.QURAN -> tr("القرآن الكريم", "Quran")
        Kind.OTHER -> tr("أخرى", "Other")
    }
    Column(
        modifier
            .widthIn(max = 720.dp)
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 14.dp, vertical = 10.dp)
            .graphicsLayer {
                translationY = (1f - appear.value) * 90.dp.toPx()
                alpha = appear.value.coerceIn(0f, 1f)
            }
            .glow(Blue, 22.dp, 38.dp) { if (playing) 0.3f + 0.4f * pulse else 0.22f }
            .clip(shape)
            .background(Brush.horizontalGradient(listOf(Color(0xFF0B2A80), Color(0xFF2A1A92))))
            .drawBehind {
                // شعاع ضوء بيعدّي على المشغّل وقت التشغيل
                if (playing) {
                    val x = size.width * sweep
                    drawRect(
                        Brush.horizontalGradient(
                            listOf(Color.Transparent, Color.White.copy(alpha = 0.09f), Color.Transparent),
                            startX = x - size.width * 0.25f, endX = x + size.width * 0.25f
                        )
                    )
                }
            }
            .border(1.5.dp, Brush.horizontalGradient(listOf(Sky, Violet)), shape)
            .bounceClick(onClick = onOpen)
    ) {
        Row(
            Modifier.padding(start = 12.dp, end = 12.dp, top = 11.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // غلاف دائري بيلف وقت التشغيل
            Box(
                Modifier
                    .size(60.dp)
                    .graphicsLayer { rotationZ = spin }
                    .glow(Sky, 10.dp, 30.dp) { if (playing) 0.3f + 0.3f * pulse else 0.15f }
                    .clip(CircleShape)
                    .border(2.dp, Brush.sweepGradient(listOf(Sky, Violet, Sky)), CircleShape)
                    .padding(3.dp),
                contentAlignment = Alignment.Center
            ) { Art(track, 54.dp, 128, CircleShape) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(status, color = Sky, fontFamily = Readex, fontSize = 11.sp, maxLines = 1)
                    if (playing) {
                        Spacer(Modifier.width(6.dp))
                        WaveBars(on = true, modifier = Modifier.width(30.dp).height(12.dp))
                    }
                }
                Text(
                    track.title, color = Color.White, fontFamily = Readex, fontWeight = FontWeight.Bold,
                    fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text(
                    kindName, color = Mut, fontFamily = Readex,
                    fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
            // أزرار التحكم دايمًا من الشمال لليمين
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(40.dp).clip(CircleShape).bounceClick(onClick = onPrev),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Default.SkipPrevious, tr("السابق", "Previous"), tint = Tx) }
                    Box(
                        Modifier.size(52.dp).pulseRing(playing)
                            .glow(Blue, 12.dp, 26.dp, 0.55f)
                            .bounceClick(onClick = onToggle)
                            .clip(CircleShape)
                            .background(Brush.linearGradient(listOf(Blue, Violet))),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, tr("تشغيل/إيقاف", "Play/Pause"), tint = Color.White, modifier = Modifier.size(30.dp))
                    }
                    Box(
                        Modifier.size(40.dp).clip(CircleShape).bounceClick(onClick = onNext),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Default.SkipNext, tr("التالي", "Next"), tint = Tx) }
                }
            }
        }
        // شريط تقدّم بحواف دائرية وتوهج عند الطرف
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Box(
                Modifier
                    .padding(start = 22.dp, end = 22.dp, bottom = 13.dp)
                    .fillMaxWidth()
                    .height(5.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.13f))
            ) {
                Box(
                    Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(progress.coerceIn(0.015f, 1f))
                        .clip(CircleShape)
                        .background(Brush.horizontalGradient(listOf(Blue, Sky, Color(0xFFB8F7FF))))
                )
            }
        }
    }
}
