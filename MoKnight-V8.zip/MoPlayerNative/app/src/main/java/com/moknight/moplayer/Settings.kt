package com.moknight.moplayer

import android.content.Intent
import android.provider.Settings
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class FontOpt(val key: String, val label: String, val res: Int)

val FONTS = listOf(
    FontOpt("readex", "Readex Pro", R.font.readex_pro),
    FontOpt("cairo", "Cairo", R.font.cairo),
    FontOpt("messiri", "El Messiri", R.font.elmessiri),
    FontOpt("tajawal", "Tajawal", R.font.tajawal_regular),
    FontOpt("almarai", "Almarai", R.font.almarai_regular),
    FontOpt("kufi", "Noto Kufi Arabic", R.font.notokufi),
)

private val families: Map<String, FontFamily> by lazy { FONTS.associate { it.key to FontFamily(Font(it.res)) } }
fun familyOf(key: String): FontFamily = families[key] ?: families.getValue("readex")

object AppFont {
    var key by mutableStateOf("readex")
}

object Lang {
    var en by mutableStateOf(false)
}

/** نص عربي/إنجليزي حسب اللغة المختارة. */
fun tr(ar: String, en: String): String = if (Lang.en) en else ar

private const val ABOUT_AR =
    "MoPlayer مشغّل موسيقى هادي وسريع من MoKnight. بيجيب الأغاني من جهازك تلقائيًا، وتقدر تعمل قوائم تشغيل، وتشغّل متتالي أو عشوائي أو تكرار، وتظبط السرعة ومؤقّت النوم، وتتحكم فيه من الإشعارات."
private const val ABOUT_EN =
    "MoPlayer is a calm, fast music player by MoKnight. It finds the songs on your phone automatically, lets you make playlists, play in order, shuffle or repeat, adjust the speed and sleep timer, and control it from the notification."

private enum class SPage { MAIN, LANG, FONT, ABOUT }

/** قائمة الإعدادات (نفس قائمة الترس في نسخة الـ APK): اللغة، إعادة فحص الجهاز، ريفريش، تغيير الخط، وصف البرنامج. */
@Composable
fun SettingsLayer(vm: MainVM, onRescan: () -> Unit, onRefresh: () -> Unit, onDismiss: () -> Unit) {
    var page by remember { mutableStateOf(SPage.MAIN) }
    val title = when (page) {
        SPage.MAIN -> tr("الإعدادات", "Settings")
        SPage.LANG -> tr("اللغة", "Language")
        SPage.FONT -> tr("تغيير الخط", "Change font")
        SPage.ABOUT -> tr("إنشاء وتصميم", "Created & designed by")
    }
    LayerDialog(title, onDismiss) {
        key(page) {
            when (page) {
                SPage.MAIN -> {
                    LayerItem(
                        tr("اللغة", "Language"), 0, Icons.Default.Language,
                        value = if (Lang.en) "English" else "العربية"
                    ) { page = SPage.LANG }
                    LayerItem(
                        tr("إعادة فحص الجهاز (دوّر على أغاني جديدة)", "Rescan device (look for new songs)"),
                        1, Icons.Default.Refresh
                    ) { onDismiss(); onRescan() }
                    LayerItem(tr("ريفريش", "Refresh"), 2, Icons.Default.Sync) { onDismiss(); onRefresh() }
                    LayerItem(tr("تغيير الخط", "Change font"), 3, Icons.Default.TextFields) { page = SPage.FONT }
                    LayerItem(tr("وصف البرنامج", "About the app"), 4, Icons.Default.Info) { page = SPage.ABOUT }
                }

                SPage.LANG -> {
                    LayerItem("العربية", 0, Icons.Default.Language, selected = !Lang.en) { vm.setLang(false) }
                    LayerItem("English", 1, Icons.Default.Language, selected = Lang.en) { vm.setLang(true) }
                    LayerItem(tr("رجوع", "Back"), 2, Icons.AutoMirrored.Filled.ArrowBack) { page = SPage.MAIN }
                }

                SPage.FONT -> {
                    FONTS.forEachIndexed { i, f ->
                        val on = AppFont.key == f.key
                        LayerItem(
                            f.label, i, Icons.Default.TextFields,
                            value = if (on) "✓" else if (f.key == "readex") tr("الأساسي", "Default") else null,
                            selected = on, family = familyOf(f.key)
                        ) { vm.setFont(f.key) }
                    }
                    LayerItem(tr("رجوع", "Back"), FONTS.size, Icons.AutoMirrored.Filled.ArrowBack) { page = SPage.MAIN }
                }

                SPage.ABOUT -> {
                    AboutBlock()
                    LayerItem(tr("رجوع", "Back"), 1, Icons.AutoMirrored.Filled.ArrowBack) { page = SPage.MAIN }
                }
            }
        }
    }
}

private val HUES = listOf(
    Color(0xFF7FD4FF), Color(0xFF9DB7FF), Color(0xFFC39BFF), Color(0xFFFF9BD1), Color(0xFFFFC58A), Color(0xFF7FF0C3),
)

/** اسم المصمم بلون بيتغير ببطء وتوهج. */
@Composable
private fun AboutBlock() {
    val inf = rememberInfiniteTransition(label = "about")
    val ph by inf.animateFloat(0f, HUES.size.toFloat(), infiniteRepeatable(tween(24000, easing = LinearEasing)), label = "ph")
    val i = ph.toInt().coerceIn(0, HUES.size - 1)
    val col = lerp(HUES[i], HUES[(i + 1) % HUES.size], ph - i)
    Column(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 2.dp).padding(bottom = 14.dp).staggerIn(0)) {
        Text(
            tr("يوسف فتحي طلعت", "Youssef Fathy Talaat"),
            style = TextStyle(
                color = col, fontFamily = Readex, fontWeight = FontWeight.ExtraBold, fontSize = 25.sp,
                lineHeight = 36.sp, shadow = Shadow(col.copy(alpha = 0.8f), blurRadius = 26f)
            ),
            modifier = Modifier.padding(bottom = 12.dp)
        )
        Text(
            tr(ABOUT_AR, ABOUT_EN), color = Mut, fontFamily = Readex, fontSize = 14.5.sp, lineHeight = 26.sp
        )
    }
}

private val RATES = listOf(0.75f, 1f, 1.25f, 1.5f, 2f)
private val SLEEPS = listOf(0, 10, 20, 30, 60)

/** إعدادات التشغيل (من الترس اللي في المشغّل): السرعة، مؤقت النوم، رفع الصوت، والتشغيل المستقر في الخلفية. */
@Composable
fun PlaybackLayer(vm: MainVM, onDismiss: () -> Unit) {
    val boost by vm.boost.collectAsState()
    val speed by vm.speed.collectAsState()
    val sleepLeft by vm.sleepLeft.collectAsState()
    var sleepSel by remember { mutableIntStateOf(0) }
    val ctx = LocalContext.current

    LayerDialog(tr("إعدادات التشغيل", "Playback settings"), onDismiss) {
        LayerLabel(tr("السرعة", "Speed"), "${if (speed % 1f == 0f) speed.toInt().toString() else speed.toString()}×")
        SegSelector(
            RATES.map { if (it % 1f == 0f) "${it.toInt()}×" else "$it×" },
            RATES.indexOfFirst { it == speed }.coerceAtLeast(1)
        ) { vm.setSpeed(RATES[it]) }

        Spacer(Modifier.height(14.dp))
        LayerLabel(
            tr("مؤقت النوم (بالدقايق)", "Sleep timer (min)"),
            if (sleepLeft > 0) tr("باقي ${formatTime(sleepLeft)}", "Left ${formatTime(sleepLeft)}") else ""
        )
        SegSelector(
            SLEEPS.map { if (it == 0) tr("إيقاف", "Off") else it.toString() },
            if (sleepLeft <= 0) 0 else sleepSel
        ) { sleepSel = it; vm.setSleep(SLEEPS[it]) }

        Spacer(Modifier.height(14.dp))
        var drag by remember(boost) { mutableFloatStateOf(boost.toFloat()) }
        val col = lerp(Sky, Color(0xFFFF6A3D), ((drag - 100f) / 200f).coerceIn(0f, 1f))
        LayerLabel(tr("رفع الصوت", "Volume boost"), "${drag.toInt()}%", valueColor = col)
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Slider(
                value = drag,
                onValueChange = { drag = it },
                onValueChangeFinished = { vm.setBoost(drag.toInt()) },
                valueRange = 100f..300f,
                colors = SliderDefaults.colors(
                    thumbColor = col, activeTrackColor = col,
                    inactiveTrackColor = Color.White.copy(alpha = 0.15f)
                ),
            )
        }
        Text(
            tr("فوق 200% الصوت ممكن يتشوّه في بعض الأغاني.", "Above 200% some tracks may distort."),
            color = Mut, fontFamily = Readex, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 4.dp)
        )

        Spacer(Modifier.height(14.dp))
        LayerLabel(tr("تشغيل مستقر في الخلفية", "Stable background playback"), "")
        Text(
            tr(
                "لو التشغيل بيقف لوحده والشاشة مقفولة، اسمح للتطبيق يشتغل من غير توفير بطارية.",
                "If playback stops by itself with the screen off, let the app run without battery optimization."
            ),
            color = Mut, fontFamily = Readex, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp)
        )
        Spacer(Modifier.height(6.dp))
        LayerItem(tr("إعدادات البطارية", "Battery settings"), 0) {
            runCatching { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        }
        LayerItem(tr("إعدادات الإشعارات", "Notification settings"), 1) {
            runCatching {
                ctx.startActivity(
                    Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
                )
            }
        }
        LayerButtons(null, tr("تم", "Done"), onOk = onDismiss)
    }
}
