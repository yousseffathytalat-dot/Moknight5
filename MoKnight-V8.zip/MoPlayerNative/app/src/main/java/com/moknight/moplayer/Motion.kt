package com.moknight.moplayer

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.withFrameNanos
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

/**
 * هالة ضوئية (جلو) ناعمة حوالين العنصر، مرسومة بطبقات شفافة فتشتغل على كل إصدارات أندرويد.
 * [alpha] دالة عشان الجلو يتحرك (نبض) من غير ما يعمل recomposition.
 */
fun Modifier.glow(color: Color, radius: Dp = 18.dp, corner: Dp = 24.dp, alpha: () -> Float): Modifier =
    this.drawBehind {
        val a = alpha()
        if (a <= 0.01f) return@drawBehind
        val r = radius.toPx()
        val c = corner.toPx()
        val steps = 8
        for (i in steps downTo 1) {
            val f = i / steps.toFloat()
            val grow = r * f
            drawRoundRect(
                color = color.copy(alpha = (a * 0.30f * (1f - f * 0.82f)).coerceIn(0f, 1f)),
                topLeft = Offset(-grow, -grow),
                size = Size(size.width + grow * 2f, size.height + grow * 2f),
                cornerRadius = CornerRadius(c + grow)
            )
        }
    }

fun Modifier.glow(color: Color, radius: Dp = 18.dp, corner: Dp = 24.dp, alpha: Float): Modifier =
    this.glow(color, radius, corner) { alpha }

/** ضغطة بترد (ترتد بنعومة) لما تلمس العنصر. */
@OptIn(ExperimentalFoundationApi::class)
fun Modifier.bounceClick(
    enabled: Boolean = true,
    onLong: (() -> Unit)? = null,
    onClick: () -> Unit,
): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(
        if (pressed) 0.95f else 1f,
        spring(dampingRatio = 0.5f, stiffness = 520f),
        label = "bounce"
    )
    this
        .graphicsLayer { scaleX = sc; scaleY = sc }
        .combinedClickable(
            interactionSource = src,
            indication = null,
            enabled = enabled,
            onLongClick = onLong,
            onClick = onClick,
        )
}

/** ظهور العنصر بنعومة: يطلع من تحت ويكبر شوية، بتأخير حسب ترتيبه. */
@Composable
fun Modifier.staggerIn(index: Int, step: Int = 40, rise: Dp = 16.dp): Modifier {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay((index.coerceIn(0, 10) * step).toLong())
        a.animateTo(1f, tween(380, easing = FastOutSlowInEasing))
    }
    return this.graphicsLayer {
        alpha = a.value
        translationY = (1f - a.value) * rise.toPx()
        val sc = 0.95f + 0.05f * a.value
        scaleX = sc
        scaleY = sc
    }
}

/** ترس الإعدادات: بيلف ببطء لوحده، ولما تضغط عليه بيلف لفة سريعة. */
@Composable
fun GearIcon(tint: Color, size: Dp, spinKey: Int = 0, idle: Boolean = true, modifier: Modifier = Modifier) {
    val spin = remember { Animatable(0f) }
    LaunchedEffect(spinKey) {
        if (spinKey > 0) spin.animateTo(spin.value + 180f, tween(650, easing = FastOutSlowInEasing))
    }
    val idleDeg = if (idle) {
        val inf = rememberInfiniteTransition(label = "gear")
        val d by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(16000, easing = LinearEasing)), label = "gi")
        d
    } else 0f
    Icon(
        Icons.Outlined.Settings, null, tint = tint,
        modifier = modifier.size(size).graphicsLayer { rotationZ = idleDeg + spin.value }
    )
}

/** زاوية دوران بتزيد مع الوقت طول ما [playing] صحيح، وبتثبت لما يوقف (الغلاف الدوّار). */
@Composable
fun rememberSpin(playing: Boolean, degPerSec: Float = 22f): State<Float> {
    val angle = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(playing) {
        if (playing) {
            var last = withFrameNanos { it }
            while (true) {
                val now = withFrameNanos { it }
                angle.floatValue = (angle.floatValue + (now - last) / 1_000_000_000f * degPerSec) % 360f
                last = now
            }
        }
    }
    return angle
}
