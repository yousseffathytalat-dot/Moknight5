package com.moknight.moplayer

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.shape.RoundedCornerShape

sealed interface Dlg {
    data class NewList(val add: List<Long>) : Dlg
    data class Rename(val pl: Playlist) : Dlg
    data class DeleteList(val pl: Playlist) : Dlg
    data class Pick(val ids: List<Long>) : Dlg
    data class Edit(val t: Track) : Dlg
    data class ConfirmHide(val ids: List<Long>) : Dlg
    object AppSettings : Dlg
    object Playback : Dlg
    object Plus : Dlg
    data class TrackMenu(val t: Track, val fromPlayer: Boolean) : Dlg
    data class ListMenu(val p: Playlist) : Dlg
    data class Move(val ids: List<Long>) : Dlg
}

@Composable
private fun field(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = onChange, singleLine = true,
        label = { Text(label, fontFamily = Readex) },
        shape = RoundedCornerShape(22.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = Tx, unfocusedTextColor = Tx,
            focusedBorderColor = Sky, unfocusedBorderColor = Mut,
            cursorColor = Sky, focusedLabelColor = Sky, unfocusedLabelColor = Mut,
        ),
        modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)
    )
}

@Composable
fun NameDialog(title: String, initial: String, ok: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var name by remember { mutableStateOf(initial) }
    LayerDialog(title, onDismiss) {
        field(tr("الاسم", "Name"), name) { name = it }
        LayerButtons(tr("إلغاء", "Cancel"), ok, onCancel = onDismiss) { onOk(name) }
    }
}

@Composable
fun EditDialog(t: Track, onDismiss: () -> Unit, onOk: (String, String, Kind) -> Unit) {
    var title by remember { mutableStateOf(t.title) }
    var artist by remember { mutableStateOf(t.artist) }
    var kind by remember { mutableStateOf(t.kind) }
    LayerDialog(tr("تعديل الملف", "Edit file"), onDismiss) {
        field(tr("الاسم", "Name"), title) { title = it }
        field(tr("الفنان", "Artist"), artist) { artist = it }
        LayerLabel(tr("التصنيف", "Category"), "")
        SegSelector(Kind.values().map { kindLabel(it) }, kind.ordinal) { kind = Kind.values()[it] }
        LayerButtons(tr("إلغاء", "Cancel"), tr("حفظ", "Save"), onCancel = onDismiss) { onOk(title, artist, kind) }
    }
}

@Composable
fun ConfirmDialog(title: String, msg: String, ok: String, onDismiss: () -> Unit, onOk: () -> Unit) {
    LayerDialog(title, onDismiss) {
        Text(
            msg, color = Mut, fontFamily = Readex, fontSize = 14.sp, lineHeight = 25.sp,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp)
        )
        LayerButtons(tr("إلغاء", "Cancel"), ok, danger = true, onCancel = onDismiss, onOk = onOk)
    }
}

@Composable
fun PickListDialog(
    lists: List<Playlist>, onDismiss: () -> Unit, onPick: (Playlist) -> Unit, onNew: () -> Unit
) {
    LayerDialog(tr("إضافة لقائمة", "Add to playlist"), onDismiss) {
        LayerItem(tr("قائمة جديدة", "New playlist"), 0, Icons.Default.Add) { onNew() }
        lists.forEachIndexed { i, p ->
            LayerItem(p.name, i + 1, Icons.Default.QueueMusic, value = "${p.ids.size}") { onPick(p) }
        }
        LayerButtons(null, tr("إلغاء", "Cancel"), onOk = onDismiss)
    }
}
