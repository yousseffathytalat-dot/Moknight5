plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.moknight.moplayer"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.moknight.moplayer"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0-native-rebuild"
    }
}
